import type { Node } from './index';
import { state, ValidationError, type State } from './core';
import { interactive } from './program';
export interface ListOptions<T> {
  key: (item: T) => string;
  render: (item: T, index: number) => Node[];
  pageSize?: number;
  onSelect?: (item: T) => unknown;
  onMove?: (item: T, from: number, to: number) => unknown;
  onDelete?: (item: T) => unknown;
  onRefresh?: () => Promise<T[]> | T[];
  onLoadMore?: () => Promise<T[]> | T[];
}
export class ExtensionList<T> {
  readonly items: State<T[]>;
  readonly selection = state.create<string[]>([]);
  private visible: State<number>;
  private predicate: (item: T) => boolean = () => true;
  private compare: ((a: T, b: T) => number) | undefined;
  private query = '';
  private stringify: (item: T) => string = item => JSON.stringify(item);
  private loading = false;
  private offset = 0;
  private history: number[] = [];
  private swipes: { title: string; perform: (item: T) => unknown }[] = [];
  private contextActions: { title: string; perform: (item: T) => unknown }[] = [];
  constructor(initial: T[], private options: ListOptions<T>) {
    if (!Array.isArray(initial) || typeof options.key !== 'function' || typeof options.render !== 'function' ||
        !Number.isInteger(options.pageSize ?? 20) || (options.pageSize ?? 20) < 1 || (options.pageSize ?? 20) > 40)
      throw new ValidationError('list_options_invalid');
    this.validate(initial);
    this.items = state.create([...initial]); this.visible = state.create(options.pageSize ?? 20);
  }
  private validate(items: T[]): void {
    if (items.length > 10000) throw new ValidationError('list_item_limit');
    const keys = items.map(item => this.options.key(item));
    if (keys.some(key => typeof key !== 'string' || !key || key.length > 200) || new Set(keys).size !== keys.length)
      throw new ValidationError('list_keys_invalid');
  }
  filter(predicate: (item: T) => boolean): this { if(typeof predicate!=='function')throw new ValidationError('list_filter_invalid');this.predicate = predicate; this.resetPage();this.invalidate(); return this; }
  sort(compare: (a: T, b: T) => number): this { if(typeof compare!=='function')throw new ValidationError('list_sort_invalid');this.compare = compare; this.resetPage();this.invalidate(); return this; }
  search(query: string, stringify?: (item: T) => string): this {
    if (typeof query !== 'string' || query.length > 4000) throw new ValidationError('list_search_invalid');
    this.query = query.normalize('NFKC').toLocaleLowerCase();
    if (stringify) this.stringify = stringify;
    this.resetPage();this.invalidate(); return this;
  }
  select(key: string): void { this.multiSelect([key]); const item = this.items.value.find(item => this.options.key(item) === key); if (item !== undefined) this.options.onSelect?.(item); }
  multiSelect(keys: string[]): void {
    const valid = new Set(this.items.value.map(item => this.options.key(item)));
    if (!Array.isArray(keys) || keys.some(key => !valid.has(key)) || new Set(keys).size !== keys.length) throw new ValidationError('list_selection_invalid');
    this.selection.set([...keys]);
  }
  async refresh(): Promise<void> {
    if (!this.options.onRefresh || this.loading) return;
    this.loading = true; this.invalidate();
    try { const next = await this.options.onRefresh(); this.validate(next); this.items.set([...next]); this.multiSelect(this.selection.value.filter(key => next.some(item => this.options.key(item) === key))); this.resetPage(); }
    finally { this.loading = false; this.invalidate(); }
  }
  async loadMore(): Promise<void> {
    if (this.loading) return;
    if (this.visible.value < this.rows().length) { this.visible.update(value => value + (this.options.pageSize ?? 20)); return; }
    if (!this.options.onLoadMore) return;
    this.loading = true; this.invalidate();
    try { const next = [...this.items.value, ...await this.options.onLoadMore()]; this.validate(next); this.items.set(next); this.visible.update(value => value + (this.options.pageSize ?? 20)); }
    finally { this.loading = false; this.invalidate(); }
  }
  async move(from: number, to: number): Promise<void> {
    if (this.compare || this.query || this.items.value.some(item => !this.predicate(item))) throw new ValidationError('list_move_requires_unfiltered_order');
    if (![from, to].every(index => Number.isInteger(index) && index >= 0 && index < this.items.value.length)) throw new ValidationError('list_index_invalid');
    const next = [...this.items.value]; const [item] = next.splice(from, 1); next.splice(to, 0, item);
    await this.options.onMove?.(item, from, to); this.items.set(next);
  }
  async delete(key: string): Promise<boolean> {
    const item = this.items.value.find(item => this.options.key(item) === key);
    if (item === undefined) return false;
    await this.options.onDelete?.(item);
    this.items.update(rows => rows.filter(row => this.options.key(row) !== key));
    this.selection.update(keys => keys.filter(value => value !== key)); return true;
  }
  swipe(actions: { title: string; perform: (item: T) => unknown }[]): this { this.swipes = this.actions(actions); return this; }
  contextMenu(actions: { title: string; perform: (item: T) => unknown }[]): this { this.contextActions = this.actions(actions); return this; }
  private actions(actions: { title: string; perform: (item: T) => unknown }[]) {
    if (!Array.isArray(actions) || actions.length > 8 || actions.some(action => !action.title?.trim() || action.title.length > 120 || typeof action.perform !== 'function')) throw new ValidationError('list_actions_invalid');
    this.invalidate(); return [...actions];
  }
  private invalidate(): void { (globalThis as { __citInvalidate?: () => void }).__citInvalidate?.(); }
  private resetPage(): void { this.offset=0;this.history=[];this.visible.set(this.options.pageSize??20); }
  private rows(): T[] { const rows = this.items.value.filter(item => this.predicate(item) && this.stringify(item).normalize('NFKC').toLocaleLowerCase().includes(this.query)); return this.compare ? rows.sort(this.compare) : rows; }
  render(lazy = false): Node {
    const rows = this.rows();
    const children: Node[] = [];
    if (this.options.onRefresh) children.push(interactive.button('更新', () => this.refresh()));
    if (this.loading) children.push({ type: 'loading', label: '読み込み中' });
    if(this.offset>0&&this.offset>=rows.length)this.resetPage();
    const nodeCount=(node:Node):number=>1+(node.children??[]).reduce((sum,child)=>sum+nodeCount(child),0);
    let used=children.reduce((sum,node)=>sum+nodeCount(node),1),shown=0;
    for(let index=this.offset;index<Math.min(rows.length,this.visible.value);index++){
      const item=rows[index];
      let content: Node = { type: 'column', children: this.options.render(item, index) };
      const controls: Node[] = [];
      const canMove = !this.compare && !this.query && this.items.value.every(candidate => this.predicate(candidate));
      if (this.options.onMove && canMove) {
        if (index > 0) controls.push(interactive.button('上へ移動', () => this.move(index, index - 1)));
        if (index < this.items.value.length - 1) controls.push(interactive.button('下へ移動', () => this.move(index, index + 1)));
      }
      if (this.options.onDelete) controls.push(interactive.button('削除', () => this.delete(this.options.key(item))));
      if (controls.length) content.children!.push({ type: 'row', children: controls });
      if (this.options.onSelect) content.children!.push(interactive.button(this.selection.value.includes(this.options.key(item)) ? '選択中' : '選択', () => this.select(this.options.key(item))));
      if (this.contextActions.length) content = { type: 'context-menu', children: [content, ...this.contextActions.map(action => interactive.button(action.title, () => action.perform(item)))] };
      if (this.swipes.length) content = { type: 'swipe-actions', children: [content, ...this.swipes.map(action => interactive.button(action.title, () => action.perform(item)))] };
      const cost=nodeCount(content)+1;
      if(cost>72)throw new ValidationError('list_row_complexity');
      if(used+cost>80)break;
      children.push(content, { type: 'divider' });used+=cost;shown++;
    }
    if(this.history.length)children.push(interactive.button('前の項目',()=>{this.offset=this.history.pop()??0;this.visible.set(this.offset+(this.options.pageSize??20));this.invalidate();}));
    const next=this.offset+shown;
    if(rows.length>next)children.push(interactive.button('次の項目',()=>{this.history.push(this.offset);this.offset=next;this.visible.set(next+(this.options.pageSize??20));this.invalidate();}));
    else if(this.options.onLoadMore)children.push(interactive.button('さらに読み込む',()=>this.loadMore()));
    return { type: lazy ? 'lazy-list' : 'column', children };
  }
}
export const list = { create: <T>(items: T[], options: ListOptions<T>) => new ExtensionList(items, options) };
