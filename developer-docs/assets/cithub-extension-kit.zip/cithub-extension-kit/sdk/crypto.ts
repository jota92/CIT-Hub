import { ValidationError, UnsupportedError } from './core';
declare const __citRandomBytes: ((length: number) => string) | undefined;
declare const __citCall: (request: string) => Promise<string>;
export interface EncryptedText { algorithm:'AES-256-GCM';iv:string;ciphertext:string }
export interface RS256JWK { kty:'RSA';n:string;e:string;alg?:'RS256';use?:'sig';kid?:string }
async function cipher<T>(operation:'crypto.encrypt'|'crypto.decrypt',key:string,args:Record<string,unknown>):Promise<T>{
  if(typeof key!=='string'||!/^[a-f0-9]{64}$/.test(key))throw new ValidationError('Expected a 32-byte lowercase hex key');
  const reply=JSON.parse(await __citCall(JSON.stringify({operation,args:{key,...args}})));
  if(reply.error)throw new UnsupportedError(reply.error);
  return reply.result as T;
}
async function compute(operation: 'crypto.hash'|'crypto.hmac', text: string, algorithm: 'SHA-256'|'SHA-512', key?:string):Promise<string> {
  if(typeof text!=='string'||text.length>16000||!['SHA-256','SHA-512'].includes(algorithm)||(operation==='crypto.hmac'&&(typeof key!=='string'||!key.length||key.length>4096)))throw new ValidationError('Invalid crypto input');
  const reply=JSON.parse(await __citCall(JSON.stringify({operation,args:{text,algorithm,...(key===undefined?{}:{key})}})));
  if(reply.error)throw new UnsupportedError(reply.error);
  return reply.result as string;
}
function randomBytes(length: number): Uint8Array {
  if (!Number.isInteger(length) || length < 1 || length > 4096) throw new ValidationError('Random byte count must be 1..4096');
  if (typeof __citRandomBytes === 'function') return Uint8Array.from(JSON.parse(__citRandomBytes(length)) as number[]);
  if (!globalThis.crypto?.getRandomValues) throw new UnsupportedError('Secure random unavailable');
  return globalThis.crypto.getRandomValues(new Uint8Array(length));
}
function uuid(): string {
  const bytes = randomBytes(16);
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2,'0')).join('');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}
export const crypto = {
 randomBytes, uuid,
 generateKey: ()=>Array.from(randomBytes(32),byte=>byte.toString(16).padStart(2,'0')).join(''),
 encrypt: (text:string,key:string,aad='')=>cipher<EncryptedText>('crypto.encrypt',key,{text,aad}),
 decrypt: (envelope:EncryptedText,key:string,aad='')=>cipher<string>('crypto.decrypt',key,{envelope,aad}),
 hash: (text:string,algorithm:'SHA-256'|'SHA-512'='SHA-256')=>compute('crypto.hash',text,algorithm),
 hmac: (text:string,key:string,algorithm:'SHA-256'|'SHA-512'='SHA-256')=>compute('crypto.hmac',text,algorithm,key),
 async verifyRS256(data:string,signature:string,jwk:RS256JWK):Promise<boolean>{
  if(typeof data!=='string'||data.length>32768||typeof signature!=='string'||!/^[A-Za-z0-9_-]{300,3000}$/.test(signature)||!jwk||jwk.kty!=='RSA'||typeof jwk.n!=='string'||typeof jwk.e!=='string')throw new ValidationError('Invalid RS256 verification input');
  const reply=JSON.parse(await __citCall(JSON.stringify({operation:'crypto.verifyRS256',args:{data,signature,jwk}})));
  if(reply.error)throw new UnsupportedError(reply.error);
  return reply.result===true;
 },
 async verifyOIDCToken(token:string,expected:{issuer:string;clientId:string;nonce:string},keys:RS256JWK[]):Promise<{subject:string;issuer:string}>{
  if(typeof token!=='string'||token.length>24000||!expected||typeof expected.issuer!=='string'||typeof expected.clientId!=='string'||typeof expected.nonce!=='string'||!Array.isArray(keys)||keys.length>64)throw new ValidationError('Invalid OIDC verification input');
  const reply=JSON.parse(await __citCall(JSON.stringify({operation:'crypto.verifyOIDCToken',args:{token,...expected,keys}})));
  if(reply.error)throw new UnsupportedError(reply.error);
  return reply.result as {subject:string;issuer:string};
 }
};
