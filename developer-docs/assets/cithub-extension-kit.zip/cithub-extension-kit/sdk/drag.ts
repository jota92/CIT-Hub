import { ValidationError } from './core';
import type { Node } from './index';

const boundedText = (value: string): string => {
  if (typeof value !== 'string' || value.length > 4000) throw new ValidationError('drag_text_invalid');
  return value;
};

/** Native plain-text drag and drop. Only text explicitly supplied by the extension is transferable. */
export const drag = {
  source(label: string, value: string): Node {
    if (typeof label !== 'string' || !label.trim() || label.length > 120) throw new ValidationError('drag_label_invalid');
    return { type: 'drag-source', label: label.trim(), text: boundedText(value) };
  },
  target(key: string, label: string): Node {
    if (!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key) || typeof label !== 'string' || !label.trim() || label.length > 120)
      throw new ValidationError('drop_target_invalid');
    return { type: 'drop-target', key, label: label.trim() };
  }
};

/** Native drop targets for plain text explicitly supplied by an extension. */
export const drop = {
  target: drag.target
};
