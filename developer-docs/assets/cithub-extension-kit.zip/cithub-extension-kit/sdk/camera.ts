import { call, permissions, type PermissionStatus, type PickedFileInfo } from './host';
import { ValidationError } from './core';
export interface ScannedCode { value:string; format:'qr'|'ean13'|'ean8'|'code128'|'code39'|'code93'|'pdf417'|'aztec'|'dataMatrix'|'itf'|'upce'|'upca'|'codabar'|'unknown' }
export const camera = {
  capturePhoto:():Promise<PickedFileInfo|null>=>call('camera.capture',{key:captureKey(),kind:'photo',maxSeconds:0}),
  captureVideo(maxSeconds=30):Promise<PickedFileInfo|null> {
    if(!Number.isInteger(maxSeconds)||maxSeconds<1||maxSeconds>60)throw new ValidationError('capture_duration_invalid');
    return call('camera.capture',{key:captureKey(),kind:'video',maxSeconds});
  },
  available: ():Promise<boolean>=>call('camera.available'),
  permissions: ():Promise<PermissionStatus>=>permissions.status('camera.use'),
  scanQRCode: ():Promise<ScannedCode|null>=>call('camera.scan',{format:'qr'}),
  scanBarcode: ():Promise<ScannedCode|null>=>call('camera.scan',{format:'barcode'})
};
let captureSequence=0;
function captureKey():string{return `capture_${Date.now()}_${++captureSequence}`;}
export const code = {
  scanQR:camera.scanQRCode, scanBarcode:camera.scanBarcode,
  generateQR(text:string,name:string,size=512):Promise<{name:string;size:number;mimeType:'image/png';width:number;height:number}> {
    if(typeof text!=='string'||!text.length||Array.from(text).reduce((n,c)=>n+(c.codePointAt(0)!<=127?1:c.codePointAt(0)!<=2047?2:c.codePointAt(0)!<=65535?3:4),0)>1000)throw new ValidationError('qr_text_invalid');
    if(typeof name!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$/.test(name)||name.includes('..'))throw new ValidationError('file_name_invalid');
    if(!Number.isInteger(size)||size<256||size>1024)throw new ValidationError('qr_size_invalid');
    return call('media.generate',{action:'code.generateQR',name,text,size});
  }
};
