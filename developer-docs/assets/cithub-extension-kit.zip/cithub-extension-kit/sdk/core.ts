export class ExtensionError extends Error {
  constructor(message: string, public readonly code = 'EXTENSION_ERROR') { super(message); this.name = new.target.name; }
}
export class ValidationError extends ExtensionError { constructor(message: string) { super(message, 'VALIDATION_ERROR'); } }
export class PermissionError extends ExtensionError { constructor(message: string) { super(message, 'PERMISSION_ERROR'); } }
export class UserInteractionError extends ExtensionError { constructor(message: string) { super(message, 'USER_INTERACTION_REQUIRED'); } }
export class UnsupportedError extends ExtensionError { constructor(message: string) { super(message, 'UNSUPPORTED_ERROR'); } }
export class NetworkError extends ExtensionError { constructor(message: string) { super(message, 'NETWORK_ERROR'); } }
export class StorageError extends ExtensionError { constructor(message: string) { super(message, 'STORAGE_ERROR'); } }
export class RateLimitError extends ExtensionError { constructor(message: string) { super(message, 'RATE_LIMIT_ERROR'); } }
export class ConflictError extends ExtensionError { constructor(message: string) { super(message, 'CONFLICT'); } }
export class NotFoundError extends ExtensionError { constructor(message: string) { super(message, 'NOT_FOUND'); } }

declare const __citRandomBytes: ((length: number) => string) | undefined;

export interface State<T> { readonly value: T; get(): T; set(value: T): void; update(fn: (value: T) => T): void; reset(): void; watch(fn: (value: T, previous: T) => void): () => void }
export const state = {
  create<T>(initial: T): State<T> {
    let value = initial;
    const listeners = new Set<(value: T, previous: T) => void>();
    const set = (next: T) => {
      if (Object.is(value, next)) return;
      const previous = value; value = next;
      for (const listener of [...listeners]) listener(next, previous);
      const invalidate = (globalThis as { __citInvalidate?: () => void }).__citInvalidate;
      if (invalidate) invalidate();
    };
    return { get value() { return value; }, get: () => value, set, update: fn => set(fn(value)), reset: () => set(initial), watch: fn => { listeners.add(fn); return () => { listeners.delete(fn); }; } };
  },
  computed<T>(dependencies: State<unknown>[], calculate: () => T): State<T> & { dispose(): void } {
    const result = state.create(calculate());
    const unsubscribers = dependencies.map(dependency => dependency.watch(() => result.set(calculate())));
    return {
      get value() { return result.value; },
      get: result.get, set: result.set, update: result.update, reset: result.reset, watch: result.watch,
      dispose: () => unsubscribers.forEach(unsubscribe => unsubscribe())
    };
  },
  get<T>(value: State<T>): T { return value.get(); },
  set<T>(value: State<T>, next: T): void { value.set(next); },
  update<T>(value: State<T>, fn: (current: T) => T): void { value.update(fn); },
  reset<T>(value: State<T>): void { value.reset(); },
  watch<T>(value: State<T>, fn: (next: T, previous: T) => void): () => void { return value.watch(fn); }
};
const numbers = (values: number[]) => { if (values.some(value => !Number.isFinite(value))) throw new ValidationError('Finite numbers required'); return values; };
export const math = {
  round: Math.round, floor: Math.floor, ceil: Math.ceil, min: Math.min, max: Math.max, abs: Math.abs, random: Math.random,
  clamp(value: number, min: number, max: number) { numbers([value, min, max]); if (min > max) throw new ValidationError('Invalid bounds'); return Math.min(max, Math.max(min, value)); },
  sum(values: number[]) { return numbers(values).reduce((total, value) => total + value, 0); },
  average(values: number[]) { if (!values.length) throw new ValidationError('Empty sample'); return math.sum(values) / values.length; },
  median(values: number[]) { if (!values.length) throw new ValidationError('Empty sample'); const sorted = numbers([...values]).sort((a, b) => a - b); const middle = Math.floor(sorted.length / 2); return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2; }
};
export const text = {
  format(template: string, values: Record<string, string | number>) { return template.replace(/\{([\w.-]+)\}/g, (match, key) => Object.prototype.hasOwnProperty.call(values, key) ? String(values[key]) : match); },
  replace: (value: string, search: string, replacement: string) => value.split(search).join(replacement),
  split: (value: string, separator: string) => value.split(separator), join: (values: string[], separator = '') => values.join(separator),
  contains: (value: string, search: string) => value.includes(search), startsWith: (value: string, search: string) => value.startsWith(search), endsWith: (value: string, search: string) => value.endsWith(search),
  trim: (value: string) => value.trim(), lowercase: (value: string) => value.toLowerCase(), uppercase: (value: string) => value.toUpperCase(),
  regex(pattern: string, flags = ''): RegExp {
    if (typeof pattern !== 'string' || pattern.length > 256 || typeof flags !== 'string' || flags.length > 6 || /[^dgimsuvy]/.test(flags) || new Set(flags).size !== flags.length) {
      throw new ValidationError('Invalid regular expression');
    }
    try { return new RegExp(pattern, flags); }
    catch { throw new ValidationError('Invalid regular expression'); }
  }
};
export const json = { parse: (value: string): unknown => JSON.parse(value), stringify: (value: unknown) => JSON.stringify(value) };
export type DateInput = Date | string | number;
declare const __citDateFormat: (request: string) => string;
declare const __citTimezone: () => string;
const validDate = (value: DateInput) => { const result = new Date(value); if (!Number.isFinite(result.getTime())) throw new ValidationError('Invalid date'); return result; };
export const date = {
  now: () => new Date(), parse: validDate,
  format(value: DateInput, options: Intl.DateTimeFormatOptions = {}, locale = 'ja-JP') {
    const parsed = validDate(value);
    if (typeof Intl !== 'undefined') return new Intl.DateTimeFormat(locale, options).format(parsed);
    if (typeof __citDateFormat === 'function') return __citDateFormat(JSON.stringify({ time: parsed.getTime(), options, locale }));
    throw new UnsupportedError('Date formatting unavailable');
  },
  add(value: DateInput, milliseconds: number) { numbers([milliseconds]); return validDate(validDate(value).getTime() + milliseconds); },
  subtract(value: DateInput, milliseconds: number) { return date.add(value, -milliseconds); },
  diff: (a: DateInput, b: DateInput) => validDate(a).getTime() - validDate(b).getTime(),
  startOfDay(value: DateInput) { const result = validDate(value); result.setHours(0, 0, 0, 0); return result; },
  endOfDay(value: DateInput) { const result = validDate(value); result.setHours(23, 59, 59, 999); return result; },
  startOfWeek(value: DateInput, firstDay = 1) { if (!Number.isInteger(firstDay) || firstDay < 0 || firstDay > 6) throw new ValidationError('Invalid weekday'); const result = date.startOfDay(value); result.setDate(result.getDate() - (result.getDay() - firstDay + 7) % 7); return result; },
  endOfWeek(value: DateInput, firstDay = 1) { const result = date.startOfWeek(value, firstDay); result.setDate(result.getDate() + 6); return date.endOfDay(result); },
  isToday: (value: DateInput) => date.startOfDay(value).getTime() === date.startOfDay(new Date()).getTime(),
  isPast: (value: DateInput) => validDate(value).getTime() < Date.now(), isFuture: (value: DateInput) => validDate(value).getTime() > Date.now(),
  timezone: () => typeof Intl !== 'undefined' ? Intl.DateTimeFormat().resolvedOptions().timeZone : typeof __citTimezone === 'function' ? __citTimezone() : 'UTC'
};

const duration = (milliseconds: number) => {
  if (!Number.isFinite(milliseconds) || milliseconds < 0 || milliseconds > 2147483647) throw new ValidationError('Invalid duration');
  return milliseconds;
};
export const utils = {
  uuid(): string {
    let bytes: Uint8Array;
    if (typeof __citRandomBytes === 'function') bytes = Uint8Array.from(JSON.parse(__citRandomBytes(16)) as number[]);
    else if (globalThis.crypto?.getRandomValues) bytes = globalThis.crypto.getRandomValues(new Uint8Array(16));
    else throw new UnsupportedError('Secure random unavailable');
    if (bytes.length !== 16) throw new UnsupportedError('Secure random unavailable');
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  },
  sleep(milliseconds: number, signal?: AbortSignal): Promise<void> {
    duration(milliseconds);
    return new Promise((resolve, reject) => {
      if (signal?.aborted) { reject(signal.reason); return; }
      const cancel = () => { clearTimeout(timer); signal?.removeEventListener('abort', cancel); reject(signal?.reason); };
      const timer = setTimeout(() => { signal?.removeEventListener('abort', cancel); resolve(); }, milliseconds);
      signal?.addEventListener('abort', cancel, { once: true });
    });
  },
  debounce<T extends unknown[]>(callback: (...args: T) => void, milliseconds: number) {
    duration(milliseconds);
    let timer: ReturnType<typeof setTimeout> | undefined;
    const run = (...args: T) => { clearTimeout(timer); timer = setTimeout(() => { timer = undefined; callback(...args); }, milliseconds); };
    return Object.assign(run, { cancel() { clearTimeout(timer); timer = undefined; } });
  },
  throttle<T extends unknown[]>(callback: (...args: T) => void, milliseconds: number) {
    duration(milliseconds);
    let last = -Infinity;
    return (...args: T) => { const now = Date.now(); if (now - last >= milliseconds) { last = now; callback(...args); } };
  }
};
export interface Coordinate { latitude: number; longitude: number }
const coordinate = (value: Coordinate) => {
  numbers([value.latitude, value.longitude]);
  if (Math.abs(value.latitude) > 90 || Math.abs(value.longitude) > 180) throw new ValidationError('Invalid coordinate');
  return value;
};
const radians = (value: number) => value * Math.PI / 180;
export const geo = {
  distance(from: Coordinate, to: Coordinate): number {
    coordinate(from); coordinate(to);
    const latitude = radians(to.latitude - from.latitude), longitude = radians(to.longitude - from.longitude);
    const a = Math.sin(latitude / 2) ** 2 + Math.cos(radians(from.latitude)) * Math.cos(radians(to.latitude)) * Math.sin(longitude / 2) ** 2;
    return 6371008.8 * 2 * Math.atan2(Math.sqrt(Math.min(1, a)), Math.sqrt(Math.max(0, 1 - a)));
  },
  bearing(from: Coordinate, to: Coordinate): number {
    coordinate(from); coordinate(to);
    const longitude = radians(to.longitude - from.longitude);
    const y = Math.sin(longitude) * Math.cos(radians(to.latitude));
    const x = Math.cos(radians(from.latitude)) * Math.sin(radians(to.latitude)) - Math.sin(radians(from.latitude)) * Math.cos(radians(to.latitude)) * Math.cos(longitude);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  },
  contains(point: Coordinate, circle: { center: Coordinate; radius: number }): boolean {
    numbers([circle.radius]); if (circle.radius < 0) throw new ValidationError('Invalid radius');
    return geo.distance(point, circle.center) <= circle.radius;
  }
};
