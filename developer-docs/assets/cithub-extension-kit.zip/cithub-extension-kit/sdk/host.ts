import { ConflictError, ExtensionError, NetworkError, NotFoundError, PermissionError, RateLimitError, StorageError, UnsupportedError, UserInteractionError, ValidationError, parseHTTPSURL } from './core';
import { openHostService } from './integration';
import { shared } from './collaboration';
import type { AcademicCalendarEvent, BusDayType, BusDeparture, BusRoute, BusSchedule, BusServiceStatus, CafeteriaCameraStatus, CafeteriaHours, CafeteriaLocation, CampusRoom, CampusService, Course, CourseOccurrence, PeriodSlot, RoomScheduleStatus, Task, UserPreferences } from './index';
import type { Permission } from './index';
export type PermissionStatus = 'granted'|'denied'|'prompt'|'user-selection'|'undeclared'|'unsupported';
export interface LocationFix { latitude:number; longitude:number; accuracyMeters:number; timestamp:string; precision:'approximate'|'precise' }
export type BackgroundAvailability = 'available'|'denied'|'restricted'|'unknown'|'unsupported';
export interface BackgroundStatus { availability:BackgroundAvailability; mayRun:boolean|null; platform:string; note:string }
declare const __citCall: (request: string) => Promise<string>;
declare const __citContext: { version: string; extensionId: string; environment: 'development' | 'production'; hostVersion: string; capabilities: string[] };
const lifecycle = new Map<string, Set<(payload: unknown) => unknown>>();
export async function call<T>(operation: string, args: unknown = {}): Promise<T> {
  const reply = JSON.parse(await __citCall(JSON.stringify({ operation, args })));
  if (reply.error) {
    const code = typeof reply.error === 'string' ? reply.error : 'host_request_failed';
    if (code === 'permission_required' || code === 'not_allowed' || code.endsWith('_permission_denied') || code === 'permission_request_denied') throw new PermissionError(code);
    if (code === 'user_gesture_required') throw new UserInteractionError(code);
    if (code === 'unsupported') throw new UnsupportedError(code);
    if (code === 'rate_limited' || code === 'storage_quota') throw new RateLimitError(code);
    if (code.endsWith('_conflict') || code === 'data_conflict') throw new ConflictError(code);
    if (code === 'not_found' || code.endsWith('_not_found')) throw new NotFoundError(code);
    if (code.startsWith('network_')) throw new NetworkError(code);
    if (/^(validation_|invalid_|.*_invalid$|.*_required$)/.test(code)) throw new ValidationError(code);
    if (/^(storage_|file_|cloud_)/.test(code)) throw new StorageError(code);
    throw new ExtensionError(code, 'HOST_ERROR');
  }
  return reply.result as T;
}
const key = (value: string) => { if (!/^[A-Za-z][A-Za-z0-9_.-]{0,99}$/.test(value)) throw new ValidationError('Invalid key'); return value; };
let preferencesRequest:Promise<UserPreferences>|undefined;
function userPreferences():Promise<UserPreferences>{
  if(preferencesRequest)return preferencesRequest;
  preferencesRequest=call<Record<string,unknown>>('cit.query',{query:'settings.display'}).then(value=>({
    accentColor:typeof value.accentColor==='string'?value.accentColor:null,
    enabledServices:Array.isArray(value.serviceTabs)?value.serviceTabs.filter((item):item is string=>typeof item==='string'):[],
    notifications:{classStart:value.classStartReminder===true,assignments:value.assignmentReminder===true},
    portal:{manabaAutoLogin:value.manabaAutoLogin===true,portalAutoLogin:value.portalAutoLogin===true,manabaSmartphoneMode:value.manabaSmartphoneMode===true,portalSmartphoneMode:value.portalSmartphoneMode===true}
  })).finally(()=>{preferencesRequest=undefined;});
  return preferencesRequest;
}
export const permissions = {
 status: (permission:Permission):Promise<PermissionStatus> => call('permissions.status',{permission}),
 request: (permission:Permission):Promise<PermissionStatus> => call('permissions.request',{permission}),
 openSettings: ():Promise<void> => call('permissions.openSettings')
};
export const background = {
  status():Promise<BackgroundStatus> { return call('background.status'); },
  /** Registers an approved server function on the 拡張機能サーバー best-effort scheduler. */
  register(task:{id:string;intervalMinutes:number;networkRequired?:boolean;chargingRequired?:boolean}):Promise<{id:string;accepted:boolean}> {
    if(!task||!Number.isInteger(task.intervalMinutes)||task.intervalMinutes<15||task.intervalMinutes>1440)throw new ValidationError('Background interval must be between 15 and 1440 minutes');
    if(task.chargingRequired===true)throw new UnsupportedError('background_charging_condition_unsupported');
    if(task.networkRequired===false)throw new UnsupportedError('background_offline_execution_unsupported');
    const id=key(task.id);
    return call<{name:string;registered:boolean}>('server.cron',{
      action:'register',name:id,input:null,intervalSeconds:task.intervalMinutes*60
    }).then(result=>({id,accepted:result.registered}));
  },
  unregister(id:string):Promise<boolean> {
    return call<{name:string;registered:boolean}>('server.cron',{action:'unregister',name:key(id)}).then(result=>!result.registered);
  }
};
export const location = {
  permission: ():Promise<PermissionStatus> => permissions.status('location.use'),
  openSettings: permissions.openSettings,
  current():Promise<LocationFix> { return call('location.current'); }
};
export const browser = {
  async open(url:string):Promise<void>{
    safeRequest(url,{});
    return call('browser.open',{url});
  },
  async openExternal(url:string):Promise<void>{
    if(typeof url!=='string'||url.length>2048||/[\s\u0000-\u001f]/.test(url))throw new ValidationError('Invalid browser URL');
    const match=/^https:\/\/(\[[0-9a-f:.]+\]|[a-z0-9.-]+)(?::([0-9]+))?((?:\/[^?#]*)?(?:\?[^#]*)?(?:#.*)?)$/i.exec(url);
    if(!match||match[2]!==undefined&&match[2]!=='443')throw new ValidationError('Only standard-port HTTPS URLs can be opened');
    const hostname=match[1];
    if(hostname.startsWith('[')?!/^\[[0-9a-f:.]+\]$/i.test(hostname):hostname.split('.').some(label=>!label||label.length>63||!/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label)))throw new ValidationError('Invalid browser hostname');
    await call('browser.openExternal',{url:`https://${hostname}${match[2]===undefined?'':':443'}${match[3]}`});
  }
};
export type NetworkMethod = 'GET'|'POST'|'PUT'|'PATCH'|'DELETE';
export type NetworkTransport = 'wifi'|'cellular'|'ethernet'|'other'|'none';
export interface NetworkStatus { connected:boolean; transport:NetworkTransport; metered:boolean|null; constrained:boolean|null; internetValidated:boolean|null }
export interface NetworkOptions { method?: NetworkMethod; headers?: Record<string,string>; body?: string }
export interface NetworkResponse { status:number; ok:boolean; headers:Record<string,string>; body:string }
export interface NetworkFileResponse { status:number; ok:boolean; headers:Record<string,string>; file:{name:string;size:number} }
export interface NetworkTransferProgress { direction:'upload'|'download'; loadedBytes:number; totalBytes:number|null; fraction:number|null }
export type NetworkProgressHandler = (progress:NetworkTransferProgress)=>unknown;
type NetworkDownloadOptions = {headers?:Record<string,string>;onProgress?:NetworkProgressHandler};
function isNetworkDownloadOptions(value:Record<string,string>|NetworkDownloadOptions):value is NetworkDownloadOptions {
  return Object.hasOwn(value,'onProgress')||Object.hasOwn(value,'headers');
}
export interface ExtensionWebSocket {
  readonly id:string;
  readonly ready:Promise<void>;
  onMessage(callback:(data:string)=>unknown):()=>void;
  onClose(callback:(event:{code:number;reason:string})=>unknown):()=>void;
  onError(callback:(code:string)=>unknown):()=>void;
  send(data:string):Promise<void>;
  close(code?:number,reason?:string):Promise<void>;
}
export type NotificationRepeat = 'none'|'daily'|'weekly';
export interface LocalNotificationInput { id:string; title:string; body:string; at:Date; repeat?:NotificationRepeat; data?:Record<string,string> }
export interface ScheduledLocalNotification { id:string; title:string; body:string; at:string; repeat:NotificationRepeat; data:Record<string,string> }
const notificationID=(value:string)=>{if(typeof value!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/.test(value))throw new ValidationError('Invalid notification id');return value;};
const notificationText=(value:string,max:number)=>{if(typeof value!=='string'||!value.trim()||value.length>max)throw new ValidationError('Invalid notification text');return value.trim();};
function notificationData(value:Record<string,string>={}):Record<string,string>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length>10)throw new ValidationError('Invalid notification data');const result:Record<string,string>={};for(const [key,text] of Object.entries(value)){if(!/^[A-Za-z][A-Za-z0-9_.-]{0,39}$/.test(key)||typeof text!=='string'||text.length>500)throw new ValidationError('Invalid notification data');result[key]=text;}return result;}
export const notification = {
 permission():Promise<PermissionStatus>{return permissions.status('notifications.schedule');},
 async schedule(value:LocalNotificationInput):Promise<void>{
  if(!(value.at instanceof Date)||!Number.isFinite(value.at.getTime())||value.at.getTime()<=Date.now())throw new ValidationError('Notification time must be in the future');
  const repeat=value.repeat??'none';if(!['none','daily','weekly'].includes(repeat))throw new ValidationError('Invalid notification repeat');
  await call('notification.schedule',{id:notificationID(value.id),title:notificationText(value.title,80),body:notificationText(value.body,300),at:value.at.toISOString(),repeat,data:notificationData(value.data)});
 },
 cancel(id:string):Promise<boolean>{return call('notification.cancel',{id:notificationID(id)});},
 cancelAll():Promise<number>{return call('notification.cancelAll');},
 listScheduled():Promise<ScheduledLocalNotification[]>{return call('notification.listScheduled');},
 onOpen(callback:(notification:{id:string;data:Record<string,string>;action:string})=>unknown){return listen('notification',callback);}
};
const safeRequest = (url:string, options:NetworkOptions) => {
  const parsed = parseHTTPSURL(url);
  if(!parsed)throw new ValidationError('Only standard-port HTTPS URLs are supported');
  const method=options.method??'GET';
  if(!['GET','POST','PUT','PATCH','DELETE'].includes(method))throw new ValidationError('Invalid network method');
  const headers=options.headers??{};
  if(!headers||typeof headers!=='object'||Array.isArray(headers)||Object.keys(headers).length>20)throw new ValidationError('Invalid network headers');
  for(const [name,value] of Object.entries(headers)){
    if(!/^[!#$%&'*+.^_`|~0-9A-Za-z-]{1,80}$/.test(name)||/^(host|cookie|cookie2|proxy-authorization|proxy-connection|connection|content-length|transfer-encoding)$/i.test(name)||typeof value!=='string'||value.length>2048||/[\r\n]/.test(value))throw new ValidationError('Invalid network header');
  }
  if(options.body!==undefined&&(typeof options.body!=='string'||options.body.length>32768))throw new ValidationError('Network request body is too large');
  if(method==='GET'&&options.body!==undefined)throw new ValidationError('GET requests cannot have a body');
  return {url:parsed.href,method,headers,body:options.body};
};
export const network = {
  upload(url:string,name:string,options:{method?:'POST'|'PUT';headers?:Record<string,string>;onProgress?:NetworkProgressHandler}={}):Promise<NetworkResponse>{return network.uploadFile(url,name,options);},
  download(url:string,name:string,options:Record<string,string>|{headers?:Record<string,string>;onProgress?:NetworkProgressHandler}={}):Promise<NetworkFileResponse>{return network.downloadFile(url,name,options);},
  status():Promise<NetworkStatus>{return call('network.status');},
  async onChange(callback:(status:NetworkStatus)=>unknown):Promise<()=>void>{
    if(typeof callback!=='function')throw new ValidationError('Network change callback is required');
    if(!__citContext.capabilities.includes('network.onChange'))throw new UnsupportedError('network_change_unavailable');
    const listeners=lifecycle.get('networkChange')??new Set<(payload:unknown)=>unknown>();
    const wasEmpty=listeners.size===0;
    const remove=listen('networkChange',callback);
    try{if(wasEmpty&&!networkWatchActive){await call('network.watch');networkWatchActive=true;}}catch(error){remove();throw error;}
    return ()=>{remove();if(!(lifecycle.get('networkChange')?.size)&&networkWatchActive){networkWatchActive=false;void call('network.unwatch').catch(()=>{});}};
  },
  async fetch(url:string, options:NetworkOptions = {}):Promise<NetworkResponse> {
    const args=safeRequest(url,options);
    return call('network.fetch',args);
  },
  async uploadFile(url:string,sourceName:string,options:{method?:'POST'|'PUT';headers?:Record<string,string>;onProgress?:NetworkProgressHandler}={}):Promise<NetworkResponse>{
    const method=options.method??'POST';if(method!=='POST'&&method!=='PUT')throw new ValidationError('File upload supports POST or PUT');
    const request=safeRequest(url,{method,headers:options.headers});
    return withTransferProgress('upload',options.onProgress,progressId=>call('network.uploadFile',{...request,name:fileName(sourceName),...(progressId?{progressId}:{})}));
  },
  async downloadFile(url:string,destinationName:string,options:Record<string,string>|{headers?:Record<string,string>;onProgress?:NetworkProgressHandler}={}):Promise<NetworkFileResponse>{
    const headers=isNetworkDownloadOptions(options)?options.headers??{}:options;
    const onProgress=isNetworkDownloadOptions(options)?options.onProgress:undefined;
    const request=safeRequest(url,{method:'GET',headers});
    return withTransferProgress('download',onProgress,progressId=>call('network.downloadFile',{...request,name:fileName(destinationName),...(progressId?{progressId}:{})}));
  },
  websocket: {
    async connect(url:string):Promise<ExtensionWebSocket>{
      if(typeof url!=='string'||url.length>2048||/[\s\u0000-\u001f]/.test(url))throw new ValidationError('Invalid WebSocket URL');
      const match=/^wss:\/\/([^/?#]+)(\/[^#]*)?(?:#.*)?$/i.exec(url);
      if(!match||match[1].includes('@'))throw new ValidationError('Only secure standard-port WebSockets are supported');
      const authority=match[1].toLowerCase();
      const host=authority.endsWith(':443')?authority.slice(0,-4):authority;
      if(authority.includes(':')&&!authority.endsWith(':443')||host.length>253||!host.includes('.')||host.split('.').some(label=>!/^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)$/.test(label)))throw new ValidationError('Only secure standard-port WebSockets are supported');
      const normalizedURL=`wss://${host}${match[2]||'/'}`;
      if(!__citContext.capabilities.includes('network.websocket'))throw new UnsupportedError('websocket_unavailable');
      const socket=new HostWebSocket(`ws-${++socketSequence}`);
      webSockets.set(socket.id,socket);
      try{await call('network.websocket.connect',{socketId:socket.id,url:normalizedURL})}
      catch(error){webSockets.delete(socket.id);socket.fail(error instanceof Error?error.message:'websocket_connect_failed');throw error}
      return socket;
    }
  },
  get(url:string,headers?:Record<string,string>){return network.fetch(url,{method:'GET',headers});},
  post(url:string,body:string,headers?:Record<string,string>){return network.fetch(url,{method:'POST',body,headers});},
  put(url:string,body:string,headers?:Record<string,string>){return network.fetch(url,{method:'PUT',body,headers});},
  patch(url:string,body:string,headers?:Record<string,string>){return network.fetch(url,{method:'PATCH',body,headers});},
  delete(url:string,headers?:Record<string,string>){return network.fetch(url,{method:'DELETE',headers});}
};
let transferSequence=0;
const transferProgressCallbacks=new Map<string,NetworkProgressHandler>();
listen('transferProgress',(payload:any)=>{
  if(!payload||typeof payload.id!=='string'||!Number.isSafeInteger(payload.loadedBytes)||payload.loadedBytes<0)return;
  const callback=transferProgressCallbacks.get(payload.id);if(!callback)return;
  const totalBytes=Number.isSafeInteger(payload.totalBytes)&&payload.totalBytes>=0?payload.totalBytes:null;
  try{void callback({direction:payload.direction==='upload'?'upload':'download',loadedBytes:payload.loadedBytes,totalBytes,fraction:totalBytes&&totalBytes>0?Math.min(1,payload.loadedBytes/totalBytes):null});}catch{}
});
async function withTransferProgress<T>(direction:'upload'|'download',callback:NetworkProgressHandler|undefined,run:(progressId?:string)=>Promise<T>):Promise<T>{
  if(callback!==undefined&&typeof callback!=='function')throw new ValidationError('onProgress must be a function');
  if(!callback)return run();
  if(!__citContext.capabilities.includes('network.transferProgress'))throw new UnsupportedError('transfer_progress_unavailable');
  const progressId=`transfer-${++transferSequence}`;
  transferProgressCallbacks.set(progressId,callback);
  try{return await run(progressId);}finally{transferProgressCallbacks.delete(progressId);}
}
const utf8Length=(value:string)=>{let bytes=0;for(const character of value){const code=character.codePointAt(0)!;bytes+=code<=0x7f?1:code<=0x7ff?2:code<=0xffff?3:4;}return bytes;};
const clipboardText=(value:string)=>{if(typeof value!=='string'||utf8Length(value)>16*1024)throw new ValidationError('Clipboard text must be at most 16 KiB');return value;};
export const clipboard = {
  read: ():Promise<string|null> => clipboard.readText(),
  write: (value:string):Promise<void> => clipboard.writeText(value),
  readText():Promise<string|null>{return call('clipboard.read');},
  writeText(value:string):Promise<void>{return call('clipboard.write',{text:clipboardText(value)});}
};
export type ShareItem = { text?:string; url?:string };
function sharePayload(items:ShareItem[]):ShareItem[]{
  if(!Array.isArray(items)||items.length<1||items.length>10)throw new ValidationError('Share must contain 1 to 10 items');
  let total=0;
  const result=items.map(item=>{
    if(!item||typeof item!=='object'||Array.isArray(item)||Object.keys(item).some(key=>key!=='text'&&key!=='url'))throw new ValidationError('Invalid share item');
    const result:ShareItem={};
    if(item.text!==undefined){if(typeof item.text!=='string'||!item.text.trim()||utf8Length(item.text)>8*1024)throw new ValidationError('Invalid share text');result.text=item.text;total+=utf8Length(item.text);}
    if(item.url!==undefined){
      if(typeof item.url!=='string'||item.url.length>2048)throw new ValidationError('Invalid share URL');
      const match=/^https:\/\/([A-Za-z0-9.-]+)(?::([0-9]{1,5}))?(?:[/?#][^\s]*)?$/.exec(item.url);
      if(!match||match[1].startsWith('.')||match[1].endsWith('.')||match[1].includes('..')||(match[2]!==undefined&&Number(match[2])!==443))throw new ValidationError('Only valid HTTPS links can be shared');
      result.url=item.url;total+=utf8Length(item.url);
    }
    if(!Object.keys(result).length)throw new ValidationError('Share item is empty');
    return result;
  });
  if(total>16*1024)throw new ValidationError('Shared content is too large');
  return result;
}
export const share = {
  image(key:string):Promise<void>{return call('share.image',{key:selectedFileKey(key)});},
  async items(items:ShareItem[]):Promise<void>{const safe=sharePayload(items);await call('share.present',{items:safe});},
  text(value:string):Promise<void>{return share.items([{text:value}]);},
  url(value:string):Promise<void>{return share.items([{url:value}]);},
  file(key:string):Promise<void>{const safe=selectedFileKey(key);return call('share.file',{key:safe});}
};
const fileName = (name:string) => {
  if(typeof name!=='string'||name.length>100||name==='.'||name==='..'||name.includes('..')||!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$/.test(name))throw new ValidationError('Invalid file name');
  return name;
};
const selectedFileKey=(key:string)=>{if(typeof key!=='string'||!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key))throw new ValidationError('Invalid selected file key');return key;};
const base64Alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function encodeFileBytes(bytes:Uint8Array):string {
  let result='';
  for(let i=0;i<bytes.length;i+=3){const a=bytes[i],hasB=i+1<bytes.length,hasC=i+2<bytes.length,b=hasB?bytes[i+1]:0,c=hasC?bytes[i+2]:0;result+=base64Alphabet[a>>2]+base64Alphabet[((a&3)<<4)|(b>>4)]+(hasB?base64Alphabet[((b&15)<<2)|(c>>6)]:'=')+(hasC?base64Alphabet[c&63]:'=');}
  return result;
}
function decodeFileBytes(value:string):Uint8Array {
  if(typeof value!=='string'||value.length%4!==0||value.length>350000||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value))throw new StorageError('file_data_invalid');
  const output=new Uint8Array(value.length/4*3-(value.endsWith('==')?2:value.endsWith('=')?1:0));let offset=0;
  for(let i=0;i<value.length;i+=4){const a=base64Alphabet.indexOf(value[i]),b=base64Alphabet.indexOf(value[i+1]),c=value[i+2]==='='?0:base64Alphabet.indexOf(value[i+2]),d=value[i+3]==='='?0:base64Alphabet.indexOf(value[i+3]);if(offset<output.length)output[offset++]=(a<<2)|(b>>4);if(offset<output.length)output[offset++]=((b&15)<<4)|(c>>2);if(offset<output.length)output[offset++]=((c&3)<<6)|d;}
  return output;
}
export interface ExtensionFileInfo { name:string; size:number; modifiedAt:number }
export interface SelectedFileInfo { name:string; size:number; mimeType:string }
export type FilePickerKind = 'any'|'image'|'video'|'audio'|'document';
export interface PickedFileInfo extends SelectedFileInfo { key:string }
export interface TransformedImageInfo { name:string; mimeType:'image/jpeg'; size:number; width:number; height:number }
let pickedFileSequence=0;
export const files = {
  async pick(kind:FilePickerKind='any'):Promise<PickedFileInfo|null>{
    if(!['any','image','video','audio','document'].includes(kind))throw new ValidationError('Invalid file type');
    const key=`picked_${Date.now().toString(36)}_${(++pickedFileSequence).toString(36)}`;
    const result=await call<SelectedFileInfo|null>('files.selection.pick',{key,kind});
    return result===null?null:{...result,key};
  },
  pickImage():Promise<PickedFileInfo|null>{return files.pick('image');},
  pickVideo():Promise<PickedFileInfo|null>{return files.pick('video');},
  pickAudio():Promise<PickedFileInfo|null>{return files.pick('audio');},
  pickDocument():Promise<PickedFileInfo|null>{return files.pick('document');},
  async pickMultiple(kind:Exclude<FilePickerKind,'multiple'>='any'):Promise<PickedFileInfo[]|null>{
    if(!['any','image','video','audio','document'].includes(kind))throw new ValidationError('Invalid file type');
    const key=`picked_${Date.now().toString(36)}_${(++pickedFileSequence).toString(36)}`;
    return call<PickedFileInfo[]|null>('files.selection.pick',{key,kind:'multiple:'+kind});
  },
  async export(name:string,suggestedName=name):Promise<boolean>{
    const safeName=fileName(name);
    if(typeof suggestedName!=='string'||suggestedName.length>120||/[\\/:*?"<>|\u0000-\u001f]/.test(suggestedName)||!suggestedName.trim())throw new ValidationError('Invalid suggested file name');
    return call('files.export',{name:safeName,suggestedName:suggestedName.trim()});
  },
  saveAs(name:string,suggestedName=name):Promise<boolean>{return files.export(name,suggestedName);},
  async read(name:string):Promise<Uint8Array|null>{const value=await call<string|null>('files.read',{name:fileName(name)});return value===null?null:decodeFileBytes(value);},
  async write(name:string,bytes:Uint8Array):Promise<void>{if(!(bytes instanceof Uint8Array)||bytes.byteLength>262144)throw new ValidationError('File must be at most 256 KiB');await call('files.write',{name:fileName(name),data:encodeFileBytes(bytes)});},
  copy(source:string,destination:string):Promise<boolean>{return call('files.copy',{source:fileName(source),destination:fileName(destination)});},
  move(source:string,destination:string):Promise<boolean>{return call('files.move',{source:fileName(source),destination:fileName(destination)});},
  delete(name:string):Promise<boolean>{return call('files.delete',{name:fileName(name)});},
  exists(name:string):Promise<boolean>{return call('files.exists',{name:fileName(name)});},
  list():Promise<string[]>{return call('files.list');},
  info(name:string):Promise<ExtensionFileInfo|null>{return call('files.info',{name:fileName(name)});},
  async selectedInfo(key:string):Promise<SelectedFileInfo|null>{return call('files.selection.info',{key:selectedFileKey(key)});},
  async readSelected(key:string,offset=0,maxBytes=48*1024):Promise<{bytes:Uint8Array;offset:number;totalSize:number;done:boolean}|null>{
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(maxBytes)||maxBytes<1||maxBytes>48*1024)throw new ValidationError('Invalid selected-file range');
    const result=await call<{data:string;offset:number;totalSize:number;done:boolean}|null>('files.selection.read',{key:selectedFileKey(key),offset,maxBytes});
    if(result===null)return null;
    const {data,...metadata}=result;
    return {...metadata,bytes:decodeFileBytes(data)};
  },
  async transformImage(key:string,outputName:string,options:{maxDimension?:number;quality?:number}={}):Promise<TransformedImageInfo>{
    const selectedKey=selectedFileKey(key),name=fileName(outputName);
    const maxDimension=options.maxDimension??1600,quality=options.quality??0.82;
    if(!Number.isInteger(maxDimension)||maxDimension<256||maxDimension>2048||typeof quality!=='number'||!Number.isFinite(quality)||quality<0.35||quality>0.9)throw new ValidationError('Invalid image transform options');
    return call('files.image.transform',{key:selectedKey,name,maxDimension,quality});
  }
};
export interface ScannedDocumentInfo { name:string; pageCount:number; size:number; mimeType:'application/pdf' }
export const scanner = {
  async document(options:{name?:string;maxPages?:number}={}):Promise<ScannedDocumentInfo|null>{
    const name=options.name??`scan_${Date.now().toString(36)}.pdf`;
    const safeName=fileName(name);
    const maxPages=options.maxPages??10;
    if(!safeName.toLowerCase().endsWith('.pdf')||!Number.isInteger(maxPages)||maxPages<1||maxPages>50)throw new ValidationError('Invalid document scan options');
    return call<ScannedDocumentInfo|null>('scanner.document',{name:safeName,maxPages});
  }
};
export const storage = {
  compareAndSet(name: string, expected: unknown, value: unknown): Promise<boolean> { if (expected === undefined || value === undefined) throw new ValidationError('Undefined value'); return call('storage.compareAndSet', { key: key(name), expected, value }); },
  get<T = unknown>(name: string): Promise<T | null> { return call('storage.get', { key: key(name) }); },
  set(name: string, value: unknown): Promise<void> { if (value === undefined) throw new ValidationError('Undefined value'); return call('storage.set', { key: key(name), value }); },
  has(name: string): Promise<boolean> { return call('storage.has', { key: key(name) }); },
  remove(name: string): Promise<void> { return call('storage.remove', { key: key(name) }); },
  clear(): Promise<void> { return call('storage.clear'); },
  keys(): Promise<string[]> { return call('storage.keys'); }
};
const cloudKey=(value:string)=>{if(typeof value!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,99}$/.test(value))throw new ValidationError('Invalid cloud key');return value;};
const cloudValue=(value:unknown)=>{const encoded=JSON.stringify(value);if(encoded===undefined||utf8Length(encoded)>16*1024)throw new ValidationError('Cloud value must be JSON and at most 16 KiB');return value;};
export const cloudUser = {
 async get<T=unknown>(name:string):Promise<{value:T|null;revision:number}>{
  const result=await call<{value_json:string|null;revision:number}>('cloud.user.get',{key:cloudKey(name)});
  return {value:result.value_json===null?null:JSON.parse(result.value_json) as T,revision:result.revision};
 },
 set(name:string,expectedRevision:number,value:unknown):Promise<number>{
  if(!Number.isSafeInteger(expectedRevision)||expectedRevision<0)throw new ValidationError('Invalid cloud revision');cloudValue(value);
  return call<{revision:number}>('cloud.user.set',{key:cloudKey(name),expectedRevision,value}).then(result=>result.revision);
 },
 delete(name:string,expectedRevision:number):Promise<boolean>{
  if(!Number.isSafeInteger(expectedRevision)||expectedRevision<0)throw new ValidationError('Invalid cloud revision');
  return call<{deleted:boolean}>('cloud.user.delete',{key:cloudKey(name),expectedRevision}).then(result=>result.deleted);
 }
};
export const analytics = {
  async event(name:string):Promise<void>{
    if(typeof name!=='string'||!/^[a-z][a-z0-9_.-]{0,47}$/.test(name))throw new ValidationError('Invalid analytics event name');
    await call('analytics.event',{name});
  }
};
export const secureStorage = {
  get<T = unknown>(name: string): Promise<T | null> { return call('secureStorage.get', { key: key(name) }); },
  set(name: string, value: unknown): Promise<void> { if (value === undefined) throw new ValidationError('Undefined value'); return call('secureStorage.set', { key: key(name), value }); },
  delete(name: string): Promise<void> { return call('secureStorage.delete', { key: key(name) }); }
};
export const capabilities = { has: (name: string): boolean => __citContext.capabilities.includes(name) };
let networkWatchActive=false;
let socketSequence=0;
const webSockets=new Map<string,HostWebSocket>();
class HostWebSocket implements ExtensionWebSocket {
  private messageListeners=new Set<(data:string)=>unknown>();
  private closeListeners=new Set<(event:{code:number;reason:string})=>unknown>();
  private errorListeners=new Set<(code:string)=>unknown>();
  private resolveReady!:()=>void;
  private rejectReady!:(reason:Error)=>void;
  readonly ready=new Promise<void>((resolve,reject)=>{this.resolveReady=resolve;this.rejectReady=reject;});
  constructor(readonly id:string){void this.ready.catch(()=>{});}
  onMessage(callback:(data:string)=>unknown){this.messageListeners.add(callback);return()=>this.messageListeners.delete(callback);}
  onClose(callback:(event:{code:number;reason:string})=>unknown){this.closeListeners.add(callback);return()=>this.closeListeners.delete(callback);}
  onError(callback:(code:string)=>unknown){this.errorListeners.add(callback);return()=>this.errorListeners.delete(callback);}
  send(data:string){if(typeof data!=='string'||utf8Length(data)>4096)throw new ValidationError('WebSocket text must be at most 4 KiB');return call<void>('network.websocket.send',{socketId:this.id,data});}
  async close(code=1000,reason=''){if(!Number.isInteger(code)||code<1000||code>4999||typeof reason!=='string'||utf8Length(reason)>120)throw new ValidationError('Invalid WebSocket close request');await call<void>('network.websocket.close',{socketId:this.id,code,reason});}
  dispatch(event:any){if(event.type==='open'){this.resolveReady();return;}if(event.type==='message'&&typeof event.data==='string'){for(const callback of [...this.messageListeners])void callback(event.data);return;}if(event.type==='close'){webSockets.delete(this.id);this.rejectReady(new ExtensionError('websocket_closed_before_open','NETWORK_ERROR'));for(const callback of [...this.closeListeners])void callback({code:event.code,reason:event.reason});return;}if(event.type==='error'){webSockets.delete(this.id);this.rejectReady(new NetworkError(event.code||'websocket_failed'));for(const callback of [...this.errorListeners])void callback(event.code||'websocket_failed');}}
  fail(code:string){this.rejectReady(new NetworkError(code));webSockets.delete(this.id);for(const callback of [...this.errorListeners])void callback(code);}
}
listen('webSocket',(payload:any)=>{if(payload&&typeof payload.id==='string')webSockets.get(payload.id)?.dispatch(payload);});
function listen(event: string, callback: (payload: any) => unknown) {
  if (!lifecycle.has(event)) lifecycle.set(event, new Set());
  lifecycle.get(event)!.add(callback);
  return () => { lifecycle.get(event)?.delete(callback); };
}
export async function emitLifecycle(event: string, payload: unknown) {
  if(event==='suspend'||event==='disappear'){
    if(networkWatchActive){networkWatchActive=false;await call('network.unwatch').catch(()=>{});}
    await Promise.all([...webSockets.values()].map(socket=>socket.close(1001,'app_inactive').catch(()=>{})));
  }else if((event==='resume'||event==='appear')&&lifecycle.get('networkChange')?.size&&!networkWatchActive){
    try{await call('network.watch');networkWatchActive=true;}catch{}
  }
  for (const callback of [...(lifecycle.get(event) ?? [])]) await callback(payload);
}
export interface AppOpenURLPayload { url: string; source?: 'search'; id?: string; route?: string }
export const app = {
  onDeepLink: (callback: (payload: AppOpenURLPayload) => unknown) => listen('openURL', callback),
  onLaunch: (callback: () => unknown) => listen('launch', callback),
  onAppear: (callback: () => unknown) => listen('appear', callback),
  onDisappear: (callback: () => unknown) => listen('disappear', callback),
  onResume: (callback: () => unknown) => listen('resume', callback),
  onSuspend: (callback: () => unknown) => listen('suspend', callback),
  onOpenURL: (callback: (payload: AppOpenURLPayload) => unknown) => listen('openURL', callback),
  onNotification: (callback: (payload: { identifier?: string; action?: string; data?: Record<string, string> }) => unknown) => listen('notification', callback),
  onMemoryWarning: (callback: () => unknown) => listen('memoryWarning', callback),
  onNetworkChange: network.onChange,
  version: (): string => __citContext.version, extensionId: (): string => __citContext.extensionId,
  environment: (): 'development' | 'production' => __citContext.environment, hostVersion: (): string => __citContext.hostVersion,
  capabilities: (): string[] => [...__citContext.capabilities]
};
function japanClock(at: Date) {
  if (!Number.isFinite(at.getTime())) throw new ValidationError('Invalid date');
  const local = new Date(at.getTime() + 9 * 60 * 60 * 1000);
  return { weekday: local.getUTCDay(), minutes: local.getUTCHours() * 60 + local.getUTCMinutes() };
}
function japanDate(at:Date,dayOffset=0){
  if(!Number.isFinite(at.getTime()))throw new ValidationError('Invalid date');
  const local=new Date(at.getTime()+9*60*60*1000);
  const date=new Date(Date.UTC(local.getUTCFullYear(),local.getUTCMonth(),local.getUTCDate()+dayOffset));
  return {year:date.getUTCFullYear(),month:date.getUTCMonth()+1,day:date.getUTCDate(),weekday:date.getUTCDay(),minutes:local.getUTCHours()*60+local.getUTCMinutes()};
}
function occurrence(course:Course,date:ReturnType<typeof japanDate>):CourseOccurrence{
  const iso=(minutes:number|null)=>minutes===null?null:new Date(Date.UTC(date.year,date.month-1,date.day,Math.floor(minutes/60),minutes%60)-9*60*60*1000).toISOString();
  return {...course,date:`${date.year}-${String(date.month).padStart(2,'0')}-${String(date.day).padStart(2,'0')}`,startAt:iso(course.startMinutes),endAt:iso(course.endMinutes)};
}
async function scheduleAt(at:Date):Promise<CourseOccurrence[]>{
  const date=japanDate(at);
  return (await courseRows()).filter(course=>course.weekday===date.weekday).map(course=>occurrence(course,date)).sort((a,b)=>(a.startAt?Date.parse(a.startAt):Number.MAX_SAFE_INTEGER)-(b.startAt?Date.parse(b.startAt):Number.MAX_SAFE_INTEGER));
}
const courseRows = (): Promise<Course[]> => call('cit.query', { query: 'courses.data' });
function roomFromCourse(course:Course):CampusRoom|null {
  const classroom=course.classroom.trim();
  if(!classroom)return null;
  const identity=roomIdentity(classroom);
  const digits=/^\s*(\d{3,4})(?:\s*(?:教室|室))?\s*$/u.exec(classroom.normalize('NFKC'))?.[1]??null;
  const campus=digits?.length===4?'新習志野':digits?.length===3?'津田沼':'不明';
  return {id:identity,classroom,campus,building:digits?.slice(0,1)??null,floor:digits&&digits.length>=3?digits.slice(1,2):null,source:'personal-timetable'};
}
function roomIdentity(value:string):string {
  const canonical=value.normalize('NFKC').trim();
  return /^\d{3,4}(?:\s*(?:教室|室))?$/u.test(canonical)
    ? canonical.replace(/\s*(?:教室|室)$/u,'').trim()
    : normalized(canonical);
}
async function campusRooms():Promise<CampusRoom[]> {
  const unique=new Map<string,CampusRoom>();
  for(const course of await courseRows()) { const room=roomFromCourse(course); if(room&&!unique.has(room.id))unique.set(room.id,room); }
  return [...unique.values()].sort((a,b)=>a.campus.localeCompare(b.campus,'ja')||a.classroom.localeCompare(b.classroom,'ja'));
}
const periodRows = (): Promise<PeriodSlot[]> => call('cit.query', { query: 'timetable.periods' });
const taskRows = (): Promise<Task[]> => call('cit.query', { query: 'assignments.data' });
const normalized = (value: string) => value.normalize('NFKC').toLocaleLowerCase().replace(/\s+/g, '');
function academicDate(at:Date):string {
  if(!(at instanceof Date)||!Number.isFinite(at.getTime()))throw new ValidationError('Invalid date');
  const {year,month,day}=japanDate(at);
  return `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
}
const academicCalendarRows=():Promise<AcademicCalendarEvent[]>=>call('cit.query',{query:'academic.calendar'});
async function busSchedule():Promise<BusSchedule>{
  const value=await call<Record<string,unknown>|null>('cit.query',{query:'bus.schedule'});
  if(!value||typeof value!=='object'||!Array.isArray(value.routes))throw new StorageError('data_unavailable');
  const period=(value.validPeriod??value.valid_period) as Record<string,unknown>|undefined;
  if(!period||typeof period.from!=='string'||typeof period.to!=='string')throw new StorageError('data_unavailable');
  const trip=(raw:unknown):BusRoute['schedules']['weekday'][number]|null=>{
    if(!raw||typeof raw!=='object')return null;
    const row=raw as Record<string,unknown>;
    if(typeof row.time!=='string')return null;
    const departure=row.akanehamaDepartureTime??row.akanehama_departure_time;
    return {time:row.time,viaAkanehamaSportsFacility:row.viaAkanehamaSportsFacility===true||row.via_akanehama_sports_facility===true,akanehamaDepartureTime:typeof departure==='string'?departure:null};
  };
  const routes=value.routes as (Record<string,unknown>&{schedules?:Record<string,unknown>})[];
  return {title:typeof value.title==='string'?value.title:'バスダイヤ',note:typeof value.note==='string'?value.note:null,validPeriod:{from:period.from,to:period.to,original:typeof period.original==='string'?period.original:null},routes:routes.filter(route=>typeof route.from==='string'&&typeof route.to==='string').map(route=>{const schedules=route.schedules??{};return {from:route.from as string,to:route.to as string,schedules:{weekday:((schedules.weekday as unknown[]|undefined)??[]).map(trip).filter((row):row is NonNullable<typeof row>=>row!==null),saturday:((schedules.saturday as unknown[]|undefined)??[]).map(trip).filter((row):row is NonNullable<typeof row>=>row!==null),sunday_holiday:((schedules.sunday_holiday as unknown[]|undefined)??[]).map(trip).filter((row):row is NonNullable<typeof row>=>row!==null)}};})};
}
function busDayType(at:Date):BusDayType { const weekday=japanDate(at).weekday;return weekday===6?'saturday':weekday===0?'sunday_holiday':'weekday'; }
function busDateTime(date:Date,time:string):string|null {
  const match=/^(\d{1,2}):(\d{2})$/.exec(time);
  if(!match)return null;
  const hour=Number(match[1]),minute=Number(match[2]);if(hour>23||minute>59)return null;
  const day=japanDate(date);
  return new Date(Date.UTC(day.year,day.month-1,day.day,hour,minute)-9*60*60*1000).toISOString();
}
function busDepartures(schedule:BusSchedule,date:Date,routeFilter?:{from?:string;to?:string}):BusDeparture[]{
  const dateKey=academicDate(date),type=busDayType(date);
  return schedule.routes.filter(route=>(!routeFilter?.from||route.from===routeFilter.from)&&(!routeFilter?.to||route.to===routeFilter.to))
    .flatMap(route=>(route.schedules?.[type]??[]).flatMap(trip=>{const departureAt=busDateTime(date,trip.time);return departureAt?[{...trip,from:route.from,to:route.to,date:dateKey,departureAt,dayType:type}]:[]}))
    .sort((a,b)=>Date.parse(a.departureAt)-Date.parse(b.departureAt));
}
export interface PersonalTodo {
  id:string;title:string;detail:string;url:string;deadline:string|null;
  notificationMode:'none'|'once'|'weekly';notificationDate:string|null;createdAt:string;
  completed:boolean;
  attachments?:{id:string;name:string}[];
}
export interface TodoFields {
  title:string;detail?:string;url?:string;deadline?:string|null;
  notificationMode?:'none'|'once'|'weekly';notificationDate?:string|null;
}
function todoFields(value:TodoFields) {
  if(typeof value.title!=='string'||!value.title.trim()||value.title.length>200)throw new ValidationError('Invalid title');
  const fields={title:value.title.trim(),detail:value.detail??'',url:value.url??'',deadline:value.deadline??null,notificationMode:value.notificationMode??'none',notificationDate:value.notificationDate??null};
  if(typeof fields.detail!=='string'||fields.detail.length>4000||typeof fields.url!=='string'||fields.url.length>2000||!['none','once','weekly'].includes(fields.notificationMode))throw new ValidationError('Invalid ToDo');
  return fields;
}
const todoRows=():Promise<PersonalTodo[]>=>call('cit.query',{query:'todos.data'});
async function setTodoCompletion(id:string,completed:boolean):Promise<PersonalTodo|null>{
  if(typeof id!=='string'||!id||id.length>200)throw new ValidationError('Invalid ToDo ID');
  const expected=(await todoRows()).find(row=>row.id===id);
  if(!expected)return null;
  return call('cit.todo.write',{action:completed?'complete':'uncomplete',id,expected});
}
export const cit = {
  campus: {
    async facilities():Promise<CampusRoom[]>{return campusRooms();},
    async buildings():Promise<{campus:CampusRoom['campus'];building:string;rooms:CampusRoom[]}[]>{
      const rooms=await campusRooms(),groups=new Map<string,{campus:CampusRoom['campus'];building:string;rooms:CampusRoom[]}>();
      for(const room of rooms){const building=room.building??'不明';const key=`${room.campus}:${building}`;const group=groups.get(key)??{campus:room.campus,building,rooms:[]};group.rooms.push(room);groups.set(key,group);}
      return [...groups.values()];
    },
    async rooms():Promise<CampusRoom[]>{return campusRooms();},
    async room(id:string):Promise<CampusRoom|null>{
      if(typeof id!=='string'||!id.trim()||id.length>120)throw new ValidationError('Invalid room ID');
      const needle=roomIdentity(id);return (await campusRooms()).find(room=>room.id===needle)??null;
    },
    async search(query:string):Promise<CampusRoom[]>{
      if(typeof query!=='string'||query.length>120)throw new ValidationError('Invalid search');
      const needle=normalized(query);if(!needle)return campusRooms();
      return (await campusRooms()).filter(room=>normalized(`${room.campus}${room.building??''}${room.floor??''}${room.classroom}`).includes(needle));
    },
    async roomAvailability(roomID:string,at=new Date()):Promise<RoomScheduleStatus>{
      if(typeof roomID!=='string'||!roomID.trim()||roomID.length>120)throw new ValidationError('Invalid room ID');
      if(!(at instanceof Date)||!Number.isFinite(at.getTime()))throw new ValidationError('Invalid date');
      const room=await cit.campus.room(roomID);if(!room)throw new NotFoundError('room_not_found');
      const date=academicDate(at),day=japanDate(at),minute=day.minutes;
      const knownClasses=(await courseRows()).filter(course=>roomIdentity(course.classroom)===room.id&&course.weekday===day.weekday&&course.startMinutes!==null&&course.endMinutes!==null&&minute>=course.startMinutes&&minute<course.endMinutes).map(course=>occurrence(course,day));
      return {room,date,knownClasses,scope:'personal-timetable-only',campusWideAvailability:false};
    }
  },
  services: {
    open: openHostService,
    async list():Promise<CampusService[]> {
      if(!__citContext.capabilities.includes('cit.services.list'))throw new UnsupportedError('services_list_unavailable');
      const snapshot=await call<{serviceTabs?:unknown}>('cit.query',{query:'services.enabled'});
      const titles=(Array.isArray(snapshot.serviceTabs)?snapshot.serviceTabs:[]).filter((title):title is string=>typeof title==='string').map(title=>title.trim()).filter((title,index,all)=>!!title&&title.length<=100&&all.indexOf(title)===index).slice(0,100);
      return titles.map(title=>({title,enabled:true as const}));
    }
  },
  cafeteria: {
    openCamera():Promise<void>{return call('host.navigate',{kind:'cameras',value:'cafeteria'});},
    async locations():Promise<CafeteriaLocation[]>{return call('cit.query',{query:'cafeteria.locations'});},
    async menu():Promise<CafeteriaLocation[]>{return call('cit.query',{query:'cafeteria.menu'});},
    async cameraStatus():Promise<CafeteriaCameraStatus[]>{return call('cit.query',{query:'cafeteria.cameraStatus'});},
    async hours():Promise<CafeteriaHours[]>{return call('cit.query',{query:'cafeteria.hours'});}
  },
  bus: {
    async routes():Promise<BusRoute[]>{return (await busSchedule()).routes;},
    async stops():Promise<string[]>{const routes=await cit.bus.routes();return [...new Set(routes.flatMap(route=>[route.from,route.to]))].sort((a,b)=>a.localeCompare(b,'ja'));},
    async timetable(at=new Date(),routeFilter?:{from?:string;to?:string}):Promise<BusDeparture[]>{
      if(!(at instanceof Date)||!Number.isFinite(at.getTime()))throw new ValidationError('Invalid date');
      if(routeFilter&&((routeFilter.from!==undefined&&(typeof routeFilter.from!=='string'||routeFilter.from.length>80))||(routeFilter.to!==undefined&&(typeof routeFilter.to!=='string'||routeFilter.to.length>80))))throw new ValidationError('Invalid route');
      return busDepartures(await busSchedule(),at,routeFilter);
    },
    async next(from?:string,to?:string,at=new Date()):Promise<BusDeparture|null>{
      if(!(at instanceof Date)||!Number.isFinite(at.getTime()))throw new ValidationError('Invalid date');
      if((from!==undefined&&(typeof from!=='string'||from.length>80))||(to!==undefined&&(typeof to!=='string'||to.length>80)))throw new ValidationError('Invalid route');
      const schedule=await busSchedule();
      for(let offset=0;offset<8;offset++){
        const day=japanDate(at,offset),localDate=new Date(Date.UTC(day.year,day.month-1,day.day,12)-9*60*60*1000);
        const next=busDepartures(schedule,localDate,{from,to}).find(item=>Date.parse(item.departureAt)>at.getTime());
        if(next)return next;
      }
      return null;
    },
    async between(start:Date,end:Date,routeFilter?:{from?:string;to?:string}):Promise<BusDeparture[]>{
      if(!(start instanceof Date)||!(end instanceof Date)||!Number.isFinite(start.getTime())||!Number.isFinite(end.getTime())||start.getTime()>end.getTime())throw new ValidationError('Invalid date range');
      const first=japanDate(start),last=japanDate(end),span=Math.round((Date.UTC(last.year,last.month-1,last.day)-Date.UTC(first.year,first.month-1,first.day))/86400000);
      if(span>366)throw new ValidationError('Date range too large');
      const schedule=await busSchedule(),result:BusDeparture[]=[];
      for(let offset=0;offset<=span;offset++){
        const day=japanDate(start,offset),localDate=new Date(Date.UTC(day.year,day.month-1,day.day,12)-9*60*60*1000);
        result.push(...busDepartures(schedule,localDate,routeFilter).filter(item=>Date.parse(item.departureAt)>=start.getTime()&&Date.parse(item.departureAt)<=end.getTime()));
      }
      return result.sort((a,b)=>Date.parse(a.departureAt)-Date.parse(b.departureAt));
    },
    async serviceStatus(at=new Date()):Promise<BusServiceStatus>{
      if(!(at instanceof Date)||!Number.isFinite(at.getTime()))throw new ValidationError('Invalid date');
      const schedule=await busSchedule(),date=academicDate(at);
      return {title:schedule.title,note:schedule.note??null,date,validFrom:schedule.validPeriod.from,validTo:schedule.validPeriod.to,inServicePeriod:date>=schedule.validPeriod.from&&date<=schedule.validPeriod.to,dayType:busDayType(at),routeCount:schedule.routes.length};
    }
  },
  courseNotes: {
    create: (title:string,content:string):Promise<{id:string;courseKey:string;content:string}|null> => call('cit.courseNotes.write',{id:title,content,expected:null}),
    update: (id:string,content:string,expectedContent:string):Promise<{id:string;courseKey:string;content:string}|null> => call('cit.courseNotes.write',{id,content,expected:expectedContent}),
    delete: (id:string,expectedContent:string):Promise<null> => call('cit.courseNotes.write',{id,content:'',expected:expectedContent}),
    list: (): Promise<{id:string;courseKey:string;content:string}[]> => call('cit.query', {query:'courseNotes.data'}),
    async get(id:string): Promise<{id:string;courseKey:string;content:string}|null> {
      if(typeof id!=='string'||!id||id.length>1000)throw new ValidationError('Invalid course note ID');
      return (await cit.courseNotes.list()).find(note=>note.id===id)??null;
    }
  },
  courses: {
    list: courseRows,
    async get(id: string): Promise<Course | null> {
      if(typeof id!=='string'||!id||id.length>1000)throw new ValidationError('Invalid course ID');
      return (await courseRows()).find(row=>row.id===id)??null;
    },
    async search(query: string): Promise<Course[]> { if(typeof query!=='string'||query.length>4000)throw new ValidationError('Invalid search'); const needle = normalized(query); return (await courseRows()).filter(row => normalized(row.name + row.classroom + (row.teacher??'')).includes(needle)); },
    async byWeekday(weekday:number):Promise<Course[]> {
      if(!Number.isInteger(weekday)||weekday<0||weekday>6)throw new ValidationError('Invalid weekday');
      return (await courseRows()).filter(row=>row.weekday===weekday).sort((a,b)=>(a.startMinutes??1440)-(b.startMinutes??1440));
    },
    async forPeriod(weekday:number,period:string):Promise<Course[]> {
      if(!Number.isInteger(weekday)||weekday<0||weekday>6||typeof period!=='string'||!period.trim()||period.length>80)throw new ValidationError('Invalid period');
      return (await courseRows()).filter(row=>row.weekday===weekday&&row.period===period);
    },
    async today(at = new Date()): Promise<Course[]> { const clock = japanClock(at); return (await courseRows()).filter(row => row.weekday === clock.weekday); },
    async current(at = new Date()): Promise<Course[]> {
      const clock = japanClock(at);
      return (await courseRows()).filter(row => row.weekday === clock.weekday && row.startMinutes !== null && row.endMinutes !== null && row.startMinutes <= clock.minutes && clock.minutes < row.endMinutes);
    },
    async next(at = new Date()): Promise<Course | null> {
      const clock = japanClock(at);
      const distance = (row: Course) => ((row.weekday - clock.weekday + 7) % 7) * 1440 + (row.startMinutes ?? 0) - clock.minutes;
      const nextDistance = (row: Course) => distance(row) <= 0 ? distance(row) + 10080 : distance(row);
      return (await courseRows()).filter(row => row.startMinutes !== null).sort((a,b) => nextDistance(a) - nextDistance(b))[0] ?? null;
    }
  },
  timetable: {
    periods:periodRows,
    async today(at=new Date()):Promise<CourseOccurrence[]>{return scheduleAt(at);},
    async tomorrow(at=new Date()):Promise<CourseOccurrence[]>{const day=japanDate(at,1);return scheduleAt(new Date(Date.UTC(day.year,day.month-1,day.day,12)-9*60*60*1000));},
    async at(date:Date):Promise<CourseOccurrence[]>{return scheduleAt(date);},
    async week(at=new Date()):Promise<CourseOccurrence[]>{
      const local=japanDate(at);
      const mondayOffset=-((local.weekday+6)%7);
      const rows=await courseRows();
      const result:CourseOccurrence[]=[];
      for(let offset=mondayOffset;offset<mondayOffset+7;offset++){
        const day=japanDate(at,offset);
        for(const course of rows)if(course.weekday===day.weekday)result.push(occurrence(course,day));
      }
      return result.sort((a,b)=>(a.startAt?Date.parse(a.startAt):Number.MAX_SAFE_INTEGER)-(b.startAt?Date.parse(b.startAt):Number.MAX_SAFE_INTEGER));
    },
    async current(at=new Date()):Promise<CourseOccurrence[]>{
      const now=at.getTime();
      return (await scheduleAt(at)).filter(row=>row.startAt!==null&&row.endAt!==null&&Date.parse(row.startAt)<=now&&now<Date.parse(row.endAt));
    },
    async next(at=new Date()):Promise<CourseOccurrence|null>{
      const now=at.getTime();
      const rows=await courseRows();
      for(let offset=0;offset<8;offset++){
        const day=japanDate(at,offset);
        const next=rows.filter(course=>course.weekday===day.weekday).map(course=>occurrence(course,day)).filter(row=>row.startAt!==null&&Date.parse(row.startAt)>now).sort((a,b)=>Date.parse(a.startAt!)-Date.parse(b.startAt!))[0];
        if(next)return next;
      }
      return null;
    },
    async freePeriods(weekday=japanClock(new Date()).weekday):Promise<PeriodSlot[]> {
      if(!Number.isInteger(weekday)||weekday<0||weekday>6)throw new ValidationError('Invalid weekday');
      const [periods,courses]=await Promise.all([periodRows(),courseRows()]);
      const occupied=new Set(courses.filter(course=>course.weekday===weekday).map(course=>course.period));
      return periods.filter(slot=>slot.weekday===weekday&&!occupied.has(slot.period)).sort((a,b)=>a.periodIndex-b.periodIndex);
    }
  },
  assignments: {
    list: taskRows,
    async get(id:string):Promise<Task|null>{if(typeof id!=='string'||!id||id.length>300)throw new ValidationError('Invalid assignment ID');return (await taskRows()).find(row=>row.id===id)??null;},
    async pending(at=new Date()):Promise<Task[]>{japanClock(at);return (await taskRows()).filter(row=>row.deadline===null||Date.parse(row.deadline)>=at.getTime());},
    async search(query: string): Promise<Task[]> { if(typeof query!=='string'||query.length>4000)throw new ValidationError('Invalid search');const needle = normalized(query); return (await taskRows()).filter(row => normalized(row.title + row.course + row.type).includes(needle)); },
    async byCourse(course:string):Promise<Task[]>{if(typeof course!=='string'||!course.trim()||course.length>200)throw new ValidationError('Invalid course');const needle=normalized(course);return (await taskRows()).filter(row=>normalized(row.course).includes(needle));},
    async between(start:Date,end:Date):Promise<Task[]>{japanClock(start);japanClock(end);if(start.getTime()>end.getTime())throw new ValidationError('Invalid date range');return (await taskRows()).filter(row=>row.deadline!==null&&Date.parse(row.deadline)>=start.getTime()&&Date.parse(row.deadline)<=end.getTime());},
    async overdue(at = new Date()): Promise<Task[]> { japanClock(at); return (await taskRows()).filter(row => row.deadline !== null && Date.parse(row.deadline) < at.getTime()); },
    async dueSoon(days = 7, at = new Date()): Promise<Task[]> {
      japanClock(at); if (!Number.isFinite(days) || days < 0 || days > 366) throw new ValidationError('Invalid days');
      return (await taskRows()).filter(row => row.deadline !== null && Date.parse(row.deadline) >= at.getTime() && Date.parse(row.deadline) <= at.getTime() + days * 86400000);
    }
  },
  todo: {
    list:todoRows,
    create:(fields:TodoFields):Promise<PersonalTodo>=>call('cit.todo.write',{action:'create',fields:todoFields(fields)}),
    update:(expected:PersonalTodo,fields:TodoFields):Promise<PersonalTodo>=>call('cit.todo.write',{action:'update',id:expected.id,expected,fields:todoFields(fields)}),
    async complete(id:string):Promise<PersonalTodo|null>{return setTodoCompletion(id,true);},
    async uncomplete(id:string):Promise<PersonalTodo|null>{return setTodoCompletion(id,false);},
    delete:(expected:PersonalTodo):Promise<null>=>call('cit.todo.write',{action:'delete',id:expected.id,expected}),
    async get(id:string):Promise<PersonalTodo|null> {
      if(typeof id!=='string'||!id||id.length>200)throw new ValidationError('Invalid ToDo ID');
      return (await todoRows()).find(row=>row.id===id)??null;
    },
    async search(query:string):Promise<PersonalTodo[]> {
      if(typeof query!=='string'||query.length>4000)throw new ValidationError('Invalid search');
      const needle=normalized(query);
      return (await todoRows()).filter(row=>normalized(row.title+' '+row.detail).includes(needle));
    },
    watch(callback:(rows:PersonalTodo[])=>void,onError?:(error:unknown)=>void):()=>void {
      let active=true,suspended=false,running=false,timer:ReturnType<typeof setTimeout>|undefined,previous:string|undefined;
      const schedule=()=>{if(active&&!suspended&&timer===undefined)timer=setTimeout(()=>{timer=undefined;void refresh();},2000);};
      const refresh=async()=>{
        if(!active||suspended||running)return;
        running=true;
        try {
          const rows=await todoRows();
          if(active&&!suspended){const json=JSON.stringify(rows);if(json!==previous){previous=json;callback(rows);}}
        }catch(error){if(active&&!suspended)onError?.(error);}
        finally{running=false;schedule();}
      };
      const pause=()=>{suspended=true;if(timer!==undefined)clearTimeout(timer);timer=undefined;};
      const cleanup: (()=>void)[]=[];
      const stop=()=>{active=false;pause();cleanup.forEach(remove=>remove());};
      cleanup.push(app.onSuspend(pause),app.onResume(()=>{suspended=false;void refresh();}),app.onDisappear(stop));
      timer=setTimeout(()=>{timer=undefined;void refresh();},10);
      return stop;
    }
  },
  settings: {
    language: (): Promise<string> => call('cit.query', { query: 'settings.language' }),
    appearance: async (): Promise<Pick<UserPreferences,'accentColor'>> => ({accentColor:(await userPreferences()).accentColor}),
    notifications: async (): Promise<UserPreferences['notifications']> => (await userPreferences()).notifications,
    enabledServices: async (): Promise<string[]> => (await userPreferences()).enabledServices
  },
  user: {
    preferences: userPreferences,
    displayName(): Promise<string | null> { return call('cit.query', { query: 'profile.displayName' }); }
  },
  academicCalendar: {
    list: academicCalendarRows,
    async on(date:Date):Promise<AcademicCalendarEvent[]> { const day=academicDate(date); return (await academicCalendarRows()).filter(event=>event.start<=day&&day<=event.end); },
    async between(start:Date,end:Date):Promise<AcademicCalendarEvent[]> {
      const from=academicDate(start),to=academicDate(end);
      if(from>to)throw new ValidationError('Invalid date range');
      return (await academicCalendarRows()).filter(event=>event.end>=from&&event.start<=to);
    },
    async isClassDay(date:Date):Promise<boolean|null> {
      const day=academicDate(date);
      const events=await academicCalendarRows();
      if(events.some(event=>event.start<=day&&day<=event.end&&(event.kind==='vacation'||event.kind==='class_suspension')))return false;
      if(events.some(event=>event.start<=day&&day<=event.end&&/授業日/.test(event.title)))return true;
      const weekday=japanDate(date).weekday;
      return (await courseRows()).some(course=>course.weekday===weekday)?true:null;
    }
  },
  // Calendar naming follows the public SDK surface while academicCalendar remains
  // available for extensions built against earlier SDK releases.
  calendar: {
    currentSemester: ():Promise<string|null> => cit.semester.current(),
    events: academicCalendarRows,
    async holidays(start?:Date,end?:Date):Promise<AcademicCalendarEvent[]> {
      if ((start === undefined) !== (end === undefined)) throw new ValidationError('Both range dates are required');
      const events = start && end ? await cit.academicCalendar.between(start,end) : await academicCalendarRows();
      return events.filter(event => event.kind === 'vacation' || /祝日|休日/.test(event.title));
    },
    async classDays(start:Date,end:Date):Promise<string[]> {
      if (!(start instanceof Date) || !(end instanceof Date) || !Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || start.getTime() > end.getTime()) throw new ValidationError('Invalid date range');
      const first = japanDate(start), last = japanDate(end);
      const span = Math.floor((Date.UTC(last.year,last.month-1,last.day)-Date.UTC(first.year,first.month-1,first.day))/86400000);
      if (span > 366) throw new ValidationError('Date range too large');
      const [events,courses]=await Promise.all([academicCalendarRows(),courseRows()]);
      const results:string[]=[];
      for(let offset=0;offset<=span;offset++) {
        const day = japanDate(start,offset);
        const date = new Date(Date.UTC(day.year,day.month-1,day.day,12)-9*60*60*1000);
        const key=academicDate(date);
        if(events.some(event=>event.start<=key&&key<=event.end&&(event.kind==='vacation'||event.kind==='class_suspension')))continue;
        if(events.some(event=>event.start<=key&&key<=event.end&&/授業日/.test(event.title))||courses.some(course=>course.weekday===day.weekday))results.push(key);
      }
      return results;
    },
    isClassDay: (date:Date):Promise<boolean|null> => cit.academicCalendar.isClassDay(date),
    weekNumber(date:Date):number {
      if (!(date instanceof Date) || !Number.isFinite(date.getTime())) throw new ValidationError('Invalid date');
      const local=japanDate(date);
      const day=new Date(Date.UTC(local.year,local.month-1,local.day));
      day.setUTCDate(day.getUTCDate()+4-(day.getUTCDay()||7));
      const yearStart=new Date(Date.UTC(day.getUTCFullYear(),0,1));
      return Math.ceil((((day.getTime()-yearStart.getTime())/86400000)+1)/7);
    }
  },
  semester: {
    async list():Promise<string[]> {
      return [...new Set((await courseRows()).map(course=>course.term.trim()).filter(Boolean))];
    },
    async current():Promise<string|null> {
      return (await courseRows()).map(course=>course.term.trim()).find(Boolean)??null;
    }
  }
};
export const connectivity = { status: network.status, onChange: network.onChange };
export const cloud = { user: cloudUser, shared };
export const webView = { open: browser.open };
