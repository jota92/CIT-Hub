import { ValidationError, NetworkError, parseHTTPSURL, parseOAuthCallback } from './core';
import { app, browser, network, secureStorage } from './host';
import { crypto, type RS256JWK } from './crypto';

export interface OAuthProvider {
  authorizationEndpoint:string;
  tokenEndpoint:string;
  clientId:string;
  scopes:string[];
  redirectUri?:string;
}
export interface OAuthSession { accessToken:string; tokenType:string; expiresAt:number|null; scopes:string[] }
export interface OIDCSession extends OAuthSession { identity:{subject:string;issuer:string} }
interface StoredOAuthSession { accessToken:string; refreshToken?:string; tokenType:string; expiresAt:number|null; scopes:string[]; tokenEndpoint:string; clientId:string; idToken?:string }
const redirectDefault='cithub://extensions/oauth';
const storageKey='oauth.session';
const authFlows=new Map<string,(url:string)=>void>();
app.onOpenURL(({url})=>{
  const parsed=parseOAuthCallback(url);
  if(parsed) authFlows.get(parsed.state)?.(url);
});
function validateEndpoint(value:string):NonNullable<ReturnType<typeof parseHTTPSURL>> {
  const parsed=parseHTTPSURL(value,2048);
  if(!parsed||parsed.hash)throw new ValidationError('oauth_endpoint_invalid');
  return parsed;
}
function validateProvider(provider:OAuthProvider):OAuthProvider {
  const authorization=validateEndpoint(provider?.authorizationEndpoint),token=validateEndpoint(provider?.tokenEndpoint);
  if(!/^[A-Za-z0-9._~+-]{1,200}$/.test(provider.clientId)||!Array.isArray(provider.scopes)||provider.scopes.length<1||provider.scopes.length>20||provider.scopes.some(scope=>typeof scope!=='string'||!/^[A-Za-z0-9:._/-]{1,80}$/.test(scope)))throw new ValidationError('oauth_provider_invalid');
  const redirectUri=provider.redirectUri??redirectDefault;
  if(redirectUri!==redirectDefault)throw new ValidationError('oauth_redirect_uri_not_allowed');
  if(authorization.origin===token.origin&&authorization.pathname===token.pathname)throw new ValidationError('oauth_endpoint_invalid');
  return {...provider,authorizationEndpoint:authorization.href,tokenEndpoint:token.href,redirectUri};
}
function b64url(bytes:Uint8Array):string { const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';let out='';for(let i=0;i<bytes.length;i+=3){const a=bytes[i],b=bytes[i+1],c=bytes[i+2];out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b===undefined?0:b>>4)];if(b!==undefined)out+=alphabet[((b&15)<<2)|(c===undefined?0:c>>6)];if(c!==undefined)out+=alphabet[c&63]}return out; }
function sha256Base64URL(value:string):string {
  const constants=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const bytes:number[]=[];
  for(const character of value){const point=character.codePointAt(0)!;if(point<0x80)bytes.push(point);else if(point<0x800)bytes.push(0xc0|(point>>6),0x80|(point&63));else if(point<0x10000)bytes.push(0xe0|(point>>12),0x80|((point>>6)&63),0x80|(point&63));else bytes.push(0xf0|(point>>18),0x80|((point>>12)&63),0x80|((point>>6)&63),0x80|(point&63));}
  const bitLength=bytes.length*8;bytes.push(0x80);while(bytes.length%64!==56)bytes.push(0);bytes.push(0,0,0,0,(bitLength>>>24)&255,(bitLength>>>16)&255,(bitLength>>>8)&255,bitLength&255);
  const hash=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const rotate=(number:number,bits:number)=>(number>>>bits)|(number<<(32-bits));
  for(let offset=0;offset<bytes.length;offset+=64){const words=new Array<number>(64);for(let i=0;i<16;i++)words[i]=((bytes[offset+i*4]<<24)|(bytes[offset+i*4+1]<<16)|(bytes[offset+i*4+2]<<8)|bytes[offset+i*4+3])>>>0;for(let i=16;i<64;i++){const x=words[i-15],y=words[i-2],s0=rotate(x,7)^rotate(x,18)^(x>>>3),s1=rotate(y,17)^rotate(y,19)^(y>>>10);words[i]=(words[i-16]+s0+words[i-7]+s1)>>>0;}
    let [a,b,c,d,e,f,g,h]=hash;
    for(let i=0;i<64;i++){const s1=rotate(e,6)^rotate(e,11)^rotate(e,25),choice=(e&f)^(~e&g),t1=(h+s1+choice+constants[i]+words[i])>>>0,s0=rotate(a,2)^rotate(a,13)^rotate(a,22),majority=(a&b)^(a&c)^(b&c),t2=(s0+majority)>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}
    hash[0]=(hash[0]+a)>>>0;hash[1]=(hash[1]+b)>>>0;hash[2]=(hash[2]+c)>>>0;hash[3]=(hash[3]+d)>>>0;hash[4]=(hash[4]+e)>>>0;hash[5]=(hash[5]+f)>>>0;hash[6]=(hash[6]+g)>>>0;hash[7]=(hash[7]+h)>>>0;
  }
  const digest=new Uint8Array(32);for(let i=0;i<hash.length;i++){digest[i*4]=hash[i]>>>24;digest[i*4+1]=hash[i]>>>16;digest[i*4+2]=hash[i]>>>8;digest[i*4+3]=hash[i];}return b64url(digest);
}
function form(data:Record<string,string>):string{return Object.entries(data).map(([key,value])=>`${encodeURIComponent(key)}=${encodeURIComponent(value)}`).join('&');}
function parseTokenResponse(body:string,provider:OAuthProvider,prior?:StoredOAuthSession):StoredOAuthSession {
  let value:Record<string,unknown>;try{value=JSON.parse(body)}catch{throw new NetworkError('oauth_token_response_invalid')}
  if(typeof value.access_token!=='string'||value.access_token.length>16000)throw new NetworkError('oauth_token_response_invalid');
  const expires=Number(value.expires_in),expiresAt=Number.isFinite(expires)&&expires>0?Date.now()+Math.min(expires,31536000)*1000:null;
  const scopes=typeof value.scope==='string'?value.scope.split(/\s+/).filter(Boolean):provider.scopes;
  return {accessToken:value.access_token,refreshToken:typeof value.refresh_token==='string'?value.refresh_token:prior?.refreshToken,tokenType:typeof value.token_type==='string'?value.token_type:'Bearer',expiresAt,scopes,tokenEndpoint:provider.tokenEndpoint,clientId:provider.clientId,...(typeof value.id_token==='string'&&value.id_token.length<=24000?{idToken:value.id_token}:{})};
}
async function exchange(provider:OAuthProvider,body:Record<string,string>,prior?:StoredOAuthSession):Promise<StoredOAuthSession>{
  const response=await network.fetch(provider.tokenEndpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},body:form(body)});
  if(!response.ok)throw new NetworkError(`oauth_token_http_${response.status}`);
  return parseTokenResponse(response.body,provider,prior);
}
function publicSession(value:StoredOAuthSession):OAuthSession{return {accessToken:value.accessToken,tokenType:value.tokenType,expiresAt:value.expiresAt,scopes:[...value.scopes]};}
async function persist(session:StoredOAuthSession):Promise<void>{const {idToken:_idToken,...stored}=session;await secureStorage.set(storageKey,stored);}
async function authorize(provider:OAuthProvider,nonce?:string):Promise<StoredOAuthSession>{
  const state=b64url(crypto.randomBytes(32)),verifier=b64url(crypto.randomBytes(48)),challenge=sha256Base64URL(verifier);
  const callback=new Promise<string>((resolve,reject)=>{const timer=setTimeout(()=>{authFlows.delete(state);reject(new NetworkError('oauth_authorization_timeout'));},5*60*1000);authFlows.set(state,url=>{clearTimeout(timer);authFlows.delete(state);resolve(url)});});
  const authorizationURL=parseHTTPSURL(provider.authorizationEndpoint,2048);
  if(!authorizationURL||authorizationURL.hash)throw new ValidationError('oauth_endpoint_invalid');
  const parameters:Record<string,string>={response_type:'code',client_id:provider.clientId,redirect_uri:provider.redirectUri!,scope:provider.scopes.join(' '),state,code_challenge:challenge,code_challenge_method:'S256',...(nonce?{nonce}:{})};
  const existingParameters=authorizationURL.search ? authorizationURL.search.slice(1).split('&').filter(Boolean) : [];
  const reservedParameters=new Set(['response_type','client_id','redirect_uri','scope','state','code_challenge','code_challenge_method','nonce']);
  for(const item of existingParameters){
    const rawKey=item.split('=',1)[0];
    let key:string;try{key=decodeURIComponent(rawKey.replace(/\+/g,' '));}catch{throw new ValidationError('oauth_endpoint_invalid');}
    if(reservedParameters.has(key))throw new ValidationError('oauth_endpoint_invalid');
  }
  const appended=Object.entries(parameters).map(([key,value])=>`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
  const authorizationHref=`${authorizationURL.origin}${authorizationURL.pathname}?${[...existingParameters,...appended].join('&')}`;
  try{
    const browserLaunch=browser.openExternal(authorizationHref);
    const existing=await secureStorage.get<StoredOAuthSession>(storageKey);
    await secureStorage.set(`${storageKey}.pending`,{state,verifier,startedAt:Date.now()});
    await browserLaunch;
    const returned=parseOAuthCallback(await callback);if(!returned||returned.state!==state)throw new NetworkError('oauth_state_mismatch');
    if(returned.error)throw new NetworkError(`oauth_authorization_${returned.error.slice(0,60)}`);
    const code=returned.code;if(!code)throw new NetworkError('oauth_authorization_code_missing');
    const session=await exchange(provider,{grant_type:'authorization_code',code,client_id:provider.clientId,redirect_uri:provider.redirectUri!,code_verifier:verifier},existing??undefined);
    await secureStorage.delete(`${storageKey}.pending`);return session;
  }catch(error){authFlows.delete(state);await secureStorage.delete(`${storageKey}.pending`).catch(()=>{});throw error;}
}
async function verifyIDToken(token:string,issuer:string,clientId:string,nonce:string,jwksURL:string):Promise<{subject:string;issuer:string}>{
  if(typeof token!=='string'||token.length>24000)throw new NetworkError('oidc_id_token_missing');
  const response=await network.fetch(jwksURL,{headers:{Accept:'application/json'}});if(!response.ok)throw new NetworkError(`oidc_jwks_http_${response.status}`);
  let jwks:{keys?:RS256JWK[]};try{jwks=JSON.parse(response.body)}catch{throw new NetworkError('oidc_jwks_invalid')}
  if(!Array.isArray(jwks.keys)||jwks.keys.length>64)throw new NetworkError('oidc_jwks_invalid');
  return crypto.verifyOIDCToken(token,{issuer,clientId,nonce},jwks.keys);
}
export const auth={
  async oauth2(providerInput:OAuthProvider):Promise<OAuthSession>{
    const session=await authorize(validateProvider(providerInput));await persist(session);return publicSession(session);
  },
  async openIDConnect(config:{issuer:string;clientId:string;scopes:string[]}):Promise<OIDCSession>{
    const issuerURL=validateEndpoint(config?.issuer),issuer=issuerURL.href,clientId=config.clientId;
    if(!/^[A-Za-z0-9._~+-]{1,200}$/.test(clientId)||!Array.isArray(config.scopes)||config.scopes.length>19||config.scopes.some(scope=>typeof scope!=='string'||!/^[A-Za-z0-9:._/-]{1,80}$/.test(scope)))throw new ValidationError('oidc_config_invalid');
    const discoveryResponse=await network.fetch(`${issuer.replace(/\/+$/,'')}/.well-known/openid-configuration`,{headers:{Accept:'application/json'}});
    if(!discoveryResponse.ok)throw new NetworkError(`oidc_discovery_http_${discoveryResponse.status}`);
    let discovery:Record<string,unknown>;try{discovery=JSON.parse(discoveryResponse.body)}catch{throw new NetworkError('oidc_discovery_invalid')}
    if(discovery.issuer!==issuer||typeof discovery.authorization_endpoint!=='string'||typeof discovery.token_endpoint!=='string'||typeof discovery.jwks_uri!=='string'||!Array.isArray(discovery.id_token_signing_alg_values_supported)||!discovery.id_token_signing_alg_values_supported.includes('RS256'))throw new NetworkError('oidc_discovery_invalid');
    const provider=validateProvider({authorizationEndpoint:discovery.authorization_endpoint,tokenEndpoint:discovery.token_endpoint,clientId,scopes:[...new Set(['openid',...config.scopes])]}),jwksURL=validateEndpoint(discovery.jwks_uri).href,nonce=b64url(crypto.randomBytes(32));
    const session=await authorize(provider,nonce);if(!session.idToken)throw new NetworkError('oidc_id_token_missing');
    const identity=await verifyIDToken(session.idToken,issuer,clientId,nonce,jwksURL);await persist(session);
    return {...publicSession(session),identity};
  },
  async tokenStatus():Promise<{connected:boolean;expiresAt:number|null;scopes:string[]}>{
    const session=await secureStorage.get<StoredOAuthSession>(storageKey);
    if(!session||typeof session.accessToken!=='string')return {connected:false,expiresAt:null,scopes:[]};
    return {connected:session.expiresAt===null||session.expiresAt>Date.now(),expiresAt:session.expiresAt,scopes:[...session.scopes]};
  },
  async logout():Promise<void>{authFlows.clear();await secureStorage.delete(storageKey);await secureStorage.delete(`${storageKey}.pending`);},
  async refresh():Promise<OAuthSession>{
    const session=await secureStorage.get<StoredOAuthSession>(storageKey);
    if(!session?.refreshToken)throw new NetworkError('oauth_refresh_token_unavailable');
    const provider={authorizationEndpoint:session.tokenEndpoint,tokenEndpoint:session.tokenEndpoint,clientId:session.clientId,scopes:session.scopes,redirectUri:redirectDefault};
    // Refresh uses the same trusted token endpoint and never opens a browser.
    const response=await network.fetch(provider.tokenEndpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},body:form({grant_type:'refresh_token',refresh_token:session.refreshToken,client_id:session.clientId})});
    if(!response.ok)throw new NetworkError(`oauth_token_http_${response.status}`);
    return publicSession(await (async()=>{const updated=parseTokenResponse(response.body,provider,session);await secureStorage.set(storageKey,updated);return updated})());
  }
};
