import { state, type State, ValidationError } from './core';
import { keyboard } from './keyboard';
export interface FieldState<T> extends State<T> { readonly key: string; focus(): Promise<void>; blur(): Promise<void> }
export const field = {
  create<T>(key: string, initial: T): FieldState<T> {
    if (!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key)) throw new ValidationError('field_key_invalid');
    const value = state.create(initial);
    return { ...value, get value() { return value.value; }, key, focus: () => keyboard.focus(key), blur: () => keyboard.dismiss() };
  }
};
