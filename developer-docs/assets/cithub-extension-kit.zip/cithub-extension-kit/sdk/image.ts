import { ValidationError } from './core';
import { call, type ScannedDocumentInfo } from './host';
export type ImageSource = { key: string } | { bytes: Uint8Array };
export interface ImageResult { name: string; width: number; height: number; size: number; mimeType: 'image/jpeg' | 'image/png' }
export interface ImageOptions { quality?: number; format?: 'jpeg' | 'png' }
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function source(value: ImageSource): { key: string } | { data: string } {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).length !== 1) throw new ValidationError('image_source_invalid');
  if ('key' in value) {
    if (typeof value.key !== 'string' || !/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(value.key)) throw new ValidationError('image_source_invalid');
    return { key: value.key };
  }
  if (!(value.bytes instanceof Uint8Array) || !value.bytes.length || value.bytes.length > 262144) throw new ValidationError('image_source_invalid');
  let data = '';
  for (let i = 0; i < value.bytes.length; i += 3) {
    const a = value.bytes[i], b = value.bytes[i + 1] ?? 0, c = value.bytes[i + 2] ?? 0;
    data += alphabet[a >> 2] + alphabet[((a & 3) << 4) | (b >> 4)] + (i + 1 < value.bytes.length ? alphabet[((b & 15) << 2) | (c >> 6)] : '=') + (i + 2 < value.bytes.length ? alphabet[c & 63] : '=');
  }
  return { data };
}
async function process(input: ImageSource, name: string, operation: string, parameters: Record<string, unknown> = {}, options: ImageOptions = {}): Promise<ImageResult> {
  if (typeof name !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$/.test(name) || name.includes('..')) throw new ValidationError('file_name_invalid');
  const quality = options.quality ?? 0.8, format = options.format ?? 'jpeg';
  if (!Number.isFinite(quality) || quality < 0.1 || quality > 1 || !['jpeg', 'png'].includes(format)) throw new ValidationError('image_options_invalid');
  return call<ImageResult>('image.process', { source: source(input), name, action: operation, quality, format, ...parameters });
}
const dimension = (value: number): number => { if (!Number.isInteger(value) || value < 1 || value > 2048) throw new ValidationError('image_dimension_invalid'); return value; };
export const image = {
  scanDocument(options:{name?:string;maxPages?:number}={}):Promise<ScannedDocumentInfo|null>{
    const name=options.name??`scan_${Date.now().toString(36)}.pdf`;
    if(typeof name!=='string'||!name.toLowerCase().endsWith('.pdf')||!Number.isInteger(options.maxPages??10)||(options.maxPages??10)<1||(options.maxPages??10)>50)throw new ValidationError('document_scan_options_invalid');
    return call<ScannedDocumentInfo|null>('scanner.document',{name,maxPages:options.maxPages??10});
  },
  resize: (input: ImageSource, name: string, width: number, height: number, options?: ImageOptions): Promise<ImageResult> => process(input, name, 'resize', { width: dimension(width), height: dimension(height) }, options),
  crop(input: ImageSource, name: string, rectangle: { x: number; y: number; width: number; height: number }, options?: ImageOptions): Promise<ImageResult> {
    if (!rectangle || Object.keys(rectangle).length !== 4 || ![rectangle.x, rectangle.y, rectangle.width, rectangle.height].every(value => typeof value === 'number' && Number.isFinite(value)) || rectangle.x < 0 || rectangle.y < 0 || rectangle.width <= 0 || rectangle.height <= 0 || rectangle.x + rectangle.width > 1 || rectangle.y + rectangle.height > 1)
      throw new ValidationError('image_crop_invalid');
    return process(input, name, 'crop', rectangle, options);
  },
  rotate(input: ImageSource, name: string, degrees: 0 | 90 | 180 | 270, options?: ImageOptions): Promise<ImageResult> {
    if (![0, 90, 180, 270].includes(degrees)) throw new ValidationError('image_rotation_invalid');
    return process(input, name, 'rotate', { degrees }, options);
  },
  flip(input: ImageSource, name: string, axis: 'horizontal' | 'vertical', options?: ImageOptions): Promise<ImageResult> {
    if (!['horizontal', 'vertical'].includes(axis)) throw new ValidationError('image_axis_invalid');
    return process(input, name, 'flip', { axis }, options);
  },
  compress: (input: ImageSource, name: string, quality = 0.6): Promise<ImageResult> => process(input, name, 'convert', {}, { quality }),
  convert: (input: ImageSource, name: string, format: 'jpeg' | 'png', quality = 0.8): Promise<ImageResult> => process(input, name, 'convert', {}, { format, quality }),
  thumbnail: (input: ImageSource, name: string, maxDimension = 256): Promise<ImageResult> => process(input, name, 'thumbnail', { maxDimension: dimension(maxDimension) }),
  removeMetadata: (input: ImageSource, name: string, options?: ImageOptions): Promise<ImageResult> => process(input, name, 'convert', {}, options)
};
