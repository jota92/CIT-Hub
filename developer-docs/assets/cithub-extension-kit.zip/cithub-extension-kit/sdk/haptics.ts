import { UnsupportedError, ValidationError } from './core';

declare const __citCall: (request:string) => Promise<string>;
async function feedback(kind:string):Promise<void> {
  const reply=JSON.parse(await __citCall(JSON.stringify({operation:'haptics.feedback',args:{kind}})));
  if(reply.error==='unsupported')throw new UnsupportedError(reply.error);
  if(reply.error)throw new ValidationError(reply.error);
}
export const haptics = {
  light:()=>feedback('light'),
  medium:()=>feedback('medium'),
  heavy:()=>feedback('heavy'),
  success:()=>feedback('success'),
  warning:()=>feedback('warning'),
  error:()=>feedback('error')
};
