import type { Extension, Node } from './index';
import { emitLifecycle } from './host';
import type { State } from './core';
export interface Program extends Extension { program: { render(): Node[] } }
export function defineProgram(value: Omit<Extension, 'schemaVersion' | 'content'> & { render(): Node[] }): Program {
  const { render, ...metadata } = value;
  return { schemaVersion: 1, ...metadata, content: [{ type: 'text', text: '拡張機能を起動しています。' }], program: { render } };
}
const callbacks = new Map<string, (payload: unknown) => unknown>();
const failureMessage = (error: unknown) => error instanceof Error ? error.message : String(error);
const bindings = new WeakMap<object, Map<string,string>>();
const buttonBindings = new Map<string,string>();
const buttonOccurrences = new Map<string,number>();
let pendingAnimation: { duration: number; curve: string; damping: number } | undefined;
let nextID = 0;
function bind(key: string, value: object, callback: (payload: unknown) => unknown): string {
  let keys = bindings.get(value);
  if (!keys) { keys = new Map(); bindings.set(value, keys); }
  let id = keys.get(key);
  if (!id) { id = String(++nextID); keys.set(key,id); }
  callbacks.set(id,callback); return id;
}
export const interactive = {
  textField(key: string, label: string, value: State<string>, events: { onFocus?: () => unknown; onBlur?: () => unknown; onSubmit?: () => unknown } = {}): Node {
    const onChange = bind(key,value,payload => { if(typeof payload !== 'string' || payload.length > 4000)throw Error('input_invalid');value.set(payload); });
    const onFocus = events.onFocus ? bind(`focus:${key}`,value,() => events.onFocus?.()) : undefined;
    const onBlur = events.onBlur ? bind(`blur:${key}`,value,() => events.onBlur?.()) : undefined;
    const onSubmit = events.onSubmit ? bind(`submit:${key}`,value,() => events.onSubmit?.()) : undefined;
    return {type:'field',key,label,value:value.value,onChange,...(onFocus?{onFocus}:{}),...(onBlur?{onBlur}:{}),...(onSubmit?{onSubmit}:{})};
  },
  textArea(key: string, label: string, value: State<string>): Node {
    const onChange = bind(key,value,payload => { if(typeof payload !== 'string' || payload.length > 4000)throw Error('input_invalid');value.set(payload); });
    return {type:'text-area',key,label,value:value.value,onChange};
  },
  secureField(key: string, label: string, value: State<string>, events: { onFocus?: () => unknown; onBlur?: () => unknown; onSubmit?: () => unknown } = {}): Node {
    const onChange = bind(key,value,payload => { if(typeof payload !== 'string' || payload.length > 4000)throw Error('input_invalid');value.set(payload); });
    const onFocus = events.onFocus ? bind(`focus:${key}`,value,() => events.onFocus?.()) : undefined;
    const onBlur = events.onBlur ? bind(`blur:${key}`,value,() => events.onBlur?.()) : undefined;
    const onSubmit = events.onSubmit ? bind(`submit:${key}`,value,() => events.onSubmit?.()) : undefined;
    return {type:'secure-field',key,label,value:value.value,onChange,...(onFocus?{onFocus}:{}),...(onBlur?{onBlur}:{}),...(onSubmit?{onSubmit}:{})};
  },
  file(key: string,label: string,value: State<string>): Node {
    if(!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key))throw new Error('Invalid file key');
    const onChange=bind(`file:${key}`,value,payload=>{if(typeof payload!=='string'||payload.length>80)throw Error('input_invalid');value.set(payload);});
    return {type:'file',key,label,onChange};
  },
  toggle(key: string,label: string,value: State<boolean>): Node {
    const onChange = bind(key,value,payload => { if(typeof payload !== 'boolean')throw Error('input_invalid');value.set(payload); });
    return {type:'toggle',key,label,value:String(value.value),onChange};
  },
  select(key: string,label: string,options: string[],value: State<string>): Node {
    if (!Array.isArray(options) || options.length < 1 || options.length > 100 || options.some(option => typeof option !== 'string' || !option.trim() || option.length > 200) || new Set(options).size !== options.length)
      throw new Error('Invalid select options');
    const onChange = bind(key,value,payload => {
      if (typeof payload !== 'string' || !options.includes(payload)) throw Error('input_invalid');
      value.set(payload);
    });
    return {type:'select',key,label,options,value:value.value,onChange};
  },
  multiSelect(key: string,label: string,options: string[],value: State<string[]>): Node {
    if (!Array.isArray(options) || options.length < 1 || options.length > 30 || options.some(option => typeof option !== 'string' || !option.trim() || option.length > 120) || new Set(options).size !== options.length)
      throw new Error('Invalid multi-select options');
    const onChange = bind(key,value,payload => {
      if (!Array.isArray(payload) || payload.length > options.length || payload.some(option => typeof option !== 'string' || !options.includes(option)) || new Set(payload).size !== payload.length) throw Error('input_invalid');
      value.set(options.filter(option => payload.includes(option)));
    });
    return {type:'multi-select',key,label,options,value:JSON.stringify(value.value),onChange};
  },
  dateTime(key: string,label: string,value: State<number | null>): Node {
    const onChange = bind(key,value,payload => {
      if (typeof payload !== 'string') throw Error('input_invalid');
      if (payload === '') { value.set(null); return; }
      const milliseconds = Number(payload);
      if (!Number.isSafeInteger(milliseconds) || Math.abs(milliseconds) > 8.64e15) throw Error('input_invalid');
      value.set(milliseconds);
    });
    return {type:'date',key,label,value:value.value == null ? '' : String(value.value),onChange};
  },
  dateRange(key: string,label: string,value: State<{start:number|null;end:number|null}>): Node {
    const onChange = bind(key,value,payload => {
      if (typeof payload !== 'string' || payload.length > 128) throw Error('input_invalid');
      let range: unknown;
      try { range = JSON.parse(payload); } catch { throw Error('input_invalid'); }
      if (!range || typeof range !== 'object' || Array.isArray(range) || !Object.hasOwn(range,'start') || !Object.hasOwn(range,'end') || Object.keys(range).some(field => !['start','end'].includes(field))) throw Error('input_invalid');
      const candidate = range as {start?:unknown;end?:unknown};
      for (const date of [candidate.start,candidate.end]) if (date !== null && (typeof date !== 'number' || !Number.isSafeInteger(date) || Math.abs(date) > 8.64e15)) throw Error('input_invalid');
      if (candidate.start != null && candidate.end != null && Number(candidate.start) > Number(candidate.end)) throw Error('input_invalid');
      value.set({start:(candidate.start ?? null) as number|null,end:(candidate.end ?? null) as number|null});
    });
    const normalized = {start:value.value?.start ?? null,end:value.value?.end ?? null};
    return {type:'date-range',key,label,value:JSON.stringify(normalized),onChange};
  },
  stepper(key: string,label: string,value: State<number>,min: number,max: number,step = 1): Node {
    if (![min,max,step,value.value].every(Number.isFinite) || min >= max || step <= 0 || step > max-min || value.value < min || value.value > max) throw new Error('Invalid stepper bounds or value');
    const onChange=bind(key,value,payload=>{
      if(typeof payload!=='number'||!Number.isFinite(payload)||payload<min||payload>max)throw Error('input_invalid');
      const position=(payload-min)/step;
      if(Math.abs(position-Math.round(position))>1e-8)throw Error('input_invalid');
      value.set(payload);
    });
    return {type:'stepper',key,label,value:String(value.value),min,max,step,onChange};
  },
  checkbox(key: string,label: string,value: State<boolean>): Node {
    const onChange=bind(key,value,payload=>{if(typeof payload!=='boolean')throw Error('input_invalid');value.set(payload);});
    return {type:'checkbox',key,label,value:String(value.value),onChange};
  },
  radio(key: string,label: string,options: string[],value: State<string>): Node {
    if(!Array.isArray(options)||options.length<1||options.length>30||options.some(option=>typeof option!=='string'||!option.trim()||option.length>120)||new Set(options).size!==options.length||!options.includes(value.value))throw new Error('Invalid radio options or selection');
    const onChange=bind(key,value,payload=>{if(typeof payload!=='string'||!options.includes(payload))throw Error('input_invalid');value.set(payload);});
    return {type:'radio',key,label,options,value:value.value,onChange};
  },
  button(label: string, onPress: () => unknown): Node {
    const occurrence = buttonOccurrences.get(label) ?? 0;
    buttonOccurrences.set(label,occurrence + 1);
    const key = JSON.stringify([label,occurrence]);
    let event = buttonBindings.get(key);
    if (!event) { event = String(++nextID); buttonBindings.set(key,event); }
    callbacks.set(event, onPress);
    return { type: 'button', label, action: 'runtime.event' as Node['action'], arguments: { event } };
  }
};
// Only the trusted runtime bootstrap provides this JSON-only channel.
declare const __citOutput: (message: string) => void;
export function mountProgram(program: Program) {
  let rendering = false;
  let scheduled = false;
  const render = () => {
    if (rendering) throw Error('Recursive render');
    rendering = true;
    try {
      callbacks.clear();
      buttonOccurrences.clear();
      const content = program.program.render();
      const animation = pendingAnimation;
      pendingAnimation = undefined;
      __citOutput(JSON.stringify({ type: 'render', content, ...(animation ? { animation } : {}) }));
    } finally { rendering = false; }
  };
  Object.assign(globalThis, { __citEvent: (event: string, payload: unknown) => {
    const callback = callbacks.get(event);
    if (!callback) return;
    try {
      // Start the handler synchronously so native hosts can validate the real button gesture.
      return Promise.resolve(callback(payload)).then(render).catch(error => { Object.assign(globalThis, { __citFailure: failureMessage(error) }); });
    } catch (error) {
      Object.assign(globalThis, { __citFailure: failureMessage(error) });
    }
  }, __citRender: render, __citSetAnimation: (value: { duration: number; curve: string; damping: number }) => { pendingAnimation = value; }, __citInvalidate: () => {
    if (scheduled) return;
    scheduled = true;
    void Promise.resolve().then(() => { scheduled = false; render(); }).catch(error => { Object.assign(globalThis, { __citFailure: failureMessage(error) }); });
  }, __citLifecycle: (event: string, payload: unknown) => emitLifecycle(event, payload).then(render).catch(error => { Object.assign(globalThis, { __citFailure: failureMessage(error) }); }) });
  render();
  void emitLifecycle('launch', undefined).then(() => emitLifecycle('appear', undefined)).then(render).catch(error => { Object.assign(globalThis, { __citFailure: failureMessage(error) }); });
}
