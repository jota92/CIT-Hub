import { call } from './host';

export interface MotionVector {
  x: number; y: number; z: number;
  timestamp: string;
  unit: 'm/s2' | 'rad/s' | 'microtesla';
}
export interface MotionOrientation {
  x: number; y: number; z: number; w: number;
  timestamp: string;
  reference: 'arbitrary' | 'magneticNorth';
}
// One fresh sample per call; acquisition ends on success, timeout or screen exit.
export const sensors = {
  accelerometer: (): Promise<MotionVector> => call('sensors.read', { kind: 'accelerometer' }),
  gyroscope: (): Promise<MotionVector> => call('sensors.read', { kind: 'gyroscope' }),
  magnetometer: (): Promise<MotionVector> => call('sensors.read', { kind: 'magnetometer' }),
  orientation: (): Promise<MotionOrientation> => call('sensors.read', { kind: 'orientation' })
};
