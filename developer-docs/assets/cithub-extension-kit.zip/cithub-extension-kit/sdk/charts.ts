import type { Node } from './index';
import { canvas, type DrawingColor, type ExtensionCanvas, type PathSegment } from './canvas';
import { ValidationError } from './core';
export interface ChartSeries { label: string; values: number[]; color?: DrawingColor }
export interface ScatterSeries { label: string; points: {x:number;y:number}[]; color?: DrawingColor }
const colors: DrawingColor[]=['accent','#d97706','#0d9488','#dc2626'];
function validate(label: string,categories: string[],series: ChartSeries[]): void {
  if(!label?.trim()||label.length>120||!Array.isArray(categories)||categories.length<1||categories.length>24||categories.some(item=>typeof item!=='string'||!item.trim()||item.length>40)||new Set(categories).size!==categories.length||!Array.isArray(series)||series.length<1||series.length>4||series.some(row=>!row.label?.trim()||row.label.length>80||row.values.length!==categories.length||row.values.some(value=>!Number.isFinite(value)||Math.abs(value)>1e6)))throw new ValidationError('chart_data_invalid');
}
function wrap(label: string,drawing: ExtensionCanvas,rows: {label:string;color?:DrawingColor}[],summary: string): Node {
  return {type:'column',children:[{type:'heading',text:label},drawing.node(),...summary.split(' / ').map(text=>({type:'caption' as const,text})),...rows.map((row,index)=>({type:'caption' as const,text:`${index+1}. ${row.label}`}))]};
}
function cartesian(kind: 'line'|'area'|'bar',label: string,categories: string[],series: ChartSeries[]): Node {
  validate(label,categories,series);
  const drawing=canvas.create(360,220,label),values=series.flatMap(row=>row.values),low=Math.min(0,...values),high=Math.max(1,...values),span=high-low;
  const x=(index:number)=>46+(categories.length===1?144:index*288/(categories.length-1));
  const y=(value:number)=>178-(value-low)/span*154;
  drawing.line(40,24,40,178,{stroke:'secondary',lineWidth:1}).line(40,y(0),340,y(0),{stroke:'secondary',lineWidth:1});
  drawing.text(String(high),34,24,{align:'trailing',size:10}).text(String(low),34,178,{align:'trailing',size:10});
  series.forEach((row,index)=>{
    const tint=row.color??colors[index];
    if(kind==='bar') {
      const group=288/categories.length,width=group/(series.length+1);
      row.values.forEach((value,i)=>drawing.rect(46+i*group+index*width,Math.min(y(0),y(value)),width*0.85,Math.abs(y(value)-y(0)),{fill:tint}));
    } else {
      const points:PathSegment[]=row.values.map((value,i)=>({op:i===0?'move':'line',x:x(i),y:y(value)}));
      if(kind==='area')drawing.path([...points,{op:'line',x:x(categories.length-1),y:y(0)},{op:'line',x:x(0),y:y(0)},{op:'close'}],{fill:tint,opacity:0.18});
      drawing.path(points,{stroke:tint,lineWidth:2});
      row.values.forEach((value,i)=>drawing.circle(x(i),y(value),2.5,{fill:tint}));
    }
  });
  const indices=[...new Set([0,Math.floor((categories.length-1)/2),categories.length-1])];
  indices.forEach(i=>drawing.text(categories[i],kind==='bar'?46+(i+0.5)*288/categories.length:x(i),200,{align:'center',size:10}));
  return wrap(label,drawing,series,series.map(row=>`${row.label}: ${categories.map((category,i)=>`${category} ${row.values[i]}`).join('、')}`).join(' / '));
}
function circular(donut: boolean,label: string,categories: string[],values: number[]): Node {
  validate(label,categories,[{label,values}]);
  if(values.some(value=>value<0)||values.every(value=>value===0))throw new ValidationError('chart_data_invalid');
  const drawing=canvas.create(320,220,label),total=values.reduce((a,b)=>a+b,0);
  let angle=-Math.PI/2;
  values.forEach((value,index)=>{
    if(!value)return;
    const end=angle+value/total*Math.PI*2,steps=Math.max(2,Math.ceil((end-angle)*10));
    const points:PathSegment[]=[{op:'move',x:160,y:110},{op:'line',x:160+90*Math.cos(angle),y:110+90*Math.sin(angle)}];
    for(let step=1;step<=steps;step++){const a=angle+(end-angle)*step/steps;points.push({op:'line',x:160+90*Math.cos(a),y:110+90*Math.sin(a)});}
    points.push({op:'close'});drawing.path(points,{fill:colors[index%colors.length],stroke:colors[index%colors.length]});angle=end;
  });
  // The hole uses the host surface token rather than a hard-coded light background.
  if(donut)drawing.circle(160,110,48,{fill:'surface'}).text(String(total),160,110,{align:'center'});
  return wrap(label,drawing,categories.map(category=>({label:category})),categories.map((category,i)=>`${category}: ${values[i]} (${Math.round(values[i]/total*100)}%)`).join('、'));
}
export const chart = {
  line:(label:string,categories:string[],series:ChartSeries[]):Node=>cartesian('line',label,categories,series),
  area:(label:string,categories:string[],series:ChartSeries[]):Node=>cartesian('area',label,categories,series),
  bar:(label:string,categories:string[],series:ChartSeries[]):Node=>cartesian('bar',label,categories,series),
  pie:(label:string,categories:string[],values:number[]):Node=>circular(false,label,categories,values),
  donut:(label:string,categories:string[],values:number[]):Node=>circular(true,label,categories,values),
  scatter(label:string,series:ScatterSeries[]):Node {
    if(!label?.trim()||label.length>120||!Array.isArray(series)||series.length<1||series.length>4||series.some(row=>!row.label?.trim()||row.label.length>80||row.points.length<1||row.points.length>24||row.points.some(point=>![point.x,point.y].every(value=>Number.isFinite(value)&&Math.abs(value)<=1e6))))throw new ValidationError('chart_data_invalid');
    const drawing=canvas.create(360,220,label),points=series.flatMap(row=>row.points),xmin=Math.min(...points.map(p=>p.x)),xmax=Math.max(...points.map(p=>p.x)),ymin=Math.min(...points.map(p=>p.y)),ymax=Math.max(...points.map(p=>p.y));
    drawing.line(40,24,40,178,{stroke:'secondary'}).line(40,178,340,178,{stroke:'secondary'});
    series.forEach((row,i)=>row.points.forEach(point=>drawing.circle(46+(point.x-xmin)/(xmax-xmin||1)*288,178-(point.y-ymin)/(ymax-ymin||1)*154,3,{fill:row.color??colors[i]})));
    drawing.text(String(xmin),46,200,{size:10}).text(String(xmax),334,200,{align:'trailing',size:10}).text(String(ymax),34,24,{align:'trailing',size:10}).text(String(ymin),34,178,{align:'trailing',size:10});
    return wrap(label,drawing,series,series.map(row=>`${row.label}: ${row.points.map(point=>`(${point.x}, ${point.y})`).join('、')}`).join(' / '));
  }
};
