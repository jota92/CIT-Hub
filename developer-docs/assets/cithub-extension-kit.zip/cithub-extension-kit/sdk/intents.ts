import { ValidationError, utf8ByteLength } from './core';

export type IntentHandler<T = unknown, R = unknown> = (input: T) => R | Promise<R>;
const handlers = new Map<string, Set<IntentHandler>>();
const namePattern = /^[A-Za-z][A-Za-z0-9_.-]{0,63}$/;

function validName(name: string): string {
  if (typeof name !== 'string' || !namePattern.test(name)) throw new ValidationError('intent_name_invalid');
  return name;
}

function clonePayload(value: unknown): unknown {
  let encoded: string;
  try { encoded = JSON.stringify(value ?? null); }
  catch { throw new ValidationError('intent_payload_invalid'); }
  if (utf8ByteLength(encoded) > 16_384) throw new ValidationError('intent_payload_too_large');
  return JSON.parse(encoded);
}

/** In-extension intent dispatch. This never invokes another extension or the operating system. */
export const intent = {
  register<T = unknown, R = unknown>(name: string, handler: IntentHandler<T, R>): () => void {
    const key = validName(name);
    if (typeof handler !== 'function') throw new ValidationError('intent_handler_invalid');
    const listeners = handlers.get(key) ?? new Set<IntentHandler>();
    listeners.add(handler as IntentHandler);
    handlers.set(key, listeners);
    let active = true;
    return () => {
      if (!active) return;
      active = false;
      listeners.delete(handler as IntentHandler);
      if (!listeners.size) handlers.delete(key);
    };
  },

  async perform<T = unknown, R = unknown>(name: string, input?: T): Promise<R[]> {
    const key = validName(name);
    const listeners = [...(handlers.get(key) ?? [])];
    if (!listeners.length) throw new ValidationError('intent_not_registered');
    const payload = clonePayload(input);
    const results: R[] = [];
    for (const handler of listeners) results.push(await handler(payload) as R);
    return results;
  }
};
