import { UnsupportedError } from './core';
declare const __citInspect:((value:unknown)=>string)|undefined;
declare const __citDebug:((message:string)=>void)|undefined;
export const debug = {
  inspect(value:unknown):string {
    if(typeof __citInspect!=='function')throw new UnsupportedError('debug_runtime_required');
    return __citInspect(value);
  }
};
function write(level:'log'|'warn'|'error',values:unknown[]):void {
  if(typeof __citDebug!=='function')throw new UnsupportedError('debug_runtime_required');
  __citDebug(JSON.stringify({level,text:debug.inspect(values).slice(0,1000)}));
}
export const console = {
  log:(...values:unknown[]):void=>write('log',values),
  warn:(...values:unknown[]):void=>write('warn',values),
  error:(...values:unknown[]):void=>write('error',values)
};
