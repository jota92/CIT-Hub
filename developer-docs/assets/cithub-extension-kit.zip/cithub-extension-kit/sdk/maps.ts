import { ValidationError } from './core';
import { call } from './host';
import type { Node } from './index';

export interface MapCoordinate { latitude: number; longitude: number }
export interface DirectionsOptions { name?: string; mode?: 'walking' | 'driving' | 'transit' }
export interface MapViewOptions { center?: MapCoordinate; zoom?: number; height?: number }
export interface MapMarkerOptions { title: string; subtitle?: string }
export interface MapShapeOptions { tone?: 'primary' | 'secondary' | 'accent'; width?: number }

const coordinate = (value: MapCoordinate): MapCoordinate => {
  if (!value || !Number.isFinite(value.latitude) || !Number.isFinite(value.longitude) ||
      Math.abs(value.latitude) > 85.051129 || Math.abs(value.longitude) > 180)
    throw new ValidationError('map_coordinate_invalid');
  return { latitude: value.latitude, longitude: value.longitude };
};
const points = (value: MapCoordinate[], min: number, max: number): string => {
  if (!Array.isArray(value) || value.length < min || value.length > max) throw new ValidationError('map_points_invalid');
  return JSON.stringify(value.map(coordinate));
};

export const map = {
  view(options: MapViewOptions = {}, overlays: Node[] = []): Node {
    const center = options.center ? JSON.stringify(coordinate(options.center)) : '';
    const zoom = options.zoom ?? 14;
    const height = options.height ?? 260;
    if (!Number.isFinite(zoom) || zoom < 2 || zoom > 19 || !Number.isFinite(height) || height < 140 || height > 600 ||
        !Array.isArray(overlays) || overlays.length > 100)
      throw new ValidationError('map_view_invalid');
    return { type: 'map-view', arguments: { center, zoom: String(zoom) }, size: height, children: overlays };
  },
  marker(location: MapCoordinate, options: MapMarkerOptions): Node {
    const title = options?.title;
    const subtitle = options?.subtitle ?? '';
    if (typeof title !== 'string' || !title.trim() || title.length > 100 || typeof subtitle !== 'string' || subtitle.length > 160)
      throw new ValidationError('map_marker_invalid');
    return { type: 'map-marker', label: title.trim(), text: subtitle, arguments: { coordinate: JSON.stringify(coordinate(location)) } };
  },
  polyline(path: MapCoordinate[], options: MapShapeOptions = {}): Node {
    const width = options.width ?? 4;
    if (!Number.isFinite(width) || width < 1 || width > 12 || !['primary', 'secondary', 'accent', undefined].includes(options.tone))
      throw new ValidationError('map_shape_invalid');
    return { type: 'map-polyline', size: width, style: { tone: options.tone ?? 'accent' }, arguments: { coordinates: points(path, 2, 1000) } };
  },
  circle(center: MapCoordinate, radiusMeters: number, options: MapShapeOptions = {}): Node {
    const width = options.width ?? 2;
    if (!Number.isFinite(radiusMeters) || radiusMeters < 1 || radiusMeters > 50000 || !Number.isFinite(width) || width < 1 || width > 12 ||
        !['primary', 'secondary', 'accent', undefined].includes(options.tone))
      throw new ValidationError('map_shape_invalid');
    return { type: 'map-circle', size: width, style: { tone: options.tone ?? 'accent' }, arguments: { coordinate: JSON.stringify(coordinate(center)), radiusMeters: String(radiusMeters) } };
  },
  fitBounds(bounds: MapCoordinate[], padding = 32): Node {
    if (!Number.isFinite(padding) || padding < 0 || padding > 100) throw new ValidationError('map_bounds_invalid');
    return { type: 'map-fit-bounds', size: padding, arguments: { coordinates: points(bounds, 2, 64) } };
  },
  async openDirections(destination: MapCoordinate, options: DirectionsOptions = {}): Promise<void> {
    if (!destination || !Number.isFinite(destination.latitude) || Math.abs(destination.latitude) > 90 || !Number.isFinite(destination.longitude) || Math.abs(destination.longitude) > 180)
      throw new ValidationError('map_coordinate_invalid');
    const point = destination;
    const name = options.name ?? '', mode = options.mode ?? 'walking';
    if (typeof name !== 'string' || name.length > 120 || !['walking', 'driving', 'transit'].includes(mode))
      throw new ValidationError('map_directions_invalid');
    await call('map.directions', { latitude: point.latitude, longitude: point.longitude, name, mode });
  }
};
