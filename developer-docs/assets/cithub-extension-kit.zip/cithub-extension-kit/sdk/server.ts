import { call, cloudUser } from './host';
import { ValidationError, utf8ByteLength } from './core';

export interface ServerRecord<T extends Record<string,unknown> = Record<string,unknown>> { id:string; value:T; revision:number; updatedAt:string }
export interface ServerFilter { field:string; operator:'=='|'!='|'>'|'>='|'<'|'<='; value:string|number|boolean|null }
export interface ServerQuery { filters?:ServerFilter[]; limit?:number; cursor?:string|null }
export type ServerOperation = { action:'insert'; table:string; id:string; value:Record<string,unknown> } |
  { action:'update'; table:string; id:string; value:Record<string,unknown>; expectedRevision:number } |
  { action:'delete'; table:string; id:string; expectedRevision:number } |
  { action:'query'; table:string; filters?:ServerFilter[]; limit?:number; cursor?:string|null };
export type ServerResult = ServerRecord | {deleted:boolean} | {rows:ServerRecord[];nextCursor:string|null};
export interface ServerFunctionContext { extensionId:string; environment:'development'|'production'; invokedAt:string }
export type ServerFunctionHandler = (input:unknown,context:ServerFunctionContext)=>unknown|Promise<unknown>;
export interface CronRegistration { name:string; registered:boolean; intervalSeconds?:number; nextRunAt?:string }
export interface CronStatus { name:string; enabled:boolean; intervalSeconds:number; nextRunAt:string; lastRunAt:string|null; lastResultAt:string|null; lastResult:unknown; lastStatus:'pending'|'success'|'failed'; lastError:string|null }
export interface ServerFileMetadata { id:string; name:string; mimeType:string; size:number; revision:number; updatedAt:string }
export interface ServerFile extends ServerFileMetadata { bytes:Uint8Array }
const serverFileID=(value:string):string=>{if(typeof value!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$/.test(value))throw new ValidationError('server_file_id_invalid');return value;};
const serverFileName=(value:string):string=>{if(typeof value!=='string'||!value.trim()||value.length>160||/[\u0000-\u001f\u007f/\\]/.test(value))throw new ValidationError('server_file_invalid');return value.normalize('NFC');};
const serverFileMime=(value:string):string=>{if(typeof value!=='string'||!/^[a-z0-9][a-z0-9.+-]{0,63}\/[a-z0-9][a-z0-9.+-]{0,63}$/i.test(value))throw new ValidationError('server_file_invalid');return value.toLowerCase();};
const serverFileBytes=(value:Uint8Array):Uint8Array=>{if(!(value instanceof Uint8Array)||value.byteLength<1||value.byteLength>256*1024)throw new ValidationError('server_file_too_large');return value;};
const serverFileBase64=(bytes:Uint8Array):string=>{let binary='';for(let offset=0;offset<bytes.length;offset+=0x8000)binary+=String.fromCharCode(...bytes.subarray(offset,offset+0x8000));return btoa(binary);};
const serverFileDecode=(value:string):Uint8Array=>{if(typeof value!=='string'||value.length>Math.ceil(256*1024/3)*4||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value))throw new ValidationError('server_file_invalid');const binary=atob(value);if(!binary.length||binary.length>256*1024)throw new ValidationError('server_file_too_large');return Uint8Array.from(binary,char=>char.charCodeAt(0));};
const tableName = (value:string):string => {
  if(typeof value!=='string'||!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(value)||['constructor','prototype','__proto__'].includes(value))throw new ValidationError('table_invalid');return value;
};
const recordID = (value:string):string => {
  if(typeof value!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/.test(value))throw new ValidationError('record_id_invalid');return value;
};
function validateRecordValue(value:unknown): asserts value is Record<string,unknown> {
  if(!value||typeof value!=='object'||Array.isArray(value))throw new ValidationError('record_invalid');
  let remaining=2048;
  const visit=(current:unknown,depth:number):void=>{
    if(depth>12||--remaining<0)throw new ValidationError('record_invalid');
    if(current===null||typeof current==='string'||typeof current==='boolean')return;
    if(typeof current==='number'&&Number.isFinite(current))return;
    if(!current||typeof current!=='object')throw new ValidationError('record_invalid');
    for(const [key,child] of Object.entries(current)){
      if(['__proto__','constructor','prototype'].includes(key))throw new ValidationError('record_invalid');
      visit(child,depth+1);
    }
  };
  visit(value,0);
  let serialized:string;
  try{serialized=JSON.stringify(value);}catch{throw new ValidationError('record_invalid');}
  if(utf8ByteLength(serialized)>16384)throw new ValidationError('record_too_large');
}
function validate(operation:ServerOperation):ServerOperation {
  if(!operation||!['insert','update','delete','query'].includes(operation.action))throw new ValidationError('server_data_invalid');
  tableName(operation.table);
  if(operation.action!=='query')recordID(operation.id);
  if((operation.action==='update'||operation.action==='delete')&&(!Number.isSafeInteger(operation.expectedRevision)||operation.expectedRevision<1))throw new ValidationError('revision_required');
  if(operation.action==='insert'||operation.action==='update')validateRecordValue(operation.value);
  if(operation.action==='query'){
    if(operation.limit!==undefined&&(!Number.isInteger(operation.limit)||operation.limit<1||operation.limit>100))throw new ValidationError('query_invalid');
    if(operation.cursor!==undefined&&operation.cursor!==null&&operation.cursor!=='')recordID(operation.cursor);
    if(operation.filters!==undefined&&(!Array.isArray(operation.filters)||operation.filters.length>16||operation.filters.some(filter=>!filter||Object.keys(filter).length!==3||!['field','operator','value'].every(key=>Object.hasOwn(filter,key))||typeof filter.field!=='string'||!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(filter.field)||['constructor','prototype','__proto__'].includes(filter.field)||!['==','!=','>','>=','<','<='].includes(filter.operator)||filter.value!==null&&!['string','number','boolean'].includes(typeof filter.value)||typeof filter.value==='number'&&!Number.isFinite(filter.value))))throw new ValidationError('query_invalid');
  }
  return operation;
}
const request = <T>(args:unknown):Promise<T> => call('server.data',args);
const functionName = (value:string):string => {
  if(typeof value!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/.test(value))throw new ValidationError('function_name_invalid');
  return value;
};
function functionInput(value:unknown):unknown {
  let text:string;
  try{text=JSON.stringify(value);}catch{throw new ValidationError('function_input_invalid');}
  if(typeof text!=='string'||utf8ByteLength(text)>16_384)throw new ValidationError('function_input_too_large');
  return JSON.parse(text);
}
const kvKey=(key:string)=>{if(typeof key!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,79}$/.test(key))throw new ValidationError('key_invalid');return `server.kv.${key}`;};
export const server = {
  function<T=unknown>(name:string,input:unknown=null):Promise<T>{
    return call('server.function',{name:functionName(name),input:functionInput(input)});
  },
  cron: {
    register(name:string,input:unknown=null,intervalSeconds=3600):Promise<CronRegistration>{
      if(!Number.isInteger(intervalSeconds)||intervalSeconds<900||intervalSeconds>2592000)throw new ValidationError('cron_interval_invalid');
      return call('server.cron',{action:'register',name:functionName(name),input:functionInput(input),intervalSeconds});
    },
    unregister(name:string):Promise<CronRegistration>{return call('server.cron',{action:'unregister',name:functionName(name)});},
    status(name:string):Promise<CronStatus>{return call('server.cron',{action:'status',name:functionName(name)});}
  },
  kv: {
    get:<T=unknown>(key:string):Promise<{value:T|null;revision:number}>=>cloudUser.get<T>(kvKey(key)),
    set:(key:string,value:unknown,expectedRevision:number):Promise<number>=>cloudUser.set(kvKey(key),expectedRevision,value),
    delete:(key:string,expectedRevision:number):Promise<boolean>=>cloudUser.delete(kvKey(key),expectedRevision)
  },
  files: {
    list():Promise<ServerFileMetadata[]>{return call('server.files',{action:'list'});},
    async get(id:string):Promise<ServerFile|null>{const result=await call<(ServerFileMetadata&{data:string})|null>('server.files',{action:'get',id:serverFileID(id)});return result===null?null:{id:result.id,name:result.name,mimeType:result.mimeType,size:result.size,revision:result.revision,updatedAt:result.updatedAt,bytes:serverFileDecode(result.data)};},
    put(id:string,file:{name:string;mimeType:string;bytes:Uint8Array},expectedRevision:number):Promise<ServerFileMetadata>{
      if(!file||typeof file!=='object'||Object.keys(file).some(key=>!['name','mimeType','bytes'].includes(key))||!['name','mimeType','bytes'].every(key=>Object.hasOwn(file,key)))throw new ValidationError('server_file_invalid');
      if(!Number.isSafeInteger(expectedRevision)||expectedRevision<0)throw new ValidationError('revision_required');
      return call('server.files',{action:'put',id:serverFileID(id),file:{name:serverFileName(file.name),mimeType:serverFileMime(file.mimeType),data:serverFileBase64(serverFileBytes(file.bytes))},expectedRevision});
    },
    delete(id:string,expectedRevision:number):Promise<{deleted:boolean}>{if(!Number.isSafeInteger(expectedRevision)||expectedRevision<1)throw new ValidationError('revision_required');return call('server.files',{action:'delete',id:serverFileID(id),expectedRevision});}
  },
  db: {
    insert<T extends Record<string,unknown>>(table:string,id:string,value:T):Promise<ServerRecord<T>>{return request(validate({action:'insert',table,id,value}));},
    query<T extends Record<string,unknown> = Record<string,unknown>>(table:string,options:ServerQuery={}):Promise<{rows:ServerRecord<T>[];nextCursor:string|null}>{return request(validate({action:'query',table,...options}));},
    update<T extends Record<string,unknown>>(table:string,id:string,value:T,expectedRevision:number):Promise<ServerRecord<T>>{return request(validate({action:'update',table,id,value,expectedRevision}));},
    delete(table:string,id:string,expectedRevision:number):Promise<{deleted:boolean}>{return request(validate({action:'delete',table,id,expectedRevision}));},
    transaction(operations:ServerOperation[]):Promise<ServerResult[]>{
      if(!Array.isArray(operations)||!operations.length||operations.length>32)throw new ValidationError('transaction_invalid');
      return request({action:'transaction',operations:operations.map(validate)});
    }
  }
};
