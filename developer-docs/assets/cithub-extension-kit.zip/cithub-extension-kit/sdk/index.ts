export type Permission = 'cloud.storage' | 'timetable.read' | 'assignments.read' | 'todos.read' | 'todos.write' | 'calendar.read' | 'bus.read' | 'cafeteria.read' | 'files.user' | 'files.selection.read' | 'files.storage' | 'browser.open' | 'settings.read' | 'settings.open' | 'courseNotes.read' | 'courseNotes.write' | 'media.remote' | 'board.camera' | 'photos.user' | 'camera.use' | 'location.use' | 'network.status' | 'network.fetch' | 'clipboard.read' | 'clipboard.write' | 'notifications.schedule';
export type CampusQuery = 'courseNotes.data' | 'courses.data' | 'timetable.periods' | 'assignments.data' | 'todos.data' | 'academic.calendar' | 'bus.schedule' | 'cafeteria.locations' | 'cafeteria.menu' | 'cafeteria.cameraStatus' | 'settings.display' | 'courses.current' | 'courses.next' | 'courses.today' | 'courses.week' | 'enrollment.summary' | 'assignments.pending' | 'assignments.summary' | 'assignments.overdue' | 'assignments.dueSoon' | 'todos.summary';
export interface Course { id:string; term:string; name: string; classroom: string; weekday: number; dayName:string; period: string; startMinutes: number | null; endMinutes: number | null; teacher?:string; syllabus?:string; hasSyllabus?:boolean }
export interface CourseOccurrence extends Course { date:string; startAt:string|null; endAt:string|null }
export interface PeriodSlot { weekday:number;dayName:string;period:string;periodIndex:number;startMinutes:number|null;endMinutes:number|null }
export interface Task { id:string; type:string; title:string; course:string; startAt:string|null; deadline:string|null; url:string|null }
export interface AcademicCalendarEvent { title:string; start:string; end:string; kind:'regular'|'class_suspension'|'vacation' }
export type BusDayType = 'weekday'|'saturday'|'sunday_holiday';
export interface BusTrip { time:string; viaAkanehamaSportsFacility:boolean; akanehamaDepartureTime:string|null }
export interface BusRoute { from:string; to:string; schedules:Record<BusDayType,BusTrip[]> }
export interface BusSchedule { title:string; validPeriod:{from:string;to:string;original?:string|null}; note?:string|null; routes:BusRoute[] }
export interface BusDeparture extends BusTrip { from:string; to:string; date:string; departureAt:string; dayType:BusDayType }
export interface BusServiceStatus { title:string; note:string|null; date:string; validFrom:string; validTo:string; inServicePeriod:boolean; dayType:BusDayType; routeCount:number }
export interface CafeteriaLocation { id:'sd1'|'sd2'|'td'; name:string; campus:'新習志野'|'津田沼'; floor:string; menuURL:string }
export interface CafeteriaCameraStatus { id:'narashino1'|'narashino2'|'tsudanuma'; name:string; isLiveNow:boolean; serviceDays:string[]; startTime:string; endTime:string; imageURL:string }
export interface UserPreferences { accentColor:string|null; enabledServices:string[]; notifications:{classStart:boolean;assignments:boolean}; portal:{manabaAutoLogin:boolean;portalAutoLogin:boolean;manabaSmartphoneMode:boolean;portalSmartphoneMode:boolean} }
export interface CampusService { title:string; enabled:true }
export interface CampusSnapshot { generatedAt: string; timezone: 'Asia/Tokyo'; courses: Course[] | null; assignments: Task[] | null; todoCount: number | null }
export interface Style { tone?: "primary" | "secondary" | "accent"; textSize?: "caption" | "body" | "title"; align?: "leading" | "center" | "trailing"; padding?: number; spacing?: number; minWidth?: number; maxWidth?: number; minHeight?: number; maxHeight?: number; aspectRatio?: number; weight?: "regular" | "medium" | "semibold" | "bold"; lineLimit?: number; selectable?: boolean }
import type { AccessibilityAttributes } from './accessibility';
declare global { var __citSetAnimation: ((value: { duration: number; curve: string; damping: number }) => void) | undefined }
export type Node = { accessibility?: AccessibilityAttributes; value?: string; onChange?: string; type: 'text' | 'label' | 'markdown' | 'code' | 'caption' | 'badge' | 'icon' | 'progress' | 'chart' | 'loading' | 'empty-state' | 'error-state' | 'section' | 'column' | 'row' | 'zstack' | 'scroll' | 'horizontal-scroll' | 'spacer' | 'field' | 'text-area' | 'secure-field' | 'toggle' | 'checkbox' | 'radio' | 'stepper' | 'button' | 'campus' | 'heading' | 'divider' | 'select' | 'multi-select' | 'when' | 'link' | 'date' | 'date-range' | 'file' | 'browser' | 'media' | 'board-camera' | 'share-text' | 'copy-text' | 'course-picker' | 'photo-grid' | 'photo-import' | 'photo-capture' | 'page' | 'grid' | 'footer' | 'disclosure' | 'course-list' | 'data-list' | 'number' | 'slider' | 'card' | 'group' | 'container' | 'safe-area'; min?: number; max?: number; step?: number; size?: number; limit?: number; columns?: number; kind?: 'image' | 'video' | 'audio' | 'bar'; style?: Style; text?: string; label?: string; key?: string; query?: CampusQuery; arguments?: Record<string,string>; action?: 'save' | 'reset' | 'todo.create' | 'state.set' | 'state.increment' | 'runtime.event'; options?: string[]; equals?: string; url?: string; children?: Node[] };
export interface Extension { schemaVersion: 1; minimumHostAPI?: number; name: string; version: string; description: string; permissions: Permission[]; network?: string[]; content: Node[]; runtime?: { engine: 'quickjs-v1'; code: string } }
export const defineExtension = (value: Omit<Extension, 'schemaVersion'>): Extension => ({ schemaVersion: 1, ...value });
// These descriptors request data from the native host at display time, not build time.
export const campus = {
 courseNotes: (): CampusQuery => 'courseNotes.data',
 periods: (): CampusQuery => 'timetable.periods',
 courseData: (): CampusQuery => 'courses.data', assignmentData: (): CampusQuery => 'assignments.data', todoData: (): CampusQuery => 'todos.data',
 academicCalendar: (): CampusQuery => 'academic.calendar',
 displaySettings: (): CampusQuery => 'settings.display',
 currentClass: (): CampusQuery => 'courses.current', nextClass: (): CampusQuery => 'courses.next',
 today: (): CampusQuery => 'courses.today', week: (): CampusQuery => 'courses.week',
 enrollment: (): CampusQuery => 'enrollment.summary', pendingAssignments: (): CampusQuery => 'assignments.pending',
 workload: (): CampusQuery => 'assignments.summary', overdue: (): CampusQuery => 'assignments.overdue',
 dueSoon: (): CampusQuery => 'assignments.dueSoon', todos: (): CampusQuery => 'todos.summary'
};
export const actions = {
 setField: (label: string, field: string, value: string): Node => ({type:'button',label,action:'state.set',arguments:{field,value}}),
 increment: (label: string, field: string, amount = 1): Node => ({type:'button',label,action:'state.increment',arguments:{field,amount:String(amount)}}),

 createTodo: (label: string, titleField: string, detailField: string, deadlineField?: string, notificationField?: string): Node => ({type:'button',label,action:'todo.create',arguments:{title:titleField,detail:detailField,...(deadlineField?{deadline:deadlineField}:{}),...(notificationField?{notification:notificationField}:{})}})
};
export type AnimationOptions = { duration?: number; curve?: 'linear' | 'easeIn' | 'easeOut' | 'easeInOut' | 'spring'; damping?: number };
export const animation = {
  async animate<T>(options: AnimationOptions, update: () => T | Promise<T>): Promise<T> {
    const duration = options.duration ?? 0.25;
    if (!Number.isFinite(duration) || duration < 0.05 || duration > 1.5) throw new Error('animation_duration_invalid');
    const curve = options.curve ?? 'easeInOut';
    if (!['linear', 'easeIn', 'easeOut', 'easeInOut', 'spring'].includes(curve)) throw new Error('animation_curve_invalid');
    const damping = options.damping ?? 0.82;
    if (!Number.isFinite(damping) || damping < 0.4 || damping > 1) throw new Error('animation_damping_invalid');
    globalThis.__citSetAnimation?.({ duration, curve, damping });
    return await update();
  },
  spring<T>(update: () => T | Promise<T>, options: Omit<AnimationOptions, 'curve'> = {}): Promise<T> {
    return animation.animate({ ...options, curve: 'spring' }, update);
  },
  transition<T>(update: () => T | Promise<T>, options: AnimationOptions = {}): Promise<T> {
    return animation.animate(options, update);
  }
};
export const ui = {
 textArea: (key: string, label: string): Node => ({type:'text-area',key,label}),
 label: (text: string): Node => ({type:'label',text}),
 markdown: (text: string): Node => ({type:'markdown',text}),
 code: (text: string): Node => ({type:'code',text}),
 caption: (text: string): Node => ({type:'caption',text}),
 badge: (text: string, tone: Style['tone'] = 'secondary'): Node => ({type:'badge',text,style:{tone}}),
 icon: (name: string, accessibilityLabel: string): Node => ({type:'icon',text:name,label:accessibilityLabel}),
 number: (key: string, label: string, min = 0, max = 100, step = 1): Node => ({type:'number',key,label,min,max,step}),
 slider: (key: string, label: string, min = 0, max = 100, step = 1): Node => ({type:'slider',key,label,min,max,step}),

 dataList: (key: string, query: 'courses.data' | 'timetable.periods' | 'assignments.data' | 'todos.data' | 'academic.calendar' | 'bus.schedule' | 'cafeteria.locations' | 'cafeteria.menu' | 'cafeteria.cameraStatus', children: Node[], pageSize = 20): Node => ({type:'data-list',key,query,children,limit:pageSize}),

 page: (label: string, children: Node[]): Node => ({type:'page',label,children}),
 scroll: (children: Node[]): Node => ({type:'scroll',children}),
 horizontalScroll: (children: Node[]): Node => ({type:'horizontal-scroll',children}),
 grid: (columns: number, children: Node[]): Node => ({type:'grid',columns,children}),
 footer: (children: Node[]): Node => ({type:'footer',children}),
 disclosure: (label: string, children: Node[]): Node => ({type:'disclosure',label,children}),
 courseList: (key: string, label: string, children: Node[]): Node => ({type:'course-list',key,label,children}),

 coursePicker: (key: string, label: string): Node => ({type:'course-picker',key,label}),
 photoGrid: (key: string, label: string, courseField?: string, columns = 3): Node => ({type:'photo-grid',key,label,columns,arguments:courseField?{course:courseField}:undefined}),
 importPhotos: (key: string, label: string, courseField?: string): Node => ({type:'photo-import',key,label,arguments:courseField?{course:courseField}:undefined}),
 capturePhoto: (key: string, label: string, courseField?: string): Node => ({type:'photo-capture',key,label,arguments:courseField?{course:courseField}:undefined}),
 shareText: (label: string, text: string): Node => ({type:'share-text',label,text}),
 copyText: (label: string, text: string): Node => ({type:'copy-text',label,text}),
 boardCamera: (label = '授業別の写真・撮影'): Node => ({type:'board-camera',label}),
 image: (label: string,url: string): Node => ({type:'media',kind:'image',label,url}),
 video: (label: string,url: string): Node => ({type:'media',kind:'video',label,url}),
 audio: (label: string,url: string): Node => ({type:'media',kind:'audio',label,url}),
 browser: (label: string, url: string): Node => ({type:'browser',label,url}),
 file: (key: string,label: string): Node => ({type:"file",key,label}),
 date: (key: string,label: string): Node => ({type:"date",key,label}),
 styled: (node: Node, style: Style): Node => ({...node,style}),
 heading: (text: string): Node => ({type:'heading',text}),
 divider: (): Node => ({type:'divider'}),
 select: (key: string, label: string, options: string[]): Node => ({type:'select',key,label,options}),
 when: (key: string, equals: string, children: Node[]): Node => ({type:'when',key,equals,children}),
 link: (label: string, url: string): Node => ({type:'link',label,url}),
 text: (text: string): Node => ({ type:'text',text }),
 data: (query: CampusQuery, label?: string): Node => ({ type:'campus',query,label }),
 section: (label: string, children: Node[]): Node => ({ type:'section',label,children }),
 card: (children: Node[], label?: string): Node => ({ type:'card',label,children }),
 group: (children: Node[]): Node => ({ type:'group',children }),
 container: (children: Node[]): Node => ({ type:'container',children }),
 safeArea: (children: Node[]): Node => ({ type:'safe-area',children }),
 frame: (node: Node, frame: Pick<Style,'minWidth'|'maxWidth'|'minHeight'|'maxHeight'|'aspectRatio'>): Node => ({...node,style:{...node.style,...frame}}),
 column: (children: Node[]): Node => ({ type:'column',children }),
 row: (children: Node[]): Node => ({ type:'row',children }),
 vstack: (children: Node[]): Node => ({ type:'column',children }),
 hstack: (children: Node[]): Node => ({ type:'row',children }),
 zstack: (children: Node[]): Node => ({ type:'zstack',children }),
 spacer: (size = 12): Node => ({ type:'spacer',size }),
 progress: (label: string,value: number): Node => ({ type:'progress',label,value:String(value) }),
 barChart: (label: string, categories: string[], series: Array<{label:string;values:number[]}>): Node => ({type:'chart',kind:'bar',label,options:categories,arguments:{series:JSON.stringify(series)}}),
 loading: (label: string): Node => ({ type:'loading',label }),
 emptyState: (title: string,message: string): Node => ({ type:'empty-state',label:title,text:message }),
 errorState: (title: string,message: string): Node => ({ type:'error-state',label:title,text:message }),
 field: (key: string, label: string): Node => ({ type:'field',key,label }),
 secureField: (key: string, label: string): Node => ({ type:'secure-field',key,label,value:'' }),
 toggle: (key: string, label: string): Node => ({ type:'toggle',key,label }),
 button: (label: string, action: 'save' | 'reset'): Node => ({ type:'button',label,action }),
};

export { state, math, text, json, date, ExtensionError, ValidationError, PermissionError, UserInteractionError, UnsupportedError, NetworkError, StorageError, RateLimitError, ConflictError, NotFoundError } from "./core";
export type { State, DateInput } from "./core";

export { utils, geo } from "./core";
export type { Coordinate } from "./core";

export { defineProgram, interactive } from "./program";
export type { Program } from "./program";

export { storage, cloudUser, capabilities, app, cit, network, files, location } from "./host";

export { secureStorage } from "./host";
export { crypto } from './crypto';
export { database } from './database';
export type { Transaction, RecordValue } from './database';
export type { EncryptedText } from './crypto';
export { permissions } from './host';
export type { PermissionStatus } from './host';
export type { LocationFix } from './host';
export { clipboard } from './host';
export { notification } from './host';
export type { LocalNotificationInput, NotificationRepeat, ScheduledLocalNotification } from './host';
export { haptics } from './haptics';
export { device } from './device';
export type { DeviceInfo, DeviceScreen } from './device';
export type { PersonalTodo, TodoFields } from './host';
export type { NetworkMethod, NetworkOptions, NetworkResponse, NetworkStatus, NetworkTransport } from './host';
export type { ExtensionFileInfo, SelectedFileInfo } from './host';
export { keyboard } from './keyboard';
export { accessibility } from './accessibility';
export type { AccessibilityStatus, AccessibilityRole, AccessibilityAttributes } from './accessibility';
