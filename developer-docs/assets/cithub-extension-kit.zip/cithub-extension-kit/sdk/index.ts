export type Permission = 'profile.read' | 'host.navigate' | 'extensions.read' | 'microphone.use' | 'cloud.shared' | 'server.functions' | 'sensors.motion' | 'cloud.storage' | 'analytics.collect' | 'timetable.read' | 'assignments.read' | 'todos.read' | 'todos.write' | 'calendar.read' | 'bus.read' | 'cafeteria.read' | 'files.user' | 'files.selection.read' | 'files.storage' | 'browser.open' | 'settings.read' | 'settings.open' | 'courseNotes.read' | 'courseNotes.write' | 'media.remote' | 'board.camera' | 'photos.user' | 'camera.use' | 'location.use' | 'network.status' | 'network.fetch' | 'clipboard.read' | 'clipboard.write' | 'notifications.schedule';
export type CampusQuery = 'profile.displayName' | 'courseNotes.data' | 'courses.data' | 'timetable.periods' | 'assignments.data' | 'todos.data' | 'academic.calendar' | 'bus.schedule' | 'cafeteria.locations' | 'cafeteria.menu' | 'cafeteria.cameraStatus' | 'cafeteria.hours' | 'settings.display' | 'courses.current' | 'courses.next' | 'courses.today' | 'courses.week' | 'enrollment.summary' | 'assignments.pending' | 'assignments.summary' | 'assignments.overdue' | 'assignments.dueSoon' | 'todos.summary';
export interface Course { id:string; term:string; name: string; classroom: string; weekday: number; dayName:string; period: string; startMinutes: number | null; endMinutes: number | null; teacher?:string; syllabus?:string; hasSyllabus?:boolean }
export interface CourseOccurrence extends Course { date:string; startAt:string|null; endAt:string|null }
export interface PeriodSlot { weekday:number;dayName:string;period:string;periodIndex:number;startMinutes:number|null;endMinutes:number|null }
export interface Task { id:string; type:string; title:string; course:string; startAt:string|null; deadline:string|null; url:string|null }
export interface AcademicCalendarEvent { title:string; start:string; end:string; kind:'regular'|'class_suspension'|'vacation' }
export type BusDayType = 'weekday'|'saturday'|'sunday_holiday';
export interface BusTrip { time:string; viaAkanehamaSportsFacility:boolean; akanehamaDepartureTime:string|null }
export interface BusRoute { from:string; to:string; schedules:Record<BusDayType,BusTrip[]> }
export interface BusSchedule { title:string; validPeriod:{from:string;to:string;original?:string|null}; note?:string|null; routes:BusRoute[] }
export interface BusDeparture extends BusTrip { from:string; to:string; date:string; departureAt:string; dayType:BusDayType }
export interface BusServiceStatus { title:string; note:string|null; date:string; validFrom:string; validTo:string; inServicePeriod:boolean; dayType:BusDayType; routeCount:number }
export interface CafeteriaLocation { id:'sd1'|'sd2'|'td'; name:string; campus:'新習志野'|'津田沼'; floor:string; menuURL:string }
export interface CafeteriaCameraStatus { id:'narashino1'|'narashino2'|'tsudanuma'; name:string; isLiveNow:boolean; serviceDays:string[]; startTime:string; endTime:string; imageURL:string }
export interface CafeteriaHours { id:'sd1'|'sd2'|'td'; name:string; campus:'新習志野'|'津田沼'; regular:{weekdays:string[];saturday:string[]}; breaks:{weekdays:string[];saturday:string[]}; note:string; sourceURL:string }
export interface CampusRoom { id:string; classroom:string; campus:'新習志野'|'津田沼'|'不明'; building:string|null; floor:string|null; source:'personal-timetable' }
export interface RoomScheduleStatus { room:CampusRoom; date:string; knownClasses:CourseOccurrence[]; scope:'personal-timetable-only'; campusWideAvailability:boolean }
export interface UserPreferences { accentColor:string|null; enabledServices:string[]; notifications:{classStart:boolean;assignments:boolean}; portal:{manabaAutoLogin:boolean;portalAutoLogin:boolean;manabaSmartphoneMode:boolean;portalSmartphoneMode:boolean} }
export interface CampusService { title:string; enabled:true }
export interface CampusSnapshot { generatedAt: string; timezone: 'Asia/Tokyo'; courses: Course[] | null; assignments: Task[] | null; todoCount: number | null }
import { interactive } from './program';
import { dialogs, showNotice } from './dialogs';
import { ExtensionList } from './lists';
import type { State } from './core';
export interface Style { tone?: "primary" | "secondary" | "accent"; textSize?: "caption" | "body" | "title"; align?: "leading" | "center" | "trailing"; padding?: number; spacing?: number; minWidth?: number; maxWidth?: number; minHeight?: number; maxHeight?: number; aspectRatio?: number; weight?: "regular" | "medium" | "semibold" | "bold"; lineLimit?: number; selectable?: boolean }
import type { AccessibilityAttributes } from './accessibility';
declare global { var __citSetAnimation: ((value: { duration: number; curve: string; damping: number }) => void) | undefined }
export type Node = { accessibility?: AccessibilityAttributes; value?: string; onChange?: string; onFocus?: string; onBlur?: string; onSubmit?: string; onLongPress?: string; onDoublePress?: string; type: 'canvas' | 'presentation' | 'menu' | 'context-menu' | 'swipe-actions' | 'toolbar' | 'floating-button' | 'lazy-list' | 'lazy-grid' | 'text' | 'label' | 'markdown' | 'code' | 'caption' | 'badge' | 'icon' | 'icon-button' | 'progress' | 'chart' | 'loading' | 'empty-state' | 'error-state' | 'section' | 'column' | 'row' | 'zstack' | 'scroll' | 'horizontal-scroll' | 'spacer' | 'field' | 'text-area' | 'secure-field' | 'search-field' | 'toggle' | 'checkbox' | 'radio' | 'stepper' | 'button' | 'campus' | 'heading' | 'divider' | 'select' | 'multi-select' | 'when' | 'link' | 'link-button' | 'date' | 'date-range' | 'file' | 'browser' | 'media' | 'board-camera' | 'share-text' | 'copy-text' | 'course-picker' | 'photo-grid' | 'photo-import' | 'photo-capture' | 'page' | 'grid' | 'footer' | 'disclosure' | 'course-list' | 'data-list' | 'number' | 'slider' | 'card' | 'group' | 'container' | 'safe-area' | 'drag-source' | 'drop-target' | 'map-view' | 'map-marker' | 'map-polyline' | 'map-circle' | 'map-fit-bounds'; min?: number; max?: number; step?: number; size?: number; limit?: number; columns?: number; kind?: 'image' | 'video' | 'audio' | 'bar' | 'sheet' | 'fullScreen'; style?: Style; text?: string; label?: string; key?: string; query?: CampusQuery; arguments?: Record<string,string>; action?: 'save' | 'reset' | 'todo.create' | 'state.set' | 'state.increment' | 'runtime.event'; options?: string[]; equals?: string; url?: string; children?: Node[] };
export interface Extension { schemaVersion: 1; minimumHostAPI?: number; name: string; version: string; description: string; permissions: Permission[]; network?: string[]; content: Node[]; runtime?: { engine: 'quickjs-v1'; code: string } }
export const defineExtension = (value: Omit<Extension, 'schemaVersion'>): Extension => ({ schemaVersion: 1, ...value });
// These descriptors request data from the native host at display time, not build time.
export const campus = {
 courseNotes: (): CampusQuery => 'courseNotes.data',
 periods: (): CampusQuery => 'timetable.periods',
 courseData: (): CampusQuery => 'courses.data', assignmentData: (): CampusQuery => 'assignments.data', todoData: (): CampusQuery => 'todos.data',
 academicCalendar: (): CampusQuery => 'academic.calendar',
 displaySettings: (): CampusQuery => 'settings.display',
 currentClass: (): CampusQuery => 'courses.current', nextClass: (): CampusQuery => 'courses.next',
 today: (): CampusQuery => 'courses.today', week: (): CampusQuery => 'courses.week',
 enrollment: (): CampusQuery => 'enrollment.summary', pendingAssignments: (): CampusQuery => 'assignments.pending',
 workload: (): CampusQuery => 'assignments.summary', overdue: (): CampusQuery => 'assignments.overdue',
 dueSoon: (): CampusQuery => 'assignments.dueSoon', todos: (): CampusQuery => 'todos.summary'
};
export const actions = {
 setField: (label: string, field: string, value: string): Node => ({type:'button',label,action:'state.set',arguments:{field,value}}),
 increment: (label: string, field: string, amount = 1): Node => ({type:'button',label,action:'state.increment',arguments:{field,amount:String(amount)}}),

 createTodo: (label: string, titleField: string, detailField: string, deadlineField?: string, notificationField?: string): Node => ({type:'button',label,action:'todo.create',arguments:{title:titleField,detail:detailField,...(deadlineField?{deadline:deadlineField}:{}),...(notificationField?{notification:notificationField}:{})}})
};
export type AnimationOptions = { duration?: number; curve?: 'linear' | 'easeIn' | 'easeOut' | 'easeInOut' | 'spring'; damping?: number };
export const animation = {
  async animate<T>(options: AnimationOptions, update: () => T | Promise<T>): Promise<T> {
    const duration = options.duration ?? 0.25;
    if (!Number.isFinite(duration) || duration < 0.05 || duration > 1.5) throw new Error('animation_duration_invalid');
    const curve = options.curve ?? 'easeInOut';
    if (!['linear', 'easeIn', 'easeOut', 'easeInOut', 'spring'].includes(curve)) throw new Error('animation_curve_invalid');
    const damping = options.damping ?? 0.82;
    if (!Number.isFinite(damping) || damping < 0.4 || damping > 1) throw new Error('animation_damping_invalid');
    globalThis.__citSetAnimation?.({ duration, curve, damping });
    return await update();
  },
  spring<T>(update: () => T | Promise<T>, options: Omit<AnimationOptions, 'curve'> = {}): Promise<T> {
    return animation.animate({ ...options, curve: 'spring' }, update);
  },
  transition<T>(update: () => T | Promise<T>, options: AnimationOptions = {}): Promise<T> {
    return animation.animate(options, update);
  }
};
export const ui = {
 textField: interactive.textField,
 searchField: interactive.searchField,
 stepper: interactive.stepper,
 checkbox: interactive.checkbox,
 radio: interactive.radio,
 multiSelect: interactive.multiSelect,
 dateTime: interactive.dateTime,
 dateRange: interactive.dateRange,
 time: (key: string, label: string, value: State<number|null>): Node => ({...interactive.dateTime(key,label,value),arguments:{mode:'time'}}),
 filePicker: interactive.file,
 photoPicker: (key: string, label: string, value: State<string>): Node => ({...interactive.file(key,label,value),arguments:{kind:'image'}}),
 textArea: (key: string, label: string, value?: State<string>): Node => value ? interactive.textArea(key,label,value) : ({type:'text-area',key,label}),
 iconButton: interactive.iconButton,
 alert: dialogs.alert,
 confirm: dialogs.confirm,
 prompt: dialogs.prompt,
 actionSheet: dialogs.actionSheet,
 toast: (text: string, duration = 3000): void => showNotice(text,duration),
 banner: (text: string, duration = 6000): void => showNotice(text,duration,true),
 menu: (label: string, actions: Node[]): Node => ({type:'menu',label,children:actions}),
 contextMenu: (content: Node, actions: Node[]): Node => ({type:'context-menu',children:[content,...actions]}),
 swipeActions: (content: Node, actions: Node[]): Node => ({type:'swipe-actions',children:[content,...actions]}),
 toolbar: (children: Node[]): Node => ({type:'toolbar',children}),
 floatingButton: (label: string, onPress: () => unknown, content: Node[] = []): Node => ({type:'floating-button',children:[{type:'column',children:content},interactive.button(label,onPress)]}),
 lazyGrid: (columns: number, children: Node[]): Node => ({type:'lazy-grid',columns,children}),
 list: <T>(items: ExtensionList<T>): Node => items.render(),
 lazyList: <T>(items: ExtensionList<T>): Node => items.render(true),
 sectionedList: <T>(sections: {title:string;list:ExtensionList<T>}[]): Node => ({type:'lazy-list',children:sections.map(section=>({type:'section',label:section.title,children:[section.list.render(true)]}))}),
 label: (text: string): Node => ({type:'label',text}),
 markdown: (text: string): Node => ({type:'markdown',text}),
 code: (text: string): Node => ({type:'code',text}),
 caption: (text: string): Node => ({type:'caption',text}),
 badge: (text: string, tone: Style['tone'] = 'secondary'): Node => ({type:'badge',text,style:{tone}}),
 icon: (name: string, accessibilityLabel: string): Node => ({type:'icon',text:name,label:accessibilityLabel}),
 number: (key: string, label: string, min = 0, max = 100, step = 1): Node => ({type:'number',key,label,min,max,step}),
 slider: (key: string, label: string, min = 0, max = 100, step = 1): Node => ({type:'slider',key,label,min,max,step}),

 dataList: (key: string, query: 'courses.data' | 'timetable.periods' | 'assignments.data' | 'todos.data' | 'academic.calendar' | 'bus.schedule' | 'cafeteria.locations' | 'cafeteria.menu' | 'cafeteria.cameraStatus', children: Node[], pageSize = 20): Node => ({type:'data-list',key,query,children,limit:pageSize}),

 page: (label: string, children: Node[]): Node => ({type:'page',label,children}),
 scroll: (children: Node[]): Node => ({type:'scroll',children}),
 horizontalScroll: (children: Node[]): Node => ({type:'horizontal-scroll',children}),
 grid: (columns: number, children: Node[]): Node => ({type:'grid',columns,children}),
 footer: (children: Node[]): Node => ({type:'footer',children}),
 disclosure: (label: string, children: Node[]): Node => ({type:'disclosure',label,children}),
 courseList: (key: string, label: string, children: Node[]): Node => ({type:'course-list',key,label,children}),

 coursePicker: (key: string, label: string): Node => ({type:'course-picker',key,label}),
 photoGrid: (key: string, label: string, courseField?: string, columns = 3): Node => ({type:'photo-grid',key,label,columns,arguments:courseField?{course:courseField}:undefined}),
 importPhotos: (key: string, label: string, courseField?: string): Node => ({type:'photo-import',key,label,arguments:courseField?{course:courseField}:undefined}),
 capturePhoto: (key: string, label: string, courseField?: string): Node => ({type:'photo-capture',key,label,arguments:courseField?{course:courseField}:undefined}),
 shareText: (label: string, text: string): Node => ({type:'share-text',label,text}),
 copyText: (label: string, text: string): Node => ({type:'copy-text',label,text}),
 boardCamera: (label = '授業別の写真・撮影'): Node => ({type:'board-camera',label}),
 image: (label: string,url: string): Node => ({type:'media',kind:'image',label,url}),
 video: (label: string,url: string): Node => ({type:'media',kind:'video',label,url}),
 audio: (label: string,url: string): Node => ({type:'media',kind:'audio',label,url}),
 browser: (label: string, url: string): Node => ({type:'browser',label,url}),
 file: (key: string,label: string): Node => ({type:"file",key,label}),
 date: (key: string,label: string,value?: State<number|null>): Node => value ? ({...interactive.dateTime(key,label,value),arguments:{mode:'date'}}) : ({type:"date",key,label}),
 styled: (node: Node, style: Style): Node => ({...node,style}),
 heading: (text: string): Node => ({type:'heading',text}),
 divider: (): Node => ({type:'divider'}),
 select: (key: string, label: string, options: string[]): Node => ({type:'select',key,label,options}),
 when: (key: string, equals: string, children: Node[]): Node => ({type:'when',key,equals,children}),
 link: (label: string, url: string): Node => ({type:'link',label,url}),
 linkButton: (label: string, url: string): Node => ({type:'link-button',label,url}),
 text: (text: string): Node => ({ type:'text',text }),
 data: (query: CampusQuery, label?: string): Node => ({ type:'campus',query,label }),
 section: (label: string, children: Node[]): Node => ({ type:'section',label,children }),
 card: (children: Node[], label?: string): Node => ({ type:'card',label,children }),
 group: (children: Node[]): Node => ({ type:'group',children }),
 container: (children: Node[]): Node => ({ type:'container',children }),
 safeArea: (children: Node[]): Node => ({ type:'safe-area',children }),
 frame: (node: Node, frame: Pick<Style,'minWidth'|'maxWidth'|'minHeight'|'maxHeight'|'aspectRatio'>): Node => ({...node,style:{...node.style,...frame}}),
 column: (children: Node[]): Node => ({ type:'column',children }),
 row: (children: Node[]): Node => ({ type:'row',children }),
 vstack: (children: Node[]): Node => ({ type:'column',children }),
 hstack: (children: Node[]): Node => ({ type:'row',children }),
 zstack: (children: Node[]): Node => ({ type:'zstack',children }),
 spacer: (size = 12): Node => ({ type:'spacer',size }),
 progress: (label: string,value: number): Node => ({ type:'progress',label,value:String(value) }),
 barChart: (label: string, categories: string[], series: Array<{label:string;values:number[]}>): Node => ({type:'chart',kind:'bar',label,options:categories,arguments:{series:JSON.stringify(series)}}),
 loading: (label: string): Node => ({ type:'loading',label }),
 emptyState: (title: string,message: string): Node => ({ type:'empty-state',label:title,text:message }),
 errorState: (title: string,message: string): Node => ({ type:'error-state',label:title,text:message }),
 field: (key: string, label: string): Node => ({ type:'field',key,label }),
 secureField: (key: string, label: string, value?: State<string>): Node => value ? interactive.secureField(key,label,value) : ({ type:'secure-field',key,label,value:'' }),
 toggle: (key: string, label: string, value?: State<boolean>): Node => value ? interactive.toggle(key,label,value) : ({ type:'toggle',key,label }),
 button: (label: string, action: 'save' | 'reset' | (() => unknown)): Node => typeof action === 'function' ? interactive.button(label,action) : ({ type:'button',label,action }),
};

export { state, math, text, json, date, ExtensionError, ValidationError, PermissionError, UserInteractionError, UnsupportedError, NetworkError, StorageError, RateLimitError, ConflictError, NotFoundError } from "./core";
export type { State, DateInput } from "./core";

export { utils, geo } from "./core";
export type { Coordinate } from "./core";

export { defineProgram, interactive } from "./program";
export type { ButtonEvents, Program } from "./program";

export { storage, cloudUser, capabilities, app, cit, network, files, location, browser, share, analytics, scanner } from "./host";
export type { ScannedDocumentInfo } from "./host";

export { secureStorage } from "./host";
export { auth } from './auth';
export type { OAuthProvider, OAuthSession, OIDCSession } from './auth';
export { crypto } from './crypto';
export { database } from './database';
export type { Transaction, RecordValue } from './database';
export type { EncryptedText } from './crypto';
export { permissions } from './host';
export type { PermissionStatus } from './host';
export type { LocationFix } from './host';
export { clipboard } from './host';
export { notification } from './host';
export type { LocalNotificationInput, NotificationRepeat, ScheduledLocalNotification } from './host';
export { haptics } from './haptics';
export { map } from './maps';
export type { MapCoordinate, DirectionsOptions, MapViewOptions, MapMarkerOptions, MapShapeOptions } from './maps';
export { device } from './device';
export type { DeviceInfo, DeviceScreen } from './device';
export type { PersonalTodo, TodoFields } from './host';
export type { NetworkMethod, NetworkOptions, NetworkResponse, NetworkStatus, NetworkTransport } from './host';
export type { ExtensionWebSocket, NetworkTransferProgress, NetworkProgressHandler } from './host';
export type { ExtensionFileInfo, SelectedFileInfo, PickedFileInfo, FilePickerKind } from './host';
export type { ShareItem } from './host';
export { keyboard } from './keyboard';
export { accessibility } from './accessibility';
export type { AccessibilityStatus, AccessibilityRole, AccessibilityAttributes } from './accessibility';
export { navigation } from './navigation';
export { console, debug } from './debug';
export type { ExtensionRoute, RouteParameters, RouteRenderer } from './navigation';
export { list, ExtensionList } from './lists';
export type { ListOptions } from './lists';
export { field } from './fields';
export type { FieldState } from './fields';
export { connectivity, cloud, webView } from './host';
export { background } from './host';
export type { BackgroundAvailability, BackgroundStatus } from './host';
export { search, host, widget, shortcuts, push, backgroundTasks } from './platform';
export type { SearchItem, HostAction, WidgetDefinition, BackgroundTask } from './platform';
export { image } from './image';
export type { ImageSource, ImageResult, ImageOptions } from './image';
export { canvas, ExtensionCanvas } from './canvas';
export type { DrawingStyle, DrawingColor, PathSegment } from './canvas';
export { chart } from './charts';
export type { ChartSeries, ScatterSeries } from './charts';
export { photos, video, pdf, audio } from './media';
export type { ImageInfo, VideoInfo, PDFInfo } from './media';
export type { PDFPageInput, GeneratedThumbnail } from './media';
export { camera, code } from './camera';
export type { ScannedCode } from './camera';
export { server } from './server';
export type { ServerRecord, ServerFilter, ServerQuery, ServerOperation, ServerResult, ServerFunctionContext, ServerFunctionHandler, CronRegistration, CronStatus } from './server';
export { sensors } from './sensors';
export type { MotionVector, MotionOrientation } from './sensors';
export { drag, drop } from './drag';
export { groups, shared, realtime } from './collaboration';
export { intent } from './intents';
export type { IntentHandler } from './intents';
export { extensions, link } from './integration';
export type { HostPage, HostService } from './integration';
export type { ExtensionGroup, GroupMember, GroupInvitation, SharedValue, RealtimeMessage, RealtimeSubscribeOptions } from './collaboration';
