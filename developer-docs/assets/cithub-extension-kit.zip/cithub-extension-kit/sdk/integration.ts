import { ValidationError } from './core';
import { call } from './host';

export type HostPage = 'timetable' | 'todo' | 'services' | 'extensions' | 'settings';
export type HostService = 'manaba' | 'portal' | 'cafeteria' | 'bus';
const extensionID = (id: string): string => {
  if (typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)) throw new ValidationError('extension_id_invalid');
  return id;
};
export function openHostPage(page: HostPage): Promise<void> {
  if (!['timetable','todo','services','extensions','settings'].includes(page)) throw new ValidationError('host_page_invalid');
  return call('host.navigate', { kind: 'page', value: page });
}
export function openHostService(service: HostService): Promise<void> {
  if (!['manaba','portal','cafeteria','bus'].includes(service)) throw new ValidationError('host_service_invalid');
  return call('host.navigate', { kind: 'service', value: service });
}
export const extensions = {
  isInstalled(id: string): Promise<boolean> { return call('extension.route', { action: 'lookup', id: extensionID(id) }); },
  open(id: string): Promise<void> { return call('extension.route', { action: 'open', id: extensionID(id) }); },
  request(id: string): Promise<void> { return call('extension.route', { action: 'request', id: extensionID(id) }); }
};
export const link = {
  create(id: string): Promise<string> { return call('extension.route', { action: 'link', id: extensionID(id) }); },
  open(url: string): Promise<void> {
    if (typeof url !== 'string') throw new ValidationError('extension_link_invalid');
    const match = /^(?:https:\/\/developer\.cithub\.app\/extensions\/|cithub:\/\/extensions\?id=)([a-f0-9]{32})$/.exec(url);
    if (!match) throw new ValidationError('extension_link_invalid');
    return extensions.request(match[1]);
  }
};
