import { UnsupportedError, ValidationError } from './core';
import { call } from './host';

const identifier = (value: string, label = 'id') => {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$/.test(value)) throw new ValidationError(`Invalid ${label}`);
  return value;
};
const shortText = (value: string, max: number, label: string) => {
  if (typeof value !== 'string' || !value.trim() || value.length > max) throw new ValidationError(`Invalid ${label}`);
  return value.trim();
};
const utf8ByteLength = (value: string) => {
  let bytes = 0;
  for (const character of value) {
    const point = character.codePointAt(0)!;
    bytes += point <= 0x7f ? 1 : point <= 0x7ff ? 2 : point <= 0xffff ? 3 : 4;
  }
  return bytes;
};

export interface BackgroundTask {
  id: string;
  intervalMinutes: number;
  networkRequired?: boolean;
  chargingRequired?: boolean;
}
export const backgroundTasks = {
  status(): Promise<{ availability: 'available'|'denied'|'restricted'|'unknown'|'unsupported'; mayRun: boolean|null; platform: string; note: string }> {
    return call('background.status');
  },
  /** Schedules an approved serverFunctions export on the Mac mini best-effort scheduler. */
  register(task: BackgroundTask): Promise<{ id: string; accepted: boolean }> {
    if (!task || !Number.isInteger(task.intervalMinutes) || task.intervalMinutes < 15 || task.intervalMinutes > 1440) throw new ValidationError('Background interval must be between 15 and 1440 minutes');
    if (task.chargingRequired === true) throw new UnsupportedError('background_charging_condition_unsupported');
    if (task.networkRequired === false) throw new UnsupportedError('background_offline_execution_unsupported');
    const id = identifier(task.id);
    return call<{ name: string; registered: boolean }>('server.cron', {
      action: 'register', name: id, input: null, intervalSeconds: task.intervalMinutes * 60
    }).then(result => ({ id, accepted: result.registered }));
  },
  unregister(id: string): Promise<boolean> {
    return call<{ name: string; registered: boolean }>('server.cron', { action: 'unregister', name: identifier(id) }).then(result => !result.registered);
  }
};

export interface SearchItem { id: string; title: string; description?: string; keywords?: string[]; route?: string }
export const search = {
  registerItems(items: SearchItem[]): Promise<{ indexed: number }> {
    if (!Array.isArray(items) || items.length < 1 || items.length > 100) throw new ValidationError('Search index must contain 1 to 100 items');
    const normalized = items.map(item => {
      if (!item || !Array.isArray(item.keywords ?? []) || (item.keywords?.length ?? 0) > 20 || (item.keywords ?? []).some(word => typeof word !== 'string' || word.length > 80)) throw new ValidationError('Invalid search item');
      return { id: identifier(item.id), title: shortText(item.title, 120, 'title'), description: (item.description ?? '').slice(0, 500), keywords: item.keywords ?? [], route: item.route ? identifier(item.route, 'route') : undefined };
    });
    return call('search.registerItems', { items: normalized });
  },
  removeItems(ids: string[]): Promise<{ removed: number }> {
    if (!Array.isArray(ids) || ids.length < 1 || ids.length > 100) throw new ValidationError('Expected 1 to 100 search item IDs');
    return call('search.removeItems', { ids: ids.map(id => identifier(id)) });
  }
};

export type HostActionRoute = 'page:timetable' | 'page:todo' | 'page:services' | 'page:extensions' | 'page:settings' | 'service:manaba' | 'service:portal' | 'service:cafeteria' | 'service:bus';
export interface HostAction { id: string; title: string; symbol?: string; route: HostActionRoute }
const actionRoute = (route: string): HostActionRoute => {
  if (!['page:timetable', 'page:todo', 'page:services', 'page:extensions', 'page:settings', 'service:manaba', 'service:portal', 'service:cafeteria', 'service:bus'].includes(route)) throw new ValidationError('Invalid host action route');
  return route as HostActionRoute;
};
export const host = {
  /** Adds an account-scoped tile in CIT Hub. Android also exposes it in the launcher; Apple hosts expose it through the CIT Hub App Shortcut action in the Shortcuts app. */
  registerShortcut(value: HostAction): Promise<{ registered: boolean }> {
    return call('host.registerShortcut', { id: identifier(value.id), title: shortText(value.title, 40, 'title'), symbol: value.symbol?.slice(0, 40), route: actionRoute(value.route) });
  },
  registerAction(value: HostAction): Promise<{ registered: boolean }> {
    return call('host.registerAction', { id: identifier(value.id), title: shortText(value.title, 40, 'title'), symbol: value.symbol?.slice(0, 40), route: actionRoute(value.route) });
  }
};

export interface WidgetDefinition { id: string; kind: 'small' | 'medium' | 'large'; title: string; refreshMinutes?: number; fields: Array<{ key: string; label: string; source: string }> }
export const widget = {
  define(value: WidgetDefinition): Promise<{ registered: boolean }> {
    if (!value || !['small', 'medium', 'large'].includes(value.kind) || !Array.isArray(value.fields) || value.fields.length < 1 || value.fields.length > 12 || !Number.isInteger(value.refreshMinutes ?? 60) || (value.refreshMinutes ?? 60) < 15 || (value.refreshMinutes ?? 60) > 1440) throw new ValidationError('Invalid widget definition');
    const fields = value.fields.map(field => ({ key: identifier(field.key), label: shortText(field.label, 50, 'field label'), source: shortText(field.source, 120, 'field source') }));
    if (new Set(fields.map(field => field.key)).size !== fields.length) throw new ValidationError('Widget field IDs must be unique');
    return call('widget.define', { id: identifier(value.id), kind: value.kind, title: shortText(value.title, 50, 'title'), refreshMinutes: value.refreshMinutes ?? 60, fields });
  },
  reload(id: string): Promise<{ queued: boolean }> { return call('widget.reload', { id: identifier(id) }); }
};

export const shortcuts = {
  /** Registers an account-scoped shortcut. Android publishes a dynamic launcher entry; Apple hosts expose registered items through a generic App Shortcut action in the Shortcuts app. */
  register(value: HostAction): Promise<{ registered: boolean }> {
    return call('shortcuts.register', { id: identifier(value.id), title: shortText(value.title, 40, 'title'), symbol: value.symbol?.slice(0, 40), route: actionRoute(value.route) });
  }
};

export const push = {
  sendToCurrentUser(value: { title: string; body: string; data?: Record<string, string> }): Promise<{ accepted: boolean }> {
    if (!value || value.data !== undefined && (!value.data || typeof value.data !== 'object' || Array.isArray(value.data) || Object.keys(value.data).length > 10 || Object.entries(value.data).some(([key, text]) => !/^[A-Za-z][A-Za-z0-9_.-]{0,39}$/.test(key) || typeof text !== 'string' || text.length > 300))) throw new ValidationError('Invalid push payload');
    const data = value.data ?? {};
    if (utf8ByteLength(JSON.stringify(data)) > 800) throw new ValidationError('Invalid push payload');
    return call('push.sendToCurrentUser', { title: shortText(value.title, 80, 'title'), body: shortText(value.body, 300, 'body'), data });
  }
};
