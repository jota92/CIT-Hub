import type { Node } from './index';
import { ValidationError } from './core';
import { interactive } from './program';
import { extensions, openHostPage } from './integration';

export type RouteParameters = Record<string, string | number | boolean | null>;
export type RouteRenderer = (parameters: RouteParameters) => Node[];
export interface ExtensionRoute { name: string; title: string; render: RouteRenderer; onOpen?: () => void; onClose?: () => void }
interface Entry { id: number; route: ExtensionRoute; parameters: RouteParameters; mode: 'page' | 'sheet' | 'fullScreen' }
const routes = new Map<string, ExtensionRoute>();
const pages: Entry[] = [];
const modals: Entry[] = [];
let sequence = 0;
const invalidate = () => (globalThis as { __citInvalidate?: () => void }).__citInvalidate?.();
function entry(name: string, parameters: RouteParameters, mode: Entry['mode']): Entry {
  const route = routes.get(name);
  if (!route) throw new ValidationError('navigation_route_unknown');
  if (!parameters || Array.isArray(parameters) || Object.keys(parameters).length > 20 ||
      Object.entries(parameters).some(([key, value]) => !/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key) ||
        !(['string', 'number', 'boolean'].includes(typeof value) || value === null) ||
        typeof value === 'number' && !Number.isFinite(value)) || JSON.stringify(parameters).length > 4000)
    throw new ValidationError('navigation_parameters_invalid');
  if (pages.length + modals.length >= 16) throw new ValidationError('navigation_stack_limit');
  return { id: ++sequence, route, parameters: { ...parameters }, mode };
}
export const navigation = {
  openExtension: extensions.open,
  openHostPage,
  register(route: ExtensionRoute): () => void {
    if (!/^[A-Za-z][A-Za-z0-9_.-]{0,79}$/.test(route.name) || !route.title?.trim() || route.title.length > 120 || typeof route.render !== 'function')
      throw new ValidationError('navigation_route_invalid');
    if (routes.has(route.name)) throw new ValidationError('navigation_route_exists');
    routes.set(route.name, { ...route });
    return () => { if (![...pages, ...modals].some(value => value.route.name === route.name)) routes.delete(route.name); };
  },
  push(name: string, parameters: RouteParameters = {}): void {
    const value = entry(name, parameters, 'page');
    pages.push(value); invalidate(); value.route.onOpen?.();
  },
  pop(): boolean {
    const value = pages.pop();
    if (!value) return false;
    invalidate(); value.route.onClose?.(); return true;
  },
  popToRoot(): void {
    const removed = pages.splice(0).reverse(); invalidate();
    removed.forEach(value => value.route.onClose?.());
  },
  present(name: string, parameters: RouteParameters = {}, mode: 'sheet' | 'fullScreen' = 'sheet'): void {
    if (!['sheet', 'fullScreen'].includes(mode)) throw new ValidationError('navigation_presentation_invalid');
    // A single native presentation avoids competing sheets and modal deadlocks.
    if (modals.length) throw new ValidationError('navigation_presentation_busy');
    const value = entry(name, parameters, mode);
    modals.push(value); invalidate(); value.route.onOpen?.();
  },
  sheet(name: string, parameters: RouteParameters = {}): void { navigation.present(name, parameters, 'sheet'); },
  fullScreen(name: string, parameters: RouteParameters = {}): void { navigation.present(name, parameters, 'fullScreen'); },
  dismiss(): boolean {
    const value = modals.pop();
    if (!value) return false;
    invalidate(); value.route.onClose?.(); return true;
  },
  tabs(tabs: { id: string; title: string; render: () => Node[] }[], selected: import('./core').State<string>): Node {
    if (!tabs.length || tabs.length > 6 || new Set(tabs.map(tab => tab.id)).size !== tabs.length ||
        tabs.some(tab => !tab.id || !tab.title?.trim() || tab.title.length > 120 || typeof tab.render !== 'function'))
      throw new ValidationError('navigation_tabs_invalid');
    const current = tabs.find(tab => tab.id === selected.value) ?? tabs[0];
    return { type: 'column', children: [
      { type: 'row', children: tabs.map(tab => ({...interactive.button(tab.title, () => selected.set(tab.id)),style:{tone:tab.id===current.id?'accent' as const:'secondary' as const},accessibility:{hint:tab.id===current.id?'選択中':'このタブを表示'}})) },
      ...current.render()
    ] };
  }
};
// mountProgram is the sole integration point; extension code never accesses native view controllers.
export function renderNavigation(root: () => Node[]): Node[] {
  const current = pages[pages.length - 1];
  const result = current ? [interactive.button('戻る', () => navigation.pop()), { type: 'heading' as const, text: current.route.title }, ...current.route.render(current.parameters)] : root();
  const modal = modals[0];
  if (!modal) return result;
  const close = interactive.button('閉じる', () => navigation.dismiss());
  return [...result, {
    type: 'presentation', key: `presentation${modal.id}`, label: modal.route.title,
    kind: modal.mode === 'fullScreen' ? 'fullScreen' : 'sheet', arguments: { event: close.arguments!.event },
    children: [close, ...modal.route.render(modal.parameters)]
  }];
}
