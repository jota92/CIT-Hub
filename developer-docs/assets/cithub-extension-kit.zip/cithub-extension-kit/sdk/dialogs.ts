import { ValidationError } from './core';
import { call } from './host';
import type { Node } from './index';
export type ActionSheetItem = { id: string; title: string; destructive?: boolean };
async function dialog<T>(kind: string, title: string, message: string, options: Record<string, unknown> = {}): Promise<T> {
  if (typeof title !== 'string' || !title.trim() || title.length > 120 || typeof message !== 'string' || message.length > 4000)
    throw new ValidationError('dialog_text_invalid');
  return call<T>('ui.dialog', { kind, title, message, ...options });
}
export const dialogs = {
  alert: (title: string, message = ''): Promise<void> => dialog('alert', title, message),
  confirm: (title: string, message = ''): Promise<boolean> => dialog('confirm', title, message),
  prompt: (title: string, message = '', initialValue = ''): Promise<string | null> => {
    if (typeof initialValue !== 'string' || initialValue.length > 4000) throw new ValidationError('dialog_input_invalid');
    return dialog('prompt', title, message, { initialValue });
  },
  actionSheet(title: string, items: ActionSheetItem[], message = ''): Promise<string | null> {
    if (!Array.isArray(items) || items.length < 1 || items.length > 8 || new Set(items.map(item => item.id)).size !== items.length ||
        items.some(item => !/^[A-Za-z][A-Za-z0-9_.-]{0,79}$/.test(item.id) || typeof item.title !== 'string' || !item.title.trim() || item.title.length > 120 || item.destructive !== undefined && typeof item.destructive !== 'boolean'))
      throw new ValidationError('dialog_actions_invalid');
    return dialog('actions', title, message, { items });
  }
};
let notice: { text: string; banner: boolean } | null = null;
let timer: ReturnType<typeof setTimeout> | undefined;
const invalidate = () => (globalThis as { __citInvalidate?: () => void }).__citInvalidate?.();
export function showNotice(text: string, duration = 3000, banner = false): void {
  if (typeof text !== 'string' || !text.trim() || text.length > 1000 || !Number.isFinite(duration) || duration < 500 || duration > 30000)
    throw new ValidationError('notice_invalid');
  if (timer !== undefined) clearTimeout(timer);
  notice = { text, banner }; invalidate();
  timer = setTimeout(() => { notice = null; timer = undefined; invalidate(); }, duration);
}
export function renderNotice(): Node[] {
  return notice ? [{ type: 'label', text: notice.text, accessibility: { label: notice.text }, style: { tone: notice.banner ? 'accent' : 'secondary' } }, { type: 'divider' }] : [];
}
