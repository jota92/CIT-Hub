import { UnsupportedError, ValidationError } from './core';
declare const __citCall:(request:string)=>Promise<string>;
export const keyboard = {
  async focus(key:string):Promise<void> {
    if(!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key))throw new ValidationError('Invalid input key');
    const reply=JSON.parse(await __citCall(JSON.stringify({operation:'keyboard.focus',args:{key}})));
    if(reply.error==='unsupported')throw new UnsupportedError(reply.error);
    if(reply.error)throw new ValidationError(reply.error);
  },
  async dismiss():Promise<void> {
    const reply=JSON.parse(await __citCall(JSON.stringify({operation:'keyboard.dismiss',args:{}})));
    if(reply.error)throw new UnsupportedError(reply.error);
  }
};
