import { ValidationError, utf8ByteLength } from './core';
import { call } from './host';

export interface ExtensionGroup { id:string; name:string; role:'owner'|'member'; memberID:string; createdAt:string }
export interface GroupMember { id:string; role:'owner'|'member'; joinedAt:string }
export interface GroupInvitation { invitation:string; expiresAt:string; maxUses:number }
export interface SharedValue<T=unknown> { key:string; value:T; revision:number; authorID:string; updatedAt:string }
const request=<T>(args:unknown):Promise<T>=>call('server.collaboration',args);
const groupID=(value:string)=>{if(typeof value!=='string'||!/^[a-f0-9]{32}$/.test(value))throw new ValidationError('group_invalid');return value;};
const key=(value:string)=>{if(typeof value!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,99}$/.test(value))throw new ValidationError('key_invalid');return value;};
const revision=(value:number)=>{if(!Number.isSafeInteger(value)||value<1)throw new ValidationError('revision_required');return value;};
export const groups = {
  list: ():Promise<ExtensionGroup[]>=>request({action:'list'}),
  create(name:string):Promise<ExtensionGroup>{
    if(typeof name!=='string'||!name.trim()||name.length>80)throw new ValidationError('group_name_invalid');
    return request({action:'createGroup',name:name.trim()});
  },
  join(invitation:string):Promise<ExtensionGroup|null>{
    if(typeof invitation!=='string'||!/^[a-f0-9]{64}$/.test(invitation))throw new ValidationError('invitation_invalid');
    return request({action:'join',invitation});
  },
  leave(id:string):Promise<{left:true}|null>{return request({action:'leave',groupID:groupID(id)});},
  members(id:string):Promise<GroupMember[]>{return request({action:'members',groupID:groupID(id)});},
  invite(id:string,options:{expiresInHours?:number;maxUses?:number}={}):Promise<GroupInvitation>{
    const expiresInHours=options.expiresInHours??24,maxUses=options.maxUses??1;
    if(!Number.isInteger(expiresInHours)||expiresInHours<1||expiresInHours>168||!Number.isInteger(maxUses)||maxUses<1||maxUses>100)throw new ValidationError('invitation_invalid');
    return request({action:'invite',groupID:groupID(id),expiresInHours,maxUses});
  }
};
export const shared = {
  create<T>(group:string,name:string,value:T):Promise<SharedValue<T>>{return request({action:'create',groupID:groupID(group),key:key(name),value});},
  read<T=unknown>(group:string,name:string):Promise<SharedValue<T>|null>{return request({action:'read',groupID:groupID(group),key:key(name)});},
  update<T>(group:string,name:string,value:T,expectedRevision:number):Promise<SharedValue<T>>{return request({action:'update',groupID:groupID(group),key:key(name),value,expectedRevision:revision(expectedRevision)});},
  delete(group:string,name:string,expectedRevision:number):Promise<{deleted:true}>{return request({action:'delete',groupID:groupID(group),key:key(name),expectedRevision:revision(expectedRevision)});}
};

export interface RealtimeMessage<T=unknown> { sequence:number; value:T; sentAt:string }
export interface RealtimeSubscribeOptions { pollIntervalMs?:number; onError?:(error:unknown)=>unknown }
const realtimeTopic=(value:string)=>{
  if(typeof value!=='string'||!/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/.test(value))throw new ValidationError('realtime_topic_invalid');
  return `rt.${value}`;
};
function realtimePayload(value:unknown):unknown {
  let text:string;
  try{text=JSON.stringify(value);}catch{throw new ValidationError('realtime_payload_invalid');}
  if(typeof text!=='string'||utf8ByteLength(text)>12*1024)throw new ValidationError('realtime_payload_too_large');
  return JSON.parse(text);
}
export const realtime = {
  async publish<T>(group:string,topic:string,value:T):Promise<RealtimeMessage<T>> {
    const safeGroup=groupID(group),safeTopic=realtimeTopic(topic),safeValue=realtimePayload(value);
    const result=await request<SharedValue<RealtimeMessage<T>>>({action:'publish',groupID:safeGroup,key:safeTopic,value:safeValue});
    return result.value;
  },
  subscribe<T>(group:string,topic:string,onMessage:(message:RealtimeMessage<T>)=>unknown,options:RealtimeSubscribeOptions={}):()=>void {
    const safeGroup=groupID(group),safeTopic=realtimeTopic(topic);
    if(typeof onMessage!=='function')throw new ValidationError('realtime_callback_required');
    if(options.onError!==undefined&&typeof options.onError!=='function')throw new ValidationError('realtime_callback_invalid');
    const interval=options.pollIntervalMs??2500;
    if(!Number.isInteger(interval)||interval<1000||interval>30000)throw new ValidationError('realtime_interval_invalid');
    let active=true,lastSequence=0,delay=interval,pendingTimer:ReturnType<typeof setTimeout>|undefined;
    const poll=async()=>{
      if(!active)return;
      try {
        const current=await shared.read<{sequence:number;value:T;sentAt:string}>(safeGroup,safeTopic);
        const event=current?.value;
        if(event&&Number.isSafeInteger(event.sequence)&&event.sequence>lastSequence&&typeof event.sentAt==='string'){
          lastSequence=event.sequence;
          try{await onMessage(event);}catch(error){try{options.onError?.(error);}catch{}}
        }
        delay=interval;
      } catch(error) {
        try{options.onError?.(error);}catch{}
        delay=Math.min(30000,Math.max(interval,delay*2));
      }
      if(active)pendingTimer=setTimeout(()=>{pendingTimer=undefined;void poll();},delay);
    };
    void poll();
    return ()=>{active=false;if(pendingTimer!==undefined)clearTimeout(pendingTimer);pendingTimer=undefined;};
  }
};
