import { UnsupportedError } from './core';
declare const __citCall:(request:string)=>Promise<string>;
export interface DeviceScreen { width:number; height:number; scale:number; fontScale:number; orientation:'portrait'|'landscape' }
export interface DeviceInfo {
  platform:'ios'|'macos'|'android';osVersion:string;deviceClass:'phone'|'tablet'|'desktop';
  screen:DeviceScreen;locale:string;timezone:string;appearance:'light'|'dark';capabilities:string[];
}
async function info():Promise<DeviceInfo> {
  const reply=JSON.parse(await __citCall(JSON.stringify({operation:'device.info',args:{}})));
  if(reply.error)throw new UnsupportedError(reply.error);
  return reply.result;
}
export const device = {
  info,
  platform:async()=> (await info()).platform,
  osVersion:async()=> (await info()).osVersion,
  deviceClass:async()=> (await info()).deviceClass,
  screen:async()=> (await info()).screen,
  locale:async()=> (await info()).locale,
  timezone:async()=> (await info()).timezone,
  appearance:async()=> (await info()).appearance,
  capabilities:async()=> (await info()).capabilities
};
