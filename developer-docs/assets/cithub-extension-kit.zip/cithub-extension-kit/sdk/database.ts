import { storage, app } from './host';
import { ValidationError, StorageError } from './core';
export type RecordValue = { id: string; [key: string]: unknown };
type Tables = Record<string, RecordValue[]>;
const valid = (name: string) => { if (['__proto__','constructor','prototype'].includes(name) || !/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(name)) throw new ValidationError('Invalid table'); return name; };
const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));
const listeners = new Map<string, Set<(rows: RecordValue[]) => void>>();
const snapshots = new Map<string,string>();
const watchErrors = new Map<(rows:RecordValue[])=>void,(error:unknown)=>void>();
let watchTimer: ReturnType<typeof setTimeout> | undefined;
let watching = false, suspended = false;
let lifecycleCleanup: (()=>void)[] = [];
function notify(tables: Tables) {
 for(const [name,callbacks] of listeners){
  const rows=tables[name]??[],encoded=JSON.stringify(rows);
  if(snapshots.get(name)===encoded)continue;
  snapshots.set(name,encoded);
  for(const callback of [...callbacks]){try{callback(clone(rows));}catch(error){try{watchErrors.get(callback)?.(error);}catch{}}}
 }
}
function scheduleWatch(delay=2000) {
 if(watchTimer!==undefined||!watching||suspended)return;
 watchTimer=setTimeout(()=>{
  watchTimer=undefined;
  void serial(async()=>{
   if(!watching||suspended)return;
   try{const tables=await load();if(watching&&!suspended)notify(tables);}catch(error){if(watching&&!suspended)for(const handler of watchErrors.values()){try{handler(error);}catch{}}}
  }).finally(()=>scheduleWatch());
 },delay);
}
function stopWatch() {
 watching=false;if(watchTimer!==undefined)clearTimeout(watchTimer);watchTimer=undefined;
 lifecycleCleanup.forEach(cleanup=>cleanup());lifecycleCleanup=[];
}
let queue: Promise<unknown> = Promise.resolve();
function serial<T>(work: () => Promise<T>): Promise<T> {
 const next=queue.then(work,work);queue=next.then(()=>undefined,()=>undefined);return next;
}
export interface Transaction {
 createTable(name: string): void;
 insert(name: string, row: RecordValue): void;
 update(name: string, id: string, changes: Record<string, unknown>): void;
 delete(name: string, id: string): void;
 get(name: string, id: string): RecordValue | null;
 query(name: string): RecordValue[];
}
function transactionView(tables: Tables): Transaction {
 const rows=(name:string)=>{valid(name);if(!Object.hasOwn(tables,name))throw new ValidationError('Table not found');return tables[name];};
 return {
  createTable(name){valid(name);if(!Object.hasOwn(tables,name))tables[name]=[];},
  insert(name,row){if(typeof row.id!=='string'||!row.id||row.id.length>200)throw new ValidationError('Invalid record ID');const table=rows(name);if(table.some(item=>item.id===row.id))throw new ValidationError('Duplicate record ID');table.push(clone(row));},
  update(name,id,changes){const table=rows(name),index=table.findIndex(row=>row.id===id);if(index<0)throw new ValidationError('Record not found');if(Object.hasOwn(changes,'id')&&changes.id!==id)throw new ValidationError('Immutable record ID');table[index]=clone({...table[index],...changes,id});},
  delete(name,id){const table=rows(name),index=table.findIndex(row=>row.id===id);if(index>=0)table.splice(index,1);},
  get(name,id){return clone(rows(name).find(row=>row.id===id)??null);},
  query(name){return clone(rows(name));}
 };
}
function validateTables(value: unknown): Tables {
 if(value===null)return {};
 if(!value||typeof value!=='object'||Array.isArray(value))throw new StorageError('database_invalid');
 for(const [name,rows] of Object.entries(value)){
  try{valid(name);}catch{throw new StorageError('database_invalid');}
  if(!Array.isArray(rows))throw new StorageError('database_invalid');
  const ids=new Set<string>();
  for(const row of rows){
   if(!row||typeof row!=='object'||Array.isArray(row)||typeof row.id!=='string'||!row.id||row.id.length>200||ids.has(row.id))throw new StorageError('database_invalid');
   ids.add(row.id);
  }
 }
 return value as Tables;
}
async function load(): Promise<Tables> { return validateTables(await storage.get('database.v1')); }
type Operator = '==' | '!=' | '>' | '>=' | '<' | '<=';
type Scalar = string | number | boolean | null;
export interface TableQuery {
 where(field: string, operator: Operator, value: Scalar): TableQuery;
 orderBy(field: string, direction?: 'asc' | 'desc'): TableQuery;
 limit(count: number): TableQuery;
 get(): Promise<RecordValue[]>;
}
function makeQuery(name: string, filters: [string,Operator,Scalar][] = [], order: [string,'asc'|'desc'][] = [], count?: number): TableQuery {
 valid(name);
 const fieldName=(field:string)=>{if(!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(field)||['constructor','prototype'].includes(field))throw new ValidationError('Invalid field');};
 return {
  where(field,operator,value){
   fieldName(field);
   if(!['==','!=','>','>=','<','<='].includes(operator)||(!['string','number','boolean'].includes(typeof value)&&value!==null)||(typeof value==='number'&&!Number.isFinite(value)))throw new ValidationError('Invalid condition');
   if(filters.length>=32)throw new ValidationError('Too many conditions');
   return makeQuery(name,[...filters,[field,operator,value]],order,count);
  },
  orderBy(field,direction='asc'){fieldName(field);if(!['asc','desc'].includes(direction)||order.length>=8)throw new ValidationError('Invalid ordering');return makeQuery(name,filters,[...order,[field,direction]],count);},
  limit(value){if(!Number.isInteger(value)||value<0||value>4096)throw new ValidationError('Invalid limit');return makeQuery(name,filters,order,value);},
  async get(){
   let rows=await database.query(name);
   for(const [field,operator,value] of filters)rows=rows.filter(row=>{
    const actual=Object.hasOwn(row,field)?row[field]:undefined;
    if(operator==='==')return actual===value;
    if(operator==='!=')return actual!==value;
    if(typeof actual!==typeof value||!['string','number'].includes(typeof actual))return false;
    const left=actual as string|number,right=value as string|number;
    switch(operator){case '>':return left>right;case '>=':return left>=right;case '<':return left<right;case '<=':return left<=right;default:return false;}
   });
   rows.sort((a,b)=>{
    for(const [field,direction] of order){
     const left=Object.hasOwn(a,field)?a[field]:null,right=Object.hasOwn(b,field)?b[field]:null;
     if(left===right)continue;
     // Missing, null and non-scalar values always sort last.
     const sortable=(value:unknown)=>typeof value==='string'||typeof value==='number'||typeof value==='boolean';
     if(!sortable(left))return sortable(right)?1:0;if(!sortable(right))return -1;
     const result=typeof left===typeof right?((left as string|number)<(right as string|number)?-1:1):(typeof left<typeof right?-1:1);
     return direction==='asc'?result:-result;
    }
    return 0;
   });
   return count===undefined?rows:rows.slice(0,count);
  }
 };
}
export const database = {
 table(name:string):TableQuery{return makeQuery(name);},
 transaction<T>(work: (transaction: Transaction) => T): Promise<T> {
  return serial(async()=>{
   const original=await storage.get<Tables>('database.v1');
   const tables=clone(validateTables(original));const tx=transactionView(tables);const result=work(tx);
   if(result && typeof (result as {then?:unknown}).then==='function')throw new ValidationError('Transaction callback must be synchronous');
   if(!await storage.compareAndSet('database.v1',original,tables))throw new StorageError('database_conflict');
   notify(tables);
   return result;
  });
 },
 createTable(name:string){return this.transaction(tx=>tx.createTable(name));},
 insert(name:string,row:RecordValue){return this.transaction(tx=>tx.insert(name,row));},
 update(name:string,id:string,changes:Record<string,unknown>){return this.transaction(tx=>tx.update(name,id,changes));},
 delete(name:string,id:string){return this.transaction(tx=>tx.delete(name,id));},
 get(name:string,id:string){return serial(async()=>transactionView(await load()).get(name,id));},
 query(name:string){return serial(async()=>transactionView(await load()).query(name));},
 watch(name:string,callback:(rows:RecordValue[])=>void,onError?:(error:unknown)=>void){
  valid(name);if(!listeners.has(name))listeners.set(name,new Set());listeners.get(name)!.add(callback);
  if(onError)watchErrors.set(callback,onError);
  if(!watching){
   watching=true;suspended=false;
   lifecycleCleanup=[app.onSuspend(()=>{suspended=true;if(watchTimer!==undefined)clearTimeout(watchTimer);watchTimer=undefined;}),app.onResume(()=>{suspended=false;scheduleWatch(10);}),app.onDisappear(stopWatch)];
  }
  // The first snapshot is delivered asynchronously, even for an empty table.
  snapshots.delete(name);scheduleWatch(10);
  return ()=>{
   const callbacks=listeners.get(name);callbacks?.delete(callback);watchErrors.delete(callback);
   if(!callbacks?.size){listeners.delete(name);snapshots.delete(name);}
   if(!listeners.size)stopWatch();
  };
 }
};
