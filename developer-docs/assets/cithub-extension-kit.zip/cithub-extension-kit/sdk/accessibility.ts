import { UnsupportedError, ValidationError } from './core';
import type { Node } from './index';
export type AccessibilityRole = 'text'|'heading'|'button'|'switch'|'textField'|'link';
export interface AccessibilityAttributes { label?:string;hint?:string;role?:AccessibilityRole }
const nodeRoles:Record<string,readonly AccessibilityRole[]> = {
  text:['text','heading'],heading:['heading','text'],button:['button'],toggle:['switch'],field:['textField'],'secure-field':['textField'],link:['link']
};
function decorate(node:Node,key:keyof AccessibilityAttributes,value:string):Node {
  if(!nodeRoles[node.type])throw new UnsupportedError('accessibility_component_unsupported');
  if(key==='role') {
    if(!nodeRoles[node.type].includes(value as AccessibilityRole))throw new ValidationError('accessibility_role_invalid');
  } else if(typeof value!=='string'||!value.trim()||value.length>1000)throw new ValidationError('accessibility_text_invalid');
  return {...node,accessibility:{...node.accessibility,[key]:value}};
}
declare const __citCall:(request:string)=>Promise<string>;
export interface AccessibilityStatus { reduceMotion:boolean;highContrast:boolean|null;screenReader:boolean }
async function status():Promise<AccessibilityStatus> {
  const reply=JSON.parse(await __citCall(JSON.stringify({operation:'accessibility.status',args:{}})));
  if(reply.error)throw new UnsupportedError(reply.error);
  return reply.result;
}
export const accessibility = {
  label:(node:Node,value:string)=>decorate(node,'label',value),
  hint:(node:Node,value:string)=>decorate(node,'hint',value),
  role:(node:Node,value:AccessibilityRole)=>decorate(node,'role',value),
  status,
  isReduceMotionEnabled:async()=> (await status()).reduceMotion,
  async isHighContrastEnabled():Promise<boolean> {
    const result=(await status()).highContrast;
    if(result===null)throw new UnsupportedError('high_contrast_unavailable');
    return result;
  }
};
