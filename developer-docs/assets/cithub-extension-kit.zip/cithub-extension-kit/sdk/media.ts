import { call, files, share, type PickedFileInfo } from './host';
import { ValidationError } from './core';
export interface ImageInfo { name:string;size:number;mimeType:string;width:number;height:number }
export interface VideoInfo extends ImageInfo { durationSeconds:number }
export interface PDFInfo { name:string;size:number;mimeType:string;pageCount:number }
export interface PDFPageInput { title?:string; text:string }
export interface GeneratedThumbnail { name:string;size:number;mimeType:'image/jpeg';width:number;height:number }
function outputName(value:string):string {if(typeof value!=='string'||!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$/.test(value)||value.includes('..'))throw new ValidationError('file_name_invalid');return value;}
function dimension(value:number):number {if(!Number.isInteger(value)||value<64||value>1024)throw new ValidationError('image_dimension_invalid');return value;}
function key(value:string):string {
  if(typeof value!=='string'||!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(value))throw new ValidationError('file_key_invalid');return value;
}
export const photos = {
  save:(source:string):Promise<boolean>=>call('photos.save',{key:key(source)}),
  pick:():Promise<PickedFileInfo|null>=>files.pickImage(),
  pickMultiple:():Promise<PickedFileInfo[]|null>=>files.pickMultiple('image'),
  info:(source:string):Promise<ImageInfo>=>call('media.info',{key:key(source),kind:'image'})
};
export const video = {
  play:(source?:string):Promise<void>=>call('media.playback',{kind:'video',action:'play',...(source===undefined?{}:{key:key(source)})}),
  pause:():Promise<void>=>call('media.playback',{kind:'video',action:'pause'}),
  info:(source:string):Promise<VideoInfo>=>call('media.info',{key:key(source),kind:'video'}),
  thumbnail(source:string,name:string,seconds=0,maxDimension=512):Promise<GeneratedThumbnail>{
    if(!Number.isFinite(seconds)||seconds<0||seconds>86400)throw new ValidationError('video_time_invalid');
    return call('media.generate',{action:'video.thumbnail',key:key(source),name:outputName(name),seconds,maxDimension:dimension(maxDimension)});
  }
};
export const audio = {
  record(maxSeconds=60):Promise<PickedFileInfo|null> {
    if(!Number.isInteger(maxSeconds)||maxSeconds<1||maxSeconds>300)throw new ValidationError('recording_duration_invalid');
    return call('audio.record',{key:`recording_${Date.now()}_${++recordingSequence}`,maxSeconds});
  },
  stopRecording:():Promise<boolean>=>call('audio.stopRecording'),
  play:(source?:string):Promise<void>=>call('media.playback',{kind:'audio',action:'play',...(source===undefined?{}:{key:key(source)})}),
  pause:():Promise<void>=>call('media.playback',{kind:'audio',action:'pause'}),
  stop:():Promise<void>=>call('media.playback',{kind:'audio',action:'stop'}),
  duration:():Promise<number|null>=>call('media.playback',{kind:'audio',action:'duration'}),
  position:():Promise<number|null>=>call('media.playback',{kind:'audio',action:'position'})
};
let recordingSequence=0;
export const pdf = {
  open:(source:string):Promise<void>=>call('files.selection.preview',{key:key(source),kind:'pdf'}),
  async pageCount(source:string):Promise<number>{return (await call<PDFInfo>('media.info',{key:key(source),kind:'pdf'})).pageCount;},
  async share(source:string):Promise<void>{return share.file(key(source));},
  create(name:string,pages:PDFPageInput[]):Promise<PDFInfo>{
    if(!Array.isArray(pages)||!pages.length||pages.length>20||pages.some(page=>!page||Object.keys(page).some(key=>!['title','text'].includes(key))||typeof page.text!=='string'||page.text.length>4000||page.title!==undefined&&(typeof page.title!=='string'||page.title.length>120))||pages.reduce((sum,page)=>sum+page.text.length,0)>16000)throw new ValidationError('pdf_pages_invalid');
    return call('media.generate',{action:'pdf.create',name:outputName(name),pages});
  },
  thumbnail(source:string,name:string,page=0,maxDimension=512):Promise<GeneratedThumbnail>{
    if(!Number.isInteger(page)||page<0||page>9999)throw new ValidationError('pdf_page_invalid');
    return call('media.generate',{action:'pdf.thumbnail',key:key(source),name:outputName(name),page,maxDimension:dimension(maxDimension)});
  },
  export(name:string,suggestedName=name):Promise<boolean>{
    if(typeof suggestedName!=='string'||!suggestedName.trim()||suggestedName.length>120||/[\u0000-\u001f/\\:*?"<>|]/.test(suggestedName))throw new ValidationError('file_name_invalid');
    return call('media.exportPDF',{name:outputName(name),suggestedName});
  }
};
