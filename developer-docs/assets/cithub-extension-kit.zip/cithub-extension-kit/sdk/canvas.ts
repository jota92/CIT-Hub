import type { Node } from './index';
import { ValidationError, parseHTTPSURL } from './core';

export type DrawingColor = 'primary' | 'secondary' | 'accent' | 'surface' | `#${string}`;
export interface DrawingStyle { fill?: DrawingColor; stroke?: DrawingColor; lineWidth?: number; opacity?: number }
export type PathSegment = { op: 'move' | 'line'; x: number; y: number } |
  { op: 'quad'; x: number; y: number; cx: number; cy: number } |
  { op: 'cubic'; x: number; y: number; cx: number; cy: number; cx2: number; cy2: number } | { op: 'close' };
interface Command extends DrawingStyle { op: string; [key: string]: unknown }
const color = (value: unknown): boolean => typeof value === 'string' && (/^#[0-9a-f]{6}$/i.test(value) || ['primary','secondary','accent','surface'].includes(value));
const number = (value: number): number => { if (!Number.isFinite(value) || Math.abs(value) > 10000) throw new ValidationError('drawing_coordinate_invalid'); return value; };
function style(value: DrawingStyle): DrawingStyle {
  if (!value || Object.keys(value).some(key => !['fill','stroke','lineWidth','opacity'].includes(key)) ||
      value.fill !== undefined && !color(value.fill) || value.stroke !== undefined && !color(value.stroke) ||
      value.lineWidth !== undefined && (!Number.isFinite(value.lineWidth) || value.lineWidth < 0.1 || value.lineWidth > 32) ||
      value.opacity !== undefined && (!Number.isFinite(value.opacity) || value.opacity < 0 || value.opacity > 1)) throw new ValidationError('drawing_style_invalid');
  return { ...value };
}
export class ExtensionCanvas {
  private readonly commands: Command[] = [];
  constructor(readonly width: number, readonly height: number, readonly label: string) {
    if (![width,height].every(value => Number.isFinite(value) && value >= 32 && value <= 1024) || !label?.trim() || label.length > 120) throw new ValidationError('drawing_size_invalid');
  }
  private add(value: Command): this {
    if (this.commands.length >= 128 || JSON.stringify([...this.commands,value]).length > 24000) throw new ValidationError('drawing_complexity');
    this.commands.push(value); return this;
  }
  line(x1: number,y1: number,x2: number,y2: number,appearance: DrawingStyle = {}): this {
    return this.add({op:'line',x1:number(x1),y1:number(y1),x2:number(x2),y2:number(y2),stroke:'accent',...style(appearance)});
  }
  rect(x: number,y: number,width: number,height: number,appearance: DrawingStyle = {}): this {
    if (width < 0 || height < 0) throw new ValidationError('drawing_size_invalid');
    return this.add({op:'rect',x:number(x),y:number(y),width:number(width),height:number(height),fill:'accent',...style(appearance)});
  }
  circle(x: number,y: number,radius: number,appearance: DrawingStyle = {}): this {
    if (radius <= 0) throw new ValidationError('drawing_size_invalid');
    return this.add({op:'circle',x:number(x),y:number(y),radius:number(radius),fill:'accent',...style(appearance)});
  }
  text(text: string,x: number,y: number,options: {color?: DrawingColor;size?: number;align?: 'leading'|'center'|'trailing'} = {}): this {
    const size=options.size??14,align=options.align??'leading',fill=options.color??'primary';
    if (typeof text!=='string'||text.length>1000||!color(fill)||!Number.isFinite(size)||size<8||size>72||!['leading','center','trailing'].includes(align)) throw new ValidationError('drawing_text_invalid');
    return this.add({op:'text',text,x:number(x),y:number(y),size,align,fill});
  }
  image(url: string,x: number,y: number,width: number,height: number): this {
    const parsed=parseHTTPSURL(url,2048);
    if (!parsed||width<=0||height<=0) throw new ValidationError('drawing_image_invalid');
    return this.add({op:'image',url:parsed.href,x:number(x),y:number(y),width:number(width),height:number(height)});
  }
  path(segments: PathSegment[],appearance: DrawingStyle = {}): this {
    if (!Array.isArray(segments)||!segments.length||segments.length>128||segments[0].op!=='move') throw new ValidationError('drawing_path_invalid');
    const safe=segments.map(segment=>{
      const keys: Record<string,string[]>={move:['op','x','y'],line:['op','x','y'],quad:['op','x','y','cx','cy'],cubic:['op','x','y','cx','cy','cx2','cy2'],close:['op']};
      const required=keys[segment.op];
      if (!required||Object.keys(segment).length!==required.length||required.some(key=>!Object.hasOwn(segment,key))) throw new ValidationError('drawing_path_invalid');
      for(const [key,value] of Object.entries(segment))if(key!=='op')number(value as number);
      return {...segment};
    });
    return this.add({op:'path',segments:safe,stroke:'accent',...style(appearance)});
  }
  node(): Node { return {type:'canvas',label:this.label,arguments:{width:String(this.width),height:String(this.height),commands:JSON.stringify(this.commands)}}; }
}
export const canvas = {
  create: (width = 320,height = 200,label = '描画'): ExtensionCanvas => new ExtensionCanvas(width,height,label)
};
