import { access, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

export async function fixEsmDirectoryImports(directory) {
  for (const item of await readdir(directory, { withFileTypes: true })) {
    const file = path.join(directory, item.name);
    if (item.isDirectory()) {
      await fixEsmDirectoryImports(file);
      continue;
    }
    if (!file.endsWith('.js')) continue;
    const source = await readFile(file, 'utf8');
    const replacements = await Promise.all([...source.matchAll(/(from\s+['"])(\.\.?\/[^'"]+)(['"])/g)].map(async match => {
      const [, before, specifier, after] = match;
      if (specifier.endsWith('.js')) return [match[0], match[0]];
      const target = path.resolve(path.dirname(file), specifier);
      let resolved = `${specifier}.js`;
      try { await access(`${target}.js`); }
      catch {
        try {
          await access(path.join(target, 'index.js'));
          resolved = `${specifier.replace(/\/$/, '')}/index.js`;
        } catch {}
      }
      return [match[0], `${before}${resolved}${after}`];
    }));
    let output = source;
    for (const [original, replacement] of replacements) output = output.replace(original, replacement);
    await writeFile(file, output);
  }
}
