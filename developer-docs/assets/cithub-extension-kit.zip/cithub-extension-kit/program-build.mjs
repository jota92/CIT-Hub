// Read literal program metadata without executing the extension's initialization code.
export function readProgramMetadata(ts, source, filename) {
  const file=ts.createSourceFile(filename,source,ts.ScriptTarget.Latest,true);
  const exported=file.statements.find(statement=>ts.isExportAssignment(statement)&&!statement.isExportEquals);
  if(!exported)return null;
  const names=new Set(['defineProgram']);
  for(const statement of file.statements){
    if(!ts.isImportDeclaration(statement))continue;
    const bindings=statement.importClause?.namedBindings;
    if(bindings&&ts.isNamedImports(bindings))for(const entry of bindings.elements){
      if((entry.propertyName?.text??entry.name.text)==='defineProgram')names.add(entry.name.text);
    }
  }
  let expression=exported.expression;
  const visited=new Set();
  while(ts.isIdentifier(expression)){
    if(visited.has(expression.text))throw Error('Circular program export');
    visited.add(expression.text);
    const name=expression.text;
    const declaration=file.statements.filter(ts.isVariableStatement).flatMap(statement=>statement.declarationList.declarations).find(item=>ts.isIdentifier(item.name)&&item.name.text===name);
    if(!declaration?.initializer)return null;
    expression=declaration.initializer;
  }
  if(!ts.isCallExpression(expression)||!ts.isIdentifier(expression.expression)||!names.has(expression.expression.text))return null;
  const argument=expression.arguments[0];
  if(!argument||!ts.isObjectLiteralExpression(argument))throw Error('defineProgram metadata must be an object literal');
  const required=new Set(['name','version','description','permissions']);const metadata={};
  for(const property of argument.properties){
    if(ts.isSpreadAssignment(property))throw Error('Do not spread defineProgram metadata; use literal name/version/description/permissions');
    if(!ts.isPropertyAssignment(property))continue;
    const name=property.name.getText(file).replace(/^['"]|['"]$/g,'');
    if(!required.has(name)&&name!=='network')continue;
    const value=property.initializer;
    if(name==='permissions'||name==='network'){
      if(!ts.isArrayLiteralExpression(value)||value.elements.some(item=>!ts.isStringLiteral(item)))throw Error(name+' must be a literal string array');
      metadata[name]=value.elements.map(item=>item.text);
      if(name==='network')continue;
    }else{
      if(!ts.isStringLiteral(value)&&!ts.isNoSubstitutionTemplateLiteral(value))throw Error(name+' must be a literal string');
      metadata[name]=value.text;
    }
    required.delete(name);
  }
  if(required.size)throw Error('Missing literal program metadata: '+[...required].join(', '));
  return {schemaVersion:1,...metadata,content:[{type:'text',text:'拡張機能を起動しています。'}]};
}

export function readServerFunctionNames(ts, source, filename) {
  const file=ts.createSourceFile(filename,source,ts.ScriptTarget.Latest,true);
  const declaration=file.statements
    .filter(ts.isVariableStatement)
    .filter(statement=>statement.modifiers?.some(modifier=>modifier.kind===ts.SyntaxKind.ExportKeyword))
    .flatMap(statement=>statement.declarationList.declarations)
    .find(item=>ts.isIdentifier(item.name)&&item.name.text==='serverFunctions');
  if(!declaration)return null;
  if(!declaration.initializer||!ts.isObjectLiteralExpression(declaration.initializer))throw Error('serverFunctions must be an object literal');
  const names=[];
  for(const member of declaration.initializer.properties){
    if(ts.isSpreadAssignment(member))throw Error('serverFunctions cannot contain spread properties');
    if(!ts.isMethodDeclaration(member)&&!ts.isPropertyAssignment(member))throw Error('serverFunctions entries must be named functions');
    const key=member.name;
    const name=key&&(ts.isIdentifier(key)||ts.isStringLiteral(key)||ts.isNumericLiteral(key))?key.text:null;
    if(!name||!(/^[A-Za-z][A-Za-z0-9_.-]{0,63}$/).test(name))throw Error('serverFunctions contains an invalid function name');
    if(ts.isPropertyAssignment(member)&&!ts.isArrowFunction(member.initializer)&&!ts.isFunctionExpression(member.initializer))throw Error(`serverFunctions.${name} must be a function`);
    names.push(name);
  }
  if(names.length<1||names.length>10)throw Error('serverFunctions must contain 1 to 10 named functions');
  if(new Set(names).size!==names.length)throw Error('serverFunctions names must be unique');
  return { names, initializer: declaration.initializer.getText(file) };
}
