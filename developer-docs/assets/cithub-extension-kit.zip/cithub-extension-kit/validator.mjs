export function validateDrawing(argumentsValue, permissions) {
    const failure = () => { throw Error('drawing_invalid'); };
    if (!argumentsValue || typeof argumentsValue !== 'object' || Array.isArray(argumentsValue))
        failure();
    const args = argumentsValue;
    if (Object.keys(args).length !== 3 || !['width', 'height', 'commands'].every(key => typeof args[key] === 'string') || ![Number(args.width), Number(args.height)].every(value => Number.isFinite(value) && value >= 32 && value <= 1024) || String(args.commands).length > 24000)
        failure();
    let commands;
    try {
        commands = JSON.parse(String(args.commands));
    }
    catch {
        failure();
    }
    if (!Array.isArray(commands) || commands.length > 128)
        failure();
    const numeric = (value) => typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= 10000;
    const fields = { line: ['x1', 'y1', 'x2', 'y2'], rect: ['x', 'y', 'width', 'height'], circle: ['x', 'y', 'radius'], text: ['x', 'y', 'size'], image: ['x', 'y', 'width', 'height'], path: [] };
    for (const value of commands) {
        if (!value || typeof value !== 'object' || Array.isArray(value))
            failure();
        const cmd = value, op = String(cmd.op), required = fields[op];
        if (!required)
            failure();
        const specific = op === 'text' ? ['text', 'align'] : op === 'image' ? ['url'] : op === 'path' ? ['segments'] : [];
        if (Object.keys(cmd).some(key => !['op', 'fill', 'stroke', 'lineWidth', 'opacity', ...required, ...specific].includes(key)) || required.some(key => !numeric(cmd[key])))
            failure();
        for (const key of ['fill', 'stroke'])
            if (cmd[key] !== undefined && (typeof cmd[key] !== 'string' || !['primary', 'secondary', 'accent', 'surface'].includes(String(cmd[key])) && !/^#[0-9a-f]{6}$/i.test(String(cmd[key]))))
                failure();
        if (cmd.lineWidth !== undefined && (!numeric(cmd.lineWidth) || Number(cmd.lineWidth) < 0.1 || Number(cmd.lineWidth) > 32) || cmd.opacity !== undefined && (!numeric(cmd.opacity) || Number(cmd.opacity) < 0 || Number(cmd.opacity) > 1))
            failure();
        if (op === 'rect' && (Number(cmd.width) < 0 || Number(cmd.height) < 0) || op === 'circle' && Number(cmd.radius) <= 0)
            failure();
        if (op === 'text' && (typeof cmd.text !== 'string' || cmd.text.length > 1000 || Number(cmd.size) < 8 || Number(cmd.size) > 72 || !['leading', 'center', 'trailing'].includes(String(cmd.align))))
            failure();
        if (op === 'image') {
            if (!permissions.includes('media.remote'))
                throw Error('permission_required');
            let url;
            try {
                url = new URL(String(cmd.url));
            }
            catch {
                failure();
            }
            if (typeof cmd.url !== 'string' || cmd.url.length > 2048 || url.protocol !== 'https:' || !url.hostname || url.username || url.password || url.port && url.port !== '443' || Number(cmd.width) <= 0 || Number(cmd.height) <= 0)
                failure();
        }
        if (op === 'path') {
            if (!Array.isArray(cmd.segments) || cmd.segments.length < 1 || cmd.segments.length > 128 || cmd.segments[0]?.op !== 'move')
                failure();
            for (const segment of cmd.segments) {
                if (!segment || typeof segment !== 'object' || Array.isArray(segment))
                    failure();
                const s = segment, keys = { move: ['x', 'y'], line: ['x', 'y'], quad: ['x', 'y', 'cx', 'cy'], cubic: ['x', 'y', 'cx', 'cy', 'cx2', 'cy2'], close: [] }, coordinates = keys[String(s.op)];
                if (!coordinates || Object.keys(s).length !== coordinates.length + 1 || coordinates.some(key => !numeric(s[key])))
                    failure();
            }
        }
    }
}
export const campusQueries = {
    'profile.displayName': 'profile.read', 'settings.display': 'settings.read', 'services.enabled': 'settings.read', 'courseNotes.data': 'courseNotes.read', 'courses.data': 'timetable.read', 'timetable.periods': 'timetable.read', 'assignments.data': 'assignments.read', 'todos.data': 'todos.read', 'academic.calendar': 'calendar.read', 'bus.schedule': 'bus.read', 'cafeteria.locations': 'cafeteria.read', 'cafeteria.menu': 'cafeteria.read', 'cafeteria.cameraStatus': 'cafeteria.read', 'cafeteria.hours': 'cafeteria.read',
    'courses.current': 'timetable.read', 'courses.next': 'timetable.read',
    'courses.today': 'timetable.read', 'courses.week': 'timetable.read',
    'enrollment.summary': 'timetable.read', 'assignments.pending': 'assignments.read',
    'assignments.summary': 'assignments.read', 'assignments.overdue': 'assignments.read',
    'assignments.dueSoon': 'assignments.read', 'todos.summary': 'todos.read'
};
const str = (v) => typeof v === 'string' ? v : '';
const now = () => Math.floor(Date.now() / 1000);
const random = () => crypto.randomUUID().replaceAll('-', '');
async function hash(value) { return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))), b => b.toString(16).padStart(2, '0')).join(''); }
export async function extensionPrincipal(userID, key) {
    return hash(`cithub-extension-v1:${userID}:${key}`);
}
function compareVersions(a, b) {
    const av = a.split('.').map(BigInt), bv = b.split('.').map(BigInt);
    for (let i = 0; i < 3; i++) {
        if (av[i] > bv[i])
            return 1;
        if (av[i] < bv[i])
            return -1;
    }
    return 0;
}
export function validateExtension(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw Error('manifest_invalid');
    const m = value;
    if (m.minimumHostAPI !== undefined && (!Number.isInteger(m.minimumHostAPI) || Number(m.minimumHostAPI) < 1 || Number(m.minimumHostAPI) > 80))
        throw Error('manifest_host_api_invalid');
    if (m.runtime !== undefined) {
        const runtime = m.runtime;
        if (!runtime || typeof runtime !== 'object' || Array.isArray(runtime) || runtime.engine !== 'quickjs-v1' || typeof runtime.code !== 'string' || !runtime.code.trim() || runtime.code.length > 150000 || Object.keys(runtime).some(key => !['engine', 'code'].includes(key)))
            throw Error('manifest_runtime_invalid');
    }
    if (m.serverFunctions !== undefined) {
        const functions = m.serverFunctions;
        if (!functions || typeof functions !== 'object' || Array.isArray(functions) || Object.keys(functions).some(key => !['engine', 'code'].includes(key)) || functions.engine !== 'quickjs-v1' || typeof functions.code !== 'string' || !functions.code.trim() || new TextEncoder().encode(functions.code).byteLength > 150000 || !Array.isArray(m.permissions) || !m.permissions.includes('server.functions') || Number(m.minimumHostAPI || 1) < 69)
            throw Error('manifest_server_functions_invalid');
    }
    if (m.schemaVersion !== 1 || !str(m.name).trim() || str(m.name).length > 60 || !/^\d+\.\d+\.\d+$/.test(str(m.version)) || str(m.version).length > 40 || typeof m.description !== 'string' || m.description.length > 2000)
        throw Error('manifest_invalid');
    if (!Array.isArray(m.permissions) || m.permissions.some(p => !['profile.read', 'host.navigate', 'extensions.read', 'microphone.use', 'cloud.storage', 'analytics.collect', 'timetable.read', 'assignments.read', 'todos.read', 'todos.write', 'calendar.read', 'bus.read', 'cafeteria.read', 'files.user', 'files.selection.read', 'files.storage', 'browser.open', 'settings.read', 'settings.open', 'courseNotes.read', 'courseNotes.write', 'media.remote', 'board.camera', 'photos.user', 'camera.use', 'location.use', 'network.status', 'network.fetch', 'clipboard.read', 'clipboard.write', 'notifications.schedule', 'sensors.motion', 'cloud.shared', 'server.functions'].includes(String(p))) || new Set(m.permissions).size !== m.permissions.length)
        throw Error('unsupported_permission');
    const networkHosts = m.network;
    if (networkHosts !== undefined && (!Array.isArray(networkHosts) || networkHosts.length < 1 || networkHosts.length > 20 || new Set(networkHosts).size !== networkHosts.length || networkHosts.some(host => typeof host !== 'string' || host !== host.toLowerCase() || host.length > 253 || !host.includes('.') || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(':') || host.split('.').some(label => !/^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)$/.test(label)))))
        throw Error('network_hosts_invalid');
    if (m.permissions.includes('network.fetch') !== Array.isArray(networkHosts))
        throw Error('network_hosts_invalid');
    if (m.permissions.includes('microphone.use') && Number(m.minimumHostAPI || 1) < 61)
        throw Error('microphone_requires_host_api_61');
    if (m.permissions.includes('cloud.shared') && Number(m.minimumHostAPI || 1) < 60)
        throw Error('collaboration_requires_host_api_60');
    if (m.permissions.includes('sensors.motion') && Number(m.minimumHostAPI || 1) < 60)
        throw Error('sensors_requires_host_api_60');
    if (m.permissions.some(p => ['host.navigate', 'extensions.read'].includes(String(p))) && Number(m.minimumHostAPI || 1) < 62)
        throw Error('integration_requires_host_api_62');
    const runtimeCode = m.runtime?.code;
    const usesRealtime = !!runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_realtime70__*/') || /\brealtime\s*\.\s*(?:publish|subscribe)\s*\(/.test(runtimeCode));
    if (usesRealtime && (!m.permissions.includes('cloud.shared') || Number(m.minimumHostAPI || 1) < 70))
        throw Error('realtime_requires_cloud_shared_and_host_api_70');
    if (runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_serverCron71__*/') || /\bserver\s*\.\s*cron\s*\.(?:register|unregister)\s*\(/.test(runtimeCode)) && (!m.permissions.includes('server.functions') || Number(m.minimumHostAPI || 1) < 71))
        throw Error('cron_requires_server_functions_and_host_api_71');
    if (runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_serverCron72__*/') || /\bserver\s*\.\s*cron\s*\.\s*status\s*\(/.test(runtimeCode)) && (!m.permissions.includes('server.functions') || Number(m.minimumHostAPI || 1) < 72))
        throw Error('cron_status_requires_server_functions_and_host_api_72');
    if (runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_auth73__*/') || /\bauth\s*\.\s*(?:oauth2|openIDConnect|refresh|logout|tokenStatus)\s*\(/.test(runtimeCode)) && Number(m.minimumHostAPI || 1) < 73)
        throw Error('auth_requires_host_api_73');
    if (runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_serverFiles80__*/') || /\bserver\s*\.\s*files\s*\./.test(runtimeCode)) && (!m.permissions.includes('cloud.storage') || Number(m.minimumHostAPI || 1) < 80))
        throw Error('server_files_requires_cloud_storage_and_host_api_80');
    if (runtimeCode && /\b(?:background|backgroundTasks)\s*\.\s*(?:register|unregister)\s*\(/.test(runtimeCode) && (!m.permissions.includes('server.functions') || Number(m.minimumHostAPI || 1) < 71))
        throw Error('background_registration_requires_server_functions_and_host_api_71');
    if (runtimeCode && /\bsearch\s*\.\s*(?:registerItems|removeItems)\s*\(/.test(runtimeCode) && (!m.permissions.includes('extensions.read') || Number(m.minimumHostAPI || 1) < 66))
        throw Error('search_index_requires_extensions_permission_and_host_api_66');
    if (runtimeCode && /\bhost\s*\.\s*(?:registerShortcut|registerAction)\s*\(/.test(runtimeCode) && (!m.permissions.includes('host.navigate') || Number(m.minimumHostAPI || 1) < 67))
        throw Error('host_actions_require_navigation_permission_and_host_api_67');
    if (runtimeCode && /\bwidget\s*\.\s*(?:define|reload)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 68)
        throw Error('widgets_require_host_api_68');
    if (runtimeCode && /\bshortcuts\s*\.\s*register\s*\(/.test(runtimeCode) && (!m.permissions.includes('host.navigate') || Number(m.minimumHostAPI || 1) < 69))
        throw Error('shortcuts_require_navigation_permission_and_host_api_69');
    if (runtimeCode && /\bpush\s*\.\s*sendToCurrentUser\s*\(/.test(runtimeCode) && (!m.permissions.includes('notifications.schedule') || Number(m.minimumHostAPI || 1) < 78))
        throw Error('self_push_requires_notifications_and_host_api_78');
    if (runtimeCode && /\bmap\s*\.\s*(?:view|marker|polyline|circle|fitBounds)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 67)
        throw Error('map_requires_host_api_67');
    if (runtimeCode && (/\bdrag\s*\.\s*source\s*\(|\bdrop\s*\.\s*target\s*\(/.test(runtimeCode)) && Number(m.minimumHostAPI || 1) < 66)
        throw Error('drag_drop_requires_host_api_66');
    if (runtimeCode && /\bcit\s*\.\s*campus\s*\.\s*(?:facilities|buildings|rooms|room|search|roomAvailability)\s*\(/.test(runtimeCode) && (!m.permissions.includes('timetable.read') || Number(m.minimumHostAPI || 1) < 65))
        throw Error('campus_room_api_requires_timetable_permission_and_host_api_65');
    if (runtimeCode && /\bcit\s*\.\s*cafeteria\s*\.\s*hours\s*\(/.test(runtimeCode) && (!m.permissions.includes('cafeteria.read') || Number(m.minimumHostAPI || 1) < 65))
        throw Error('cafeteria_hours_requires_cafeteria_permission_and_host_api_65');
    if (runtimeCode && /\b(?:scanner\s*\.\s*document|image\s*\.\s*scanDocument)\s*\(/.test(runtimeCode) && (!m.permissions.includes('camera.use') || !m.permissions.includes('files.storage') || Number(m.minimumHostAPI || 1) < 64))
        throw Error('document_scanner_requires_camera_files_and_host_api_64');
    if (runtimeCode && /__CIT_FEATURE_integration62__/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 62)
        throw Error('integration_requires_host_api_62');
    if (runtimeCode?.includes('/*__CIT_FEATURE_media61__*/') && Number(m.minimumHostAPI || 1) < 61)
        throw Error('media_requires_host_api_61');
    if (runtimeCode?.includes('/*__CIT_FEATURE_native60__*/') && Number(m.minimumHostAPI || 1) < 60)
        throw Error('native_requires_host_api_60');
    if (runtimeCode?.includes('/*__CIT_FEATURE_ui58__*/') && Number(m.minimumHostAPI || 1) < 58)
        throw Error('foundation_ui_requires_host_api_58');
    if (runtimeCode?.includes('/*__CIT_FEATURE_dataMedia59__*/') && Number(m.minimumHostAPI || 1) < 59)
        throw Error('data_media_requires_host_api_59');
    if (runtimeCode && /\bnetwork\s*\.\s*(?:uploadFile|downloadFile)\s*\(/.test(runtimeCode) && (!m.permissions.includes('network.fetch') || !m.permissions.includes('files.storage') || Number(m.minimumHostAPI || 1) < 33))
        throw Error('network_file_transfer_requirements');
    if (runtimeCode && /\binteractive\s*\.\s*multiSelect\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 34)
        throw Error('interactive_multi_select_requires_host_api_34');
    if (runtimeCode && /\binteractive\s*\.\s*dateTime\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 35)
        throw Error('interactive_date_time_requires_host_api_35');
    if (runtimeCode && /\binteractive\s*\.\s*dateRange\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 36)
        throw Error('interactive_date_range_requires_host_api_36');
    if (runtimeCode && /\binteractive\s*\.\s*(?:stepper|checkbox|radio)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 37)
        throw Error('interactive_form_controls_require_host_api_37');
    if (runtimeCode && /\bui\s*\.\s*progress\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 38)
        throw Error('progress_ui_requires_host_api_38');
    if (runtimeCode && /\bui\s*\.\s*(?:loading|emptyState|errorState)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 39)
        throw Error('status_ui_requires_host_api_39');
    if (runtimeCode && /\bui\s*\.\s*(?:card|group|container)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 40)
        throw Error('responsive_container_requires_host_api_40');
    if (runtimeCode && /\banimation\s*\.\s*(?:animate|spring|transition)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 41)
        throw Error('animation_requires_host_api_41');
    function usesChart(nodes) { return nodes.some(node => node.type === 'chart' || Array.isArray(node.children) && usesChart(node.children)); }
    if (Array.isArray(m.content) && usesChart(m.content) && Number(m.minimumHostAPI || 1) < 42)
        throw Error('chart_requires_host_api_42');
    if (runtimeCode && /\bui\s*\.\s*barChart\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 42)
        throw Error('chart_requires_host_api_42');
    function usesLayout43(nodes) { return nodes.some(node => node.type === 'safe-area' || ['minWidth', 'maxWidth', 'minHeight', 'maxHeight', 'aspectRatio'].some(key => Object.hasOwn(node.style || {}, key)) || Array.isArray(node.children) && usesLayout43(node.children)); }
    if (Array.isArray(m.content) && usesLayout43(m.content) && Number(m.minimumHostAPI || 1) < 43)
        throw Error('responsive_geometry_requires_host_api_43');
    if (runtimeCode && /\bui\s*\.\s*(?:safeArea|frame)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 43)
        throw Error('responsive_geometry_requires_host_api_43');
    if (runtimeCode && /\binteractive\s*\.\s*iconButton\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 45)
        throw Error('icon_button_requires_host_api_45');
    if (runtimeCode && /\binteractive\s*\.\s*searchField\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 46)
        throw Error('search_field_requires_host_api_46');
    if (runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_inputEvents__*/') || /\binteractive\s*\.\s*(?:textField|secureField|textArea|searchField)\s*\([^)]*\{[^}]*\bon(?:Focus|Blur|Submit)\s*:/.test(runtimeCode)) && Number(m.minimumHostAPI || 1) < 44)
        throw Error('input_events_require_host_api_44');
    if (runtimeCode && /\bui\s*\.\s*linkButton\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 47)
        throw Error('link_button_requires_host_api_47');
    // Bundled SDKs contain this operation name as an implementation string even when
    // an extension never calls WebSocket. Permission checks belong at server upload
    // and native dispatch, not this shared shape-only manifest validator.
    const usesWebSocket = runtimeCode && /\bnetwork\s*\.\s*websocket\s*\.\s*connect\s*\(/.test(runtimeCode);
    const usesBackgroundStatus = runtimeCode && /\bbackground\s*\.\s*status\s*\(/.test(runtimeCode);
    if (usesBackgroundStatus && Number(m.minimumHostAPI || 1) < 68)
        throw Error('background_status_requires_host_api_68');
    if (usesWebSocket && Number(m.minimumHostAPI || 1) < 48)
        throw Error('websocket_requires_host_api_48');
    const usesFilePicker = runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_filePicker__*/') || /\bfiles\s*\.\s*pick(?:Multiple|Image|Video|Audio|Document)?\s*\(/.test(runtimeCode));
    if (usesFilePicker && (!m.permissions.includes('files.user') || !m.permissions.includes('files.selection.read')))
        throw Error('file_picker_requires_file_permissions');
    if (usesFilePicker && Number(m.minimumHostAPI || 1) < 49)
        throw Error('file_picker_requires_host_api_49');
    if (runtimeCode && /\bfiles\s*\.\s*pickMultiple\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 50)
        throw Error('multiple_file_picker_requires_host_api_50');
    const usesFileExport = runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_fileExport__*/') || /\bfiles\s*\.\s*(?:export|saveAs)\s*\(/.test(runtimeCode));
    if (usesFileExport && !m.permissions.includes('files.storage'))
        throw Error('file_export_requires_files_storage');
    if (usesFileExport && Number(m.minimumHostAPI || 1) < 51)
        throw Error('file_export_requires_host_api_51');
    const usesShareSheet = runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_shareSheet__*/') || /\bshare\s*\.\s*(?:text|url|items)\s*\(/.test(runtimeCode));
    if (usesShareSheet && Number(m.minimumHostAPI || 1) < 52)
        throw Error('share_sheet_requires_host_api_52');
    const usesShareFile = runtimeCode && (runtimeCode.includes('/*__CIT_FEATURE_shareFile__*/') || /\bshare\s*\.\s*file\s*\(/.test(runtimeCode));
    if (usesShareFile && (!m.permissions.includes('files.user') || !m.permissions.includes('files.selection.read')))
        throw Error('share_file_requires_file_permissions');
    if (usesShareFile && Number(m.minimumHostAPI || 1) < 53)
        throw Error('share_file_requires_host_api_53');
    const usesImageTransform = runtimeCode && /\bfiles\s*\.\s*transformImage\s*\(/.test(runtimeCode);
    if (usesImageTransform && (!m.permissions.includes('files.storage') || !m.permissions.includes('files.selection.read')))
        throw Error('image_transform_requires_file_permissions');
    if (usesImageTransform && Number(m.minimumHostAPI || 1) < 54)
        throw Error('image_transform_requires_host_api_54');
    const usesTransferProgress = runtimeCode && /\bnetwork\s*\.\s*(?:uploadFile|downloadFile)\s*\([\s\S]{0,2000}\bonProgress\b/.test(runtimeCode);
    if (usesTransferProgress && Number(m.minimumHostAPI || 1) < 55)
        throw Error('transfer_progress_requires_host_api_55');
    const usesExternalBrowser = runtimeCode && /\bbrowser\s*\.\s*openExternal\s*\(/.test(runtimeCode);
    if (usesExternalBrowser && !m.permissions.includes('browser.open'))
        throw Error('browser_open_requires_permission');
    if (usesExternalBrowser && Number(m.minimumHostAPI || 1) < 56)
        throw Error('browser_open_requires_host_api_56');
    if (runtimeCode && /\banalytics\s*\.\s*event\s*\(/.test(runtimeCode) && (!m.permissions.includes('analytics.collect') || Number(m.minimumHostAPI || 1) < 57))
        throw Error('analytics_event_requires_permission_and_host_api_57');
    function usesStatusNode(nodes) { return nodes.some(node => ['loading', 'empty-state', 'error-state'].includes(str(node.type)) || Array.isArray(node.children) && usesStatusNode(node.children)); }
    if (Array.isArray(m.content) && usesStatusNode(m.content) && Number(m.minimumHostAPI || 1) < 39)
        throw Error('status_ui_requires_host_api_39');
    function usesContainerNode(nodes) { return nodes.some(node => ['card', 'group', 'container'].includes(str(node.type)) || Array.isArray(node.children) && usesContainerNode(node.children)); }
    if (Array.isArray(m.content) && usesContainerNode(m.content) && Number(m.minimumHostAPI || 1) < 40)
        throw Error('responsive_container_requires_host_api_40');
    let count = 0;
    const ids = new Set();
    const fields = new Map();
    const todoActions = [];
    const stateActions = [];
    function visit(value, depth, parent = "") {
        if (++count > 120 || depth > 8 || !value || typeof value !== 'object' || Array.isArray(value))
            throw Error('layout_invalid');
        const n = value;
        const args = n.arguments && typeof n.arguments === 'object' && !Array.isArray(n.arguments) ? n.arguments : {};
        if (['presentation', 'menu', 'context-menu', 'swipe-actions', 'toolbar', 'floating-button', 'lazy-list', 'lazy-grid'].includes(str(n.type))) {
            if (Number(m.minimumHostAPI || 1) < 58)
                throw Error('foundation_ui_requires_host_api_58');
            if (!Array.isArray(n.children))
                throw Error('children_invalid');
            if (['menu', 'context-menu', 'swipe-actions', 'floating-button'].includes(str(n.type))) {
                const offset = n.type === 'menu' ? 0 : 1;
                if (n.children.length < offset + 1 || n.children.length > offset + 8 || n.children.slice(offset).some(child => !child || typeof child !== 'object' || !['button', 'icon-button', 'link-button'].includes(str(child.type))))
                    throw Error('menu_actions_invalid');
            }
            if (n.type === 'floating-button' && n.children.length !== 2)
                throw Error('floating_button_invalid');
            if (n.type === 'presentation' && (!m.runtime || !['sheet', 'fullScreen'].includes(str(n.kind)) || !str(n.label).trim() || !n.arguments || !/^[0-9]{1,6}$/.test(str(n.arguments.event))))
                throw Error('presentation_invalid');
        }
        if (n.type === 'date' && n.arguments !== undefined && (!n.arguments || Array.isArray(n.arguments) || Object.keys(n.arguments).some(key => key !== 'mode') || !['time', 'date', 'dateTime'].includes(str(n.arguments.mode)) || Number(m.minimumHostAPI || 1) < 58))
            throw Error('date_mode_invalid');
        if (n.type === 'file' && n.arguments !== undefined && (!n.arguments || Array.isArray(n.arguments) || Object.keys(n.arguments).some(key => key !== 'kind') || !['any', 'image', 'video', 'audio', 'document'].includes(str(n.arguments.kind)) || Number(m.minimumHostAPI || 1) < 58))
            throw Error('file_picker_kind_invalid');
        if (n.onChange !== undefined && (!m.runtime || !['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'file', 'select', 'multi-select', 'date', 'date-range', 'stepper', 'checkbox', 'radio'].includes(str(n.type)) || (n.type === 'file' && !m.permissions.includes('files.user')) || !/^\d{1,6}$/.test(str(n.onChange))))
            throw Error('action_unsupported');
        const inputEvents = ['onFocus', 'onBlur', 'onSubmit'];
        if (inputEvents.some(event => n[event] !== undefined) && (!m.runtime || !['field', 'secure-field', 'text-area', 'search-field'].includes(str(n.type)) || (n.type === 'text-area' && n.onSubmit !== undefined) || inputEvents.some(event => n[event] !== undefined && !/^\d{1,6}$/.test(str(n[event])))))
            throw Error('input_event_unsupported');
        if (inputEvents.some(event => n[event] !== undefined) && Number(m.minimumHostAPI || 1) < 44)
            throw Error('input_events_require_host_api_44');
        const gestureEvents = ['onLongPress', 'onDoublePress'];
        if (gestureEvents.some(event => n[event] !== undefined) && (!m.runtime || !['button', 'icon-button'].includes(str(n.type)) || gestureEvents.some(event => n[event] !== undefined && !/^\d{1,6}$/.test(str(n[event])))))
            throw Error('button_gesture_event_unsupported');
        if (gestureEvents.some(event => n[event] !== undefined) && Number(m.minimumHostAPI || 1) < 79)
            throw Error('button_gesture_events_require_host_api_79');
        if (runtimeCode && /\binteractive\s*\.\s*(?:button|iconButton)\s*\([^)]*,[^)]*,\s*\{[^}]*\bon(?:LongPress|DoublePress)\s*:/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 79)
            throw Error('button_gesture_events_require_host_api_79');
        if (n.value !== undefined && (typeof n.value !== 'string' || n.value.length > 4000 || !['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'select', 'multi-select', 'date', 'date-range', 'stepper', 'checkbox', 'radio', 'progress'].includes(str(n.type)) || (['toggle', 'checkbox'].includes(str(n.type)) && !['true', 'false'].includes(n.value)) || (n.type === 'stepper' && (!Number.isFinite(Number(n.value)) || Number(n.value) < Number(n.min) || Number(n.value) > Number(n.max) || Math.abs((Number(n.value) - Number(n.min)) / Number(n.step) - Math.round((Number(n.value) - Number(n.min)) / Number(n.step))) > 1e-8)) || (n.type === 'radio' && !(Array.isArray(n.options) && n.options.includes(n.value))) || (n.type === 'date' && n.value !== '' && !/^-?\d{1,16}$/.test(n.value)) || (n.type === 'date-range' && (() => { try {
            const range = JSON.parse(n.value);
            if (!range || Array.isArray(range) || Object.keys(range).some(key => !['start', 'end'].includes(key)) || !['start', 'end'].every(key => range[key] === null || Number.isSafeInteger(range[key]) && Math.abs(Number(range[key])) <= 8.64e15))
                return true;
            return range.start !== null && range.end !== null && Number(range.start) > Number(range.end);
        }
        catch {
            return true;
        } })()) || (n.type === 'select' && n.value !== '' && !(Array.isArray(n.options) && n.options.includes(n.value))) || (n.type === 'multi-select' && (!Array.isArray(n.options) || (() => { try {
            const options = n.options;
            const chosen = JSON.parse(n.value);
            return !Array.isArray(chosen) || chosen.some(item => typeof item !== 'string' || !options.includes(item)) || new Set(chosen).size !== chosen.length;
        }
        catch {
            return true;
        } })()))))
            throw Error('layout_invalid');
        if (n.type === 'footer' && !['page', 'course-list', 'presentation'].includes(parent))
            throw Error('layout_invalid');
        if (!['canvas', 'presentation', 'menu', 'context-menu', 'swipe-actions', 'toolbar', 'floating-button', 'lazy-list', 'lazy-grid', 'text', 'label', 'markdown', 'code', 'caption', 'badge', 'icon', 'icon-button', 'progress', 'chart', 'loading', 'empty-state', 'error-state', 'section', 'column', 'row', 'zstack', 'scroll', 'horizontal-scroll', 'spacer', 'field', 'text-area', 'secure-field', 'search-field', 'toggle', 'button', 'campus', 'heading', 'divider', 'select', 'multi-select', 'checkbox', 'radio', 'stepper', 'when', 'link', 'link-button', 'date', 'date-range', 'file', 'browser', 'media', 'board-camera', 'share-text', 'copy-text', 'course-picker', 'photo-grid', 'photo-import', 'photo-capture', 'page', 'grid', 'footer', 'disclosure', 'course-list', 'data-list', 'number', 'slider', 'card', 'group', 'container', 'safe-area', 'drag-source', 'drop-target', 'map-view', 'map-marker', 'map-polyline', 'map-circle', 'map-fit-bounds'].includes(str(n.type)))
            throw Error('component_unsupported');
        if (n.type === 'drag-source' && (!str(n.label).trim() || str(n.label).length > 120 || str(n.text).length > 4000))
            throw Error('drag_source_invalid');
        if (n.type === 'drop-target' && (!/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(str(n.key)) || !str(n.label).trim() || str(n.label).length > 120))
            throw Error('drop_target_invalid');
        if ((n.type === 'drag-source' || n.type === 'drop-target') && Number(m.minimumHostAPI || 1) < 66)
            throw Error('drag_drop_requires_host_api_66');
        if (['map-view', 'map-marker', 'map-polyline', 'map-circle', 'map-fit-bounds'].includes(str(n.type)) && Number(m.minimumHostAPI || 1) < 67)
            throw Error('map_requires_host_api_67');
        if (n.type === 'map-view') {
            let center = null;
            try {
                center = args.center ? JSON.parse(str(args.center)) : null;
            }
            catch {
                throw Error('map_coordinate_invalid');
            }
            const zoom = Number(args.zoom);
            if (Object.keys(args).some(k => !['center', 'zoom'].includes(k)) || center && (!Number.isFinite(center.latitude) || Math.abs(center.latitude) > 85.051129 || !Number.isFinite(center.longitude) || Math.abs(center.longitude) > 180) || !Number.isFinite(zoom) || zoom < 2 || zoom > 19 || !Number.isFinite(n.size) || Number(n.size) < 140 || Number(n.size) > 600 || !Array.isArray(n.children) || n.children.length > 100)
                throw Error('map_view_invalid');
        }
        if (n.type === 'map-marker') {
            let p;
            try {
                p = JSON.parse(str(args.coordinate));
            }
            catch {
                throw Error('map_coordinate_invalid');
            }
            if (!str(n.label).trim() || str(n.label).length > 100 || str(n.text).length > 160 || !Number.isFinite(p.latitude) || Math.abs(p.latitude) > 85.051129 || !Number.isFinite(p.longitude) || Math.abs(p.longitude) > 180)
                throw Error('map_marker_invalid');
        }
        if (n.type === 'map-polyline' || n.type === 'map-fit-bounds') {
            let pts;
            try {
                pts = JSON.parse(str(args.coordinates));
            }
            catch {
                throw Error('map_coordinates_invalid');
            }
            if (!Array.isArray(pts) || pts.length < 2 || pts.length > (n.type === 'map-polyline' ? 1000 : 64) || pts.some(p => !p || !Number.isFinite(p.latitude) || Math.abs(p.latitude) > 85.051129 || !Number.isFinite(p.longitude) || Math.abs(p.longitude) > 180))
                throw Error('map_coordinates_invalid');
            if (n.type === 'map-polyline' && (!Number.isFinite(n.size) || Number(n.size) < 1 || Number(n.size) > 12 || !['primary', 'secondary', 'accent'].includes(str(n.style?.tone))))
                throw Error('map_shape_invalid');
            if (n.type === 'map-fit-bounds' && (!Number.isFinite(n.size) || Number(n.size) < 0 || Number(n.size) > 100))
                throw Error('map_bounds_invalid');
        }
        if (n.type === 'map-circle') {
            let p;
            try {
                p = JSON.parse(str(args.coordinate));
            }
            catch {
                throw Error('map_coordinate_invalid');
            }
            const radius = Number(args.radiusMeters);
            if (!Number.isFinite(p.latitude) || Math.abs(p.latitude) > 85.051129 || !Number.isFinite(p.longitude) || Math.abs(p.longitude) > 180 || !Number.isFinite(radius) || radius < 1 || radius > 50000 || !Number.isFinite(n.size) || Number(n.size) < 1 || Number(n.size) > 12 || !['primary', 'secondary', 'accent'].includes(str(n.style?.tone)))
                throw Error('map_circle_invalid');
        }
        if (n.type === 'link-button' && Number(m.minimumHostAPI || 1) < 47)
            throw Error('link_button_requires_host_api_47');
        if (n.type === 'search-field' && (!m.runtime || !/^[0-9]{1,6}$/.test(str(n.onChange)) || !str(n.label).trim()))
            throw Error('search_field_invalid');
        if (n.type === 'search-field' && Number(m.minimumHostAPI || 1) < 46)
            throw Error('search_field_requires_host_api_46');
        if (n.type === 'icon-button' && (!['book', 'calendar', 'bus', 'check', 'clock', 'info', 'map', 'person', 'photo', 'plus', 'search', 'edit', 'list', 'bell'].includes(str(n.text)) || !str(n.label).trim() || n.action !== 'runtime.event' || !m.runtime || !/^\d{1,6}$/.test(str(n.arguments?.event))))
            throw Error('icon_button_invalid');
        if (n.type === 'icon-button' && Number(m.minimumHostAPI || 1) < 45)
            throw Error('icon_button_requires_host_api_45');
        if (n.type === 'canvas') {
            if (Number(m.minimumHostAPI || 1) < 58 || !str(n.label).trim())
                throw Error('drawing_requires_host_api_58');
            validateDrawing(n.arguments, m.permissions);
        }
        if (n.type === 'chart') {
            let series;
            try {
                series = JSON.parse(String(n.arguments?.series || ''));
            }
            catch {
                throw Error('chart_data_invalid');
            }
            const labels = n.options;
            const validSeries = (row) => {
                if (!row || typeof row !== 'object' || Array.isArray(row))
                    return false;
                const item = row, values = item.values;
                return Object.keys(item).every(key => ['label', 'values'].includes(key)) && typeof item.label === 'string' && !!item.label.trim() && item.label.length <= 80 && Array.isArray(values) && values.length === labels?.length && values.every(number => typeof number === 'number' && Number.isFinite(number) && number >= 0 && number <= 1e6);
            };
            if (!str(n.label).trim() || n.kind !== 'bar' || !Array.isArray(labels) || labels.length < 1 || labels.length > 12 || labels.some(label => typeof label !== 'string' || !label.trim() || label.length > 40) || new Set(labels).size !== labels.length || !n.arguments || Object.keys(n.arguments).length !== 1 || !Array.isArray(series) || series.length < 1 || series.length > 4 || series.some(row => !validSeries(row)))
                throw Error('chart_data_invalid');
        }
        if (n.type === 'progress' && (!str(n.label).trim() || typeof n.value !== 'string' || !Number.isFinite(Number(n.value)) || Number(n.value) < 0 || Number(n.value) > 1))
            throw Error('layout_invalid');
        if (['loading', 'empty-state', 'error-state'].includes(str(n.type)) && (!str(n.label).trim() || (n.type !== 'loading' && (typeof n.text !== 'string' || !str(n.text).trim()))))
            throw Error('layout_invalid');
        if (n.type === 'spacer' && (!Number.isInteger(n.size) || Number(n.size) < 0 || Number(n.size) > 120))
            throw Error('layout_invalid');
        if (['number', 'slider', 'stepper'].includes(str(n.type))) {
            for (const k of ['min', 'max', 'step'])
                if (typeof n[k] !== 'number' || !Number.isFinite(n[k]) || Math.abs(Number(n[k])) > 1e9)
                    throw Error('layout_invalid');
            if (Number(n.min) >= Number(n.max) || Number(n.step) <= 0 || Number(n.step) > Number(n.max) - Number(n.min))
                throw Error('layout_invalid');
        }
        if (['checkbox', 'radio', 'stepper'].includes(str(n.type)) && (!str(n.label).trim() || (n.type === 'radio' && (!Array.isArray(n.options) || n.options.length < 1 || n.options.length > 30 || n.options.some(item => typeof item !== 'string' || !item.trim() || item.length > 120) || new Set(n.options).size !== n.options.length))))
            throw Error('layout_invalid');
        if (['checkbox', 'radio', 'stepper'].includes(str(n.type)) && typeof n.value !== 'string')
            throw Error('layout_invalid');
        if (n.type === 'data-list') {
            if (!['profile.displayName', 'courses.data', 'timetable.periods', 'assignments.data', 'todos.data', 'academic.calendar', 'bus.schedule', 'cafeteria.locations', 'cafeteria.menu', 'cafeteria.cameraStatus', 'cafeteria.hours'].includes(str(n.query)) || !m.permissions.includes(campusQueries[str(n.query)]))
                throw Error('unsupported_query');
            if (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)) || ids.has(str(n.key)))
                throw Error('field_key_invalid');
            ids.add(str(n.key));
            if (!Number.isInteger(n.limit) || Number(n.limit) < 1 || Number(n.limit) > 100)
                throw Error('layout_invalid');
            function readOnly(nodes) { for (const child of nodes) {
                if (!['text', 'label', 'markdown', 'code', 'caption', 'badge', 'icon', 'progress', 'chart', 'loading', 'empty-state', 'error-state', 'heading', 'section', 'column', 'row', 'zstack', 'scroll', 'horizontal-scroll', 'spacer', 'grid', 'disclosure', 'page', 'footer', 'link', 'browser', 'media', 'share-text', 'copy-text', 'divider', 'card', 'group', 'container'].includes(str(child.type)))
                    throw Error('component_unsupported');
                if (Array.isArray(child.children))
                    readOnly(child.children);
            } }
            if (Array.isArray(n.children))
                readOnly(n.children);
        }
        if ((['grid', 'lazy-grid'].includes(str(n.type)) || (n.type === 'photo-grid' && n.columns !== undefined)) && (!Number.isInteger(n.columns) || Number(n.columns) < 1 || Number(n.columns) > 6))
            throw Error('layout_invalid');
        if (n.style !== undefined) {
            const style = n.style;
            if (!style || typeof style !== 'object' || Array.isArray(style) || Object.keys(style).some(k => !['tone', 'textSize', 'align', 'padding', 'spacing', 'minWidth', 'maxWidth', 'minHeight', 'maxHeight', 'aspectRatio', 'weight', 'lineLimit', 'selectable'].includes(k)))
                throw Error('layout_invalid');
            for (const [k, options] of Object.entries({ tone: ['primary', 'secondary', 'accent'], textSize: ['caption', 'body', 'title'], align: ['leading', 'center', 'trailing'] }))
                if (style[k] !== undefined && !options.includes(String(style[k])))
                    throw Error('layout_invalid');
            for (const k of ['padding', 'spacing'])
                if (style[k] !== undefined && (typeof style[k] !== 'number' || !Number.isInteger(style[k]) || Number(style[k]) < 0 || Number(style[k]) > 32))
                    throw Error('layout_invalid');
            for (const k of ['minWidth', 'maxWidth', 'minHeight', 'maxHeight'])
                if (style[k] !== undefined && (typeof style[k] !== 'number' || !Number.isFinite(style[k]) || Number(style[k]) < 0 || Number(style[k]) > 2000))
                    throw Error('layout_invalid');
            if (style.minWidth !== undefined && style.maxWidth !== undefined && Number(style.minWidth) > Number(style.maxWidth) || style.minHeight !== undefined && style.maxHeight !== undefined && Number(style.minHeight) > Number(style.maxHeight))
                throw Error('layout_invalid');
            if (style.aspectRatio !== undefined && (typeof style.aspectRatio !== 'number' || !Number.isFinite(style.aspectRatio) || Number(style.aspectRatio) < 0.1 || Number(style.aspectRatio) > 10))
                throw Error('layout_invalid');
            if (style.weight !== undefined && !['regular', 'medium', 'semibold', 'bold'].includes(String(style.weight)))
                throw Error('layout_invalid');
            if (style.lineLimit !== undefined && (!Number.isInteger(style.lineLimit) || Number(style.lineLimit) < 1 || Number(style.lineLimit) > 100))
                throw Error('layout_invalid');
            if (style.selectable !== undefined && typeof style.selectable !== 'boolean')
                throw Error('layout_invalid');
        }
        if (n.accessibility !== undefined) {
            const a = n.accessibility;
            const roles = { text: ['text', 'heading'], label: ['text'], markdown: ['text'], code: ['text'], caption: ['text'], badge: ['text'], icon: ['text'], heading: ['heading', 'text'], button: ['button'], 'icon-button': ['button'], toggle: ['switch'], field: ['textField'], 'text-area': ['textField'], 'secure-field': ['textField'], 'search-field': ['textField'], link: ['link'], 'link-button': ['link'] };
            if (!roles[str(n.type)] || !a || typeof a !== 'object' || Array.isArray(a) || Object.keys(a).some(k => !['label', 'hint', 'role'].includes(k)))
                throw Error('accessibility_invalid');
            for (const k of ['label', 'hint'])
                if (a[k] !== undefined && (typeof a[k] !== 'string' || !String(a[k]).trim() || String(a[k]).length > 1000))
                    throw Error('accessibility_invalid');
            if (a.role !== undefined && (typeof a.role !== 'string' || !roles[str(n.type)].includes(a.role)))
                throw Error('accessibility_invalid');
        }
        if (['course-picker', 'course-list'].includes(str(n.type)) && !m.permissions.includes('timetable.read'))
            throw Error('unsupported_permission');
        if (['photo-grid', 'photo-import', 'photo-capture'].includes(str(n.type))) {
            if (!m.permissions.includes('photos.user') || (n.type === 'photo-capture' && !m.permissions.includes('camera.use')))
                throw Error('unsupported_permission');
            if (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)))
                throw Error('field_key_invalid');
            if (n.arguments !== undefined) {
                const args = n.arguments;
                if (!args || Array.isArray(args) || Object.keys(args).some(k => k !== 'course') || !/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(args.course)))
                    throw Error('action_field_invalid');
            }
        }
        if (n.type === 'board-camera' && !m.permissions.includes('board.camera'))
            throw Error('unsupported_permission');
        if (n.type === 'media' && (!m.permissions.includes('media.remote') || !['image', 'video', 'audio'].includes(str(n.kind))))
            throw Error('unsupported_permission');
        if (n.type === 'browser' && !m.permissions.includes('browser.open'))
            throw Error('unsupported_permission');
        if (n.type === 'file' && !m.permissions.includes('files.user'))
            throw Error('unsupported_permission');
        if (n.type === 'campus' && (!Object.hasOwn(campusQueries, str(n.query)) || !m.permissions.includes(campusQueries[str(n.query)])))
            throw Error('unsupported_query');
        if (n.type === 'campus' && n.query === 'cafeteria.hours' && Number(m.minimumHostAPI || 1) < 65)
            throw Error('cafeteria_hours_requires_host_api_65');
        for (const key of ['text', 'label', 'key', 'action', 'equals', 'url'])
            if (n[key] !== undefined && typeof n[key] !== 'string')
                throw Error('layout_invalid');
        if (['text', 'label', 'markdown', 'code', 'caption', 'badge', 'icon', 'heading', 'share-text', 'copy-text', 'empty-state', 'error-state'].includes(str(n.type)) && typeof n.text !== 'string')
            throw Error('layout_invalid');
        if (['text', 'label', 'markdown', 'code', 'caption', 'badge', 'heading', 'share-text', 'copy-text', 'empty-state', 'error-state'].includes(str(n.type)) && (str(n.text).length > 6000))
            throw Error('layout_invalid');
        if (n.type === 'icon' && (!['book', 'calendar', 'bus', 'check', 'clock', 'info', 'map', 'person', 'photo', 'plus', 'search', 'edit', 'list', 'bell'].includes(str(n.text)) || !str(n.label).trim() || str(n.label).length > 120))
            throw Error('layout_invalid');
        if (['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'button', 'select', 'multi-select', 'checkbox', 'radio', 'stepper', 'link', 'link-button', 'date', 'file', 'browser', 'media', 'board-camera', 'share-text', 'copy-text', 'course-picker', 'photo-grid', 'photo-import', 'photo-capture', 'page', 'disclosure', 'course-list', 'number', 'slider', 'loading', 'empty-state', 'error-state'].includes(str(n.type)) && !str(n.label).trim())
            throw Error('layout_invalid');
        if (str(n.text).length > 4000 || str(n.label).length > 120)
            throw Error('text_too_long');
        if (['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'select', 'multi-select', 'checkbox', 'radio', 'stepper', 'date', 'file', 'course-picker', 'course-list', 'number', 'slider', 'drop-target'].includes(str(n.type))) {
            if (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)) || ids.has(str(n.key)))
                throw Error('field_key_invalid');
            ids.add(str(n.key));
            fields.set(str(n.key), str(n.type));
        }
        if (['select', 'multi-select'].includes(str(n.type)) && (!Array.isArray(n.options) || n.options.length < 1 || n.options.length > 30 || new Set(n.options).size !== n.options.length || n.options.some(o => typeof o !== 'string' || !o.trim() || o.length > 120)))
            throw Error('layout_invalid');
        if (n.type === 'when' && (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)) || typeof n.equals !== 'string' || n.equals.length > 4000))
            throw Error('layout_invalid');
        if (['link', 'link-button', 'browser', 'media'].includes(str(n.type))) {
            try {
                const u = new URL(str(n.url));
                if (u.protocol !== 'https:' || u.username || u.password || str(n.url).length > 2000)
                    throw Error();
            }
            catch {
                throw Error('action_unsupported');
            }
        }
        if (['button', 'icon-button'].includes(str(n.type)) && !['save', 'reset', 'todo.create', 'state.set', 'state.increment', 'runtime.event'].includes(str(n.action)))
            throw Error('action_unsupported');
        if (['state.set', 'state.increment'].includes(str(n.action))) {
            const args = n.arguments;
            const valueKey = n.action === 'state.set' ? 'value' : 'amount';
            if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some(k => !['field', valueKey].includes(k)) || !/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(args.field)) || typeof args[valueKey] !== 'string' || String(args[valueKey]).length > 4000)
                throw Error('action_field_invalid');
            if (n.action === 'state.increment' && (!Number.isFinite(Number(args.amount)) || Math.abs(Number(args.amount)) > 1e9))
                throw Error('action_field_invalid');
            stateActions.push({ ...args, action: n.action });
        }
        if (n.action === 'runtime.event') {
            if (!m.runtime || !['button', 'icon-button'].includes(str(n.type)) || !n.arguments || Object.keys(n.arguments).some(key => key !== 'event') || !/^\d{1,6}$/.test(str(n.arguments.event)))
                throw Error('action_unsupported');
        }
        if (n.action === 'todo.create') {
            if (!m.permissions.includes('todos.write'))
                throw Error('unsupported_permission');
            const args = n.arguments;
            if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some(k => !['title', 'detail', 'deadline', 'notification'].includes(k)) || Object.values(args).some(v => !/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(String(v))) || !['title', 'detail'].every(k => /^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(args[k]))))
                throw Error('action_unsupported');
            todoActions.push(args);
        }
        if (n.type === 'button' && n.action === 'save' && !m.permissions.includes('cloud.storage'))
            throw Error('unsupported_permission');
        if (n.children !== undefined) {
            if (!Array.isArray(n.children) || !['presentation', 'menu', 'context-menu', 'swipe-actions', 'toolbar', 'floating-button', 'lazy-list', 'lazy-grid', 'section', 'column', 'row', 'zstack', 'scroll', 'horizontal-scroll', 'when', 'page', 'grid', 'footer', 'disclosure', 'course-list', 'data-list', 'card', 'group', 'container', 'safe-area', 'map-view'].includes(str(n.type)))
                throw Error('children_invalid');
            n.children.forEach(child => visit(child, depth + 1, str(n.type)));
        }
    }
    if (!Array.isArray(m.content) || !m.content.length)
        throw Error('layout_invalid');
    m.content.forEach(node => visit(node, 0));
    for (const args of stateActions) {
        const type = fields.get(str(args.field));
        if (!type || type === 'file')
            throw Error('action_field_invalid');
        if (args.action === 'state.increment' && !['number', 'slider', 'stepper'].includes(type))
            throw Error('action_field_invalid');
    }
    for (const args of todoActions) {
        for (const key of ['title', 'detail'])
            if (fields.get(str(args[key])) !== 'field')
                throw Error('action_field_invalid');
        for (const key of ['deadline', 'notification'])
            if (args[key] !== undefined && fields.get(str(args[key])) !== 'date')
                throw Error('action_field_invalid');
    }
    function checkPhotoRefs(nodes) { for (const n of nodes) {
        if (['photo-grid', 'photo-import', 'photo-capture'].includes(str(n.type)) && n.arguments) {
            if (!['course-picker', 'course-list'].includes(fields.get(str(n.arguments.course)) ?? ''))
                throw Error('action_field_invalid');
        }
        if (Array.isArray(n.children))
            checkPhotoRefs(n.children);
    } }
    checkPhotoRefs(m.content);
    if (JSON.stringify({ ...m, runtime: undefined }).length > 60000)
        throw Error('manifest_too_large');
}
