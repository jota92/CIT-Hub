export const campusQueries = {
    'settings.display': 'settings.read', 'services.enabled': 'settings.read', 'courseNotes.data': 'courseNotes.read', 'courses.data': 'timetable.read', 'timetable.periods': 'timetable.read', 'assignments.data': 'assignments.read', 'todos.data': 'todos.read', 'academic.calendar': 'calendar.read', 'bus.schedule': 'bus.read', 'cafeteria.locations': 'cafeteria.read', 'cafeteria.menu': 'cafeteria.read', 'cafeteria.cameraStatus': 'cafeteria.read',
    'courses.current': 'timetable.read', 'courses.next': 'timetable.read',
    'courses.today': 'timetable.read', 'courses.week': 'timetable.read',
    'enrollment.summary': 'timetable.read', 'assignments.pending': 'assignments.read',
    'assignments.summary': 'assignments.read', 'assignments.overdue': 'assignments.read',
    'assignments.dueSoon': 'assignments.read', 'todos.summary': 'todos.read'
};
const str = (v) => typeof v === 'string' ? v : '';
const now = () => Math.floor(Date.now() / 1000);
const random = () => crypto.randomUUID().replaceAll('-', '');
async function hash(value) { return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))), b => b.toString(16).padStart(2, '0')).join(''); }
export async function extensionPrincipal(userID, key) {
    return hash(`cithub-extension-v1:${userID}:${key}`);
}
function compareVersions(a, b) {
    const av = a.split('.').map(BigInt), bv = b.split('.').map(BigInt);
    for (let i = 0; i < 3; i++) {
        if (av[i] > bv[i])
            return 1;
        if (av[i] < bv[i])
            return -1;
    }
    return 0;
}
export function validateExtension(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw Error('manifest_invalid');
    const m = value;
    if (m.minimumHostAPI !== undefined && (!Number.isInteger(m.minimumHostAPI) || Number(m.minimumHostAPI) < 1 || Number(m.minimumHostAPI) > 47))
        throw Error('manifest_host_api_invalid');
    if (m.runtime !== undefined) {
        const runtime = m.runtime;
        if (!runtime || typeof runtime !== 'object' || Array.isArray(runtime) || runtime.engine !== 'quickjs-v1' || typeof runtime.code !== 'string' || !runtime.code.trim() || runtime.code.length > 150000 || Object.keys(runtime).some(key => !['engine', 'code'].includes(key)))
            throw Error('manifest_runtime_invalid');
    }
    if (m.schemaVersion !== 1 || !str(m.name).trim() || str(m.name).length > 60 || !/^\d+\.\d+\.\d+$/.test(str(m.version)) || str(m.version).length > 40 || typeof m.description !== 'string' || m.description.length > 2000)
        throw Error('manifest_invalid');
    if (!Array.isArray(m.permissions) || m.permissions.some(p => !['cloud.storage', 'timetable.read', 'assignments.read', 'todos.read', 'todos.write', 'calendar.read', 'bus.read', 'cafeteria.read', 'files.user', 'files.selection.read', 'files.storage', 'browser.open', 'settings.read', 'settings.open', 'courseNotes.read', 'courseNotes.write', 'media.remote', 'board.camera', 'photos.user', 'camera.use', 'location.use', 'network.status', 'network.fetch', 'clipboard.read', 'clipboard.write', 'notifications.schedule'].includes(String(p))) || new Set(m.permissions).size !== m.permissions.length)
        throw Error('unsupported_permission');
    const networkHosts = m.network;
    if (networkHosts !== undefined && (!Array.isArray(networkHosts) || networkHosts.length < 1 || networkHosts.length > 20 || new Set(networkHosts).size !== networkHosts.length || networkHosts.some(host => typeof host !== 'string' || host !== host.toLowerCase() || host.length > 253 || !host.includes('.') || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(':') || host.split('.').some(label => !/^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)$/.test(label)))))
        throw Error('network_hosts_invalid');
    if (m.permissions.includes('network.fetch') !== Array.isArray(networkHosts))
        throw Error('network_hosts_invalid');
    const runtimeCode = m.runtime?.code;
    if (runtimeCode && /\bnetwork\s*\.\s*(?:uploadFile|downloadFile)\s*\(/.test(runtimeCode) && (!m.permissions.includes('network.fetch') || !m.permissions.includes('files.storage') || Number(m.minimumHostAPI || 1) < 33))
        throw Error('network_file_transfer_requirements');
    if (runtimeCode && /\binteractive\s*\.\s*multiSelect\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 34)
        throw Error('interactive_multi_select_requires_host_api_34');
    if (runtimeCode && /\binteractive\s*\.\s*dateTime\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 35)
        throw Error('interactive_date_time_requires_host_api_35');
    if (runtimeCode && /\binteractive\s*\.\s*dateRange\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 36)
        throw Error('interactive_date_range_requires_host_api_36');
    if (runtimeCode && /\binteractive\s*\.\s*(?:stepper|checkbox|radio)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 37)
        throw Error('interactive_form_controls_require_host_api_37');
    if (runtimeCode && /\bui\s*\.\s*progress\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 38)
        throw Error('progress_ui_requires_host_api_38');
    if (runtimeCode && /\bui\s*\.\s*(?:loading|emptyState|errorState)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 39)
        throw Error('status_ui_requires_host_api_39');
    if (runtimeCode && /\bui\s*\.\s*(?:card|group|container)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 40)
        throw Error('responsive_container_requires_host_api_40');
    if (runtimeCode && /\banimation\s*\.\s*(?:animate|spring|transition)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 41)
        throw Error('animation_requires_host_api_41');
    function usesChart(nodes) { return nodes.some(node => node.type === 'chart' || Array.isArray(node.children) && usesChart(node.children)); }
    if (Array.isArray(m.content) && usesChart(m.content) && Number(m.minimumHostAPI || 1) < 42)
        throw Error('chart_requires_host_api_42');
    if (runtimeCode && /\bui\s*\.\s*barChart\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 42)
        throw Error('chart_requires_host_api_42');
    function usesLayout43(nodes) { return nodes.some(node => node.type === 'safe-area' || ['minWidth', 'maxWidth', 'minHeight', 'maxHeight', 'aspectRatio'].some(key => Object.hasOwn(node.style || {}, key)) || Array.isArray(node.children) && usesLayout43(node.children)); }
    if (Array.isArray(m.content) && usesLayout43(m.content) && Number(m.minimumHostAPI || 1) < 43)
        throw Error('responsive_geometry_requires_host_api_43');
    if (runtimeCode && /\bui\s*\.\s*(?:safeArea|frame)\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 43)
        throw Error('responsive_geometry_requires_host_api_43');
    if (runtimeCode && /\binteractive\s*\.\s*iconButton\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 45)
        throw Error('icon_button_requires_host_api_45');
    if (runtimeCode && /\binteractive\s*\.\s*searchField\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 46)
        throw Error('search_field_requires_host_api_46');
    if (runtimeCode && /\bui\s*\.\s*linkButton\s*\(/.test(runtimeCode) && Number(m.minimumHostAPI || 1) < 47)
        throw Error('link_button_requires_host_api_47');
    function usesStatusNode(nodes) { return nodes.some(node => ['loading', 'empty-state', 'error-state'].includes(str(node.type)) || Array.isArray(node.children) && usesStatusNode(node.children)); }
    if (Array.isArray(m.content) && usesStatusNode(m.content) && Number(m.minimumHostAPI || 1) < 39)
        throw Error('status_ui_requires_host_api_39');
    function usesContainerNode(nodes) { return nodes.some(node => ['card', 'group', 'container'].includes(str(node.type)) || Array.isArray(node.children) && usesContainerNode(node.children)); }
    if (Array.isArray(m.content) && usesContainerNode(m.content) && Number(m.minimumHostAPI || 1) < 40)
        throw Error('responsive_container_requires_host_api_40');
    let count = 0;
    const ids = new Set();
    const fields = new Map();
    const todoActions = [];
    const stateActions = [];
    function visit(value, depth, parent = "") {
        if (++count > 120 || depth > 8 || !value || typeof value !== 'object' || Array.isArray(value))
            throw Error('layout_invalid');
        const n = value;
        if (n.onChange !== undefined && (!m.runtime || !['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'file', 'select', 'multi-select', 'date', 'date-range', 'stepper', 'checkbox', 'radio'].includes(str(n.type)) || (n.type === 'file' && !m.permissions.includes('files.user')) || !/^\d{1,6}$/.test(str(n.onChange))))
            throw Error('action_unsupported');
        const inputEvents = ['onFocus', 'onBlur', 'onSubmit'];
        if (inputEvents.some(event => n[event] !== undefined) && (!m.runtime || !['field', 'secure-field', 'text-area', 'search-field'].includes(str(n.type)) || (n.type === 'text-area' && n.onSubmit !== undefined) || inputEvents.some(event => n[event] !== undefined && !/^\d{1,6}$/.test(str(n[event])))))
            throw Error('input_event_unsupported');
        if (inputEvents.some(event => n[event] !== undefined) && Number(m.minimumHostAPI || 1) < 44)
            throw Error('input_events_require_host_api_44');
        if (n.value !== undefined && (typeof n.value !== 'string' || n.value.length > 4000 || !['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'select', 'multi-select', 'date', 'date-range', 'stepper', 'checkbox', 'radio', 'progress'].includes(str(n.type)) || (['toggle', 'checkbox'].includes(str(n.type)) && !['true', 'false'].includes(n.value)) || (n.type === 'stepper' && (!Number.isFinite(Number(n.value)) || Number(n.value) < Number(n.min) || Number(n.value) > Number(n.max) || Math.abs((Number(n.value) - Number(n.min)) / Number(n.step) - Math.round((Number(n.value) - Number(n.min)) / Number(n.step))) > 1e-8)) || (n.type === 'radio' && !(Array.isArray(n.options) && n.options.includes(n.value))) || (n.type === 'date' && n.value !== '' && !/^-?\d{1,16}$/.test(n.value)) || (n.type === 'date-range' && (() => { try {
            const range = JSON.parse(n.value);
            if (!range || Array.isArray(range) || Object.keys(range).some(key => !['start', 'end'].includes(key)) || !['start', 'end'].every(key => range[key] === null || Number.isSafeInteger(range[key]) && Math.abs(Number(range[key])) <= 8.64e15))
                return true;
            return range.start !== null && range.end !== null && Number(range.start) > Number(range.end);
        }
        catch {
            return true;
        } })()) || (n.type === 'select' && n.value !== '' && !(Array.isArray(n.options) && n.options.includes(n.value))) || (n.type === 'multi-select' && (!Array.isArray(n.options) || (() => { try {
            const options = n.options;
            const chosen = JSON.parse(n.value);
            return !Array.isArray(chosen) || chosen.some(item => typeof item !== 'string' || !options.includes(item)) || new Set(chosen).size !== chosen.length;
        }
        catch {
            return true;
        } })()))))
            throw Error('layout_invalid');
        if (n.type === 'footer' && !['page', 'course-list'].includes(parent))
            throw Error('layout_invalid');
        if (!['text', 'label', 'markdown', 'code', 'caption', 'badge', 'icon', 'icon-button', 'progress', 'chart', 'loading', 'empty-state', 'error-state', 'section', 'column', 'row', 'zstack', 'scroll', 'horizontal-scroll', 'spacer', 'field', 'text-area', 'secure-field', 'search-field', 'toggle', 'button', 'campus', 'heading', 'divider', 'select', 'multi-select', 'checkbox', 'radio', 'stepper', 'when', 'link', 'link-button', 'date', 'date-range', 'file', 'browser', 'media', 'board-camera', 'share-text', 'copy-text', 'course-picker', 'photo-grid', 'photo-import', 'photo-capture', 'page', 'grid', 'footer', 'disclosure', 'course-list', 'data-list', 'number', 'slider', 'card', 'group', 'container', 'safe-area'].includes(str(n.type)))
            throw Error('component_unsupported');
        if (n.type === 'link-button' && Number(m.minimumHostAPI || 1) < 47)
            throw Error('link_button_requires_host_api_47');
        if (n.type === 'search-field' && (!m.runtime || !/^[0-9]{1,6}$/.test(str(n.onChange)) || !str(n.label).trim()))
            throw Error('search_field_invalid');
        if (n.type === 'search-field' && Number(m.minimumHostAPI || 1) < 46)
            throw Error('search_field_requires_host_api_46');
        if (n.type === 'icon-button' && (!['book', 'calendar', 'bus', 'check', 'clock', 'info', 'map', 'person', 'photo', 'plus', 'search', 'edit', 'list', 'bell'].includes(str(n.text)) || !str(n.label).trim() || n.action !== 'runtime.event' || !m.runtime || !/^\d{1,6}$/.test(str(n.arguments?.event))))
            throw Error('icon_button_invalid');
        if (n.type === 'icon-button' && Number(m.minimumHostAPI || 1) < 45)
            throw Error('icon_button_requires_host_api_45');
        if (n.type === 'chart') {
            let series;
            try {
                series = JSON.parse(String(n.arguments?.series || ''));
            }
            catch {
                throw Error('chart_data_invalid');
            }
            const labels = n.options;
            const validSeries = (row) => {
                if (!row || typeof row !== 'object' || Array.isArray(row))
                    return false;
                const item = row, values = item.values;
                return Object.keys(item).every(key => ['label', 'values'].includes(key)) && typeof item.label === 'string' && !!item.label.trim() && item.label.length <= 80 && Array.isArray(values) && values.length === labels?.length && values.every(number => typeof number === 'number' && Number.isFinite(number) && number >= 0 && number <= 1e6);
            };
            if (!str(n.label).trim() || n.kind !== 'bar' || !Array.isArray(labels) || labels.length < 1 || labels.length > 12 || labels.some(label => typeof label !== 'string' || !label.trim() || label.length > 40) || new Set(labels).size !== labels.length || !n.arguments || Object.keys(n.arguments).length !== 1 || !Array.isArray(series) || series.length < 1 || series.length > 4 || series.some(row => !validSeries(row)))
                throw Error('chart_data_invalid');
        }
        if (n.type === 'progress' && (!str(n.label).trim() || typeof n.value !== 'string' || !Number.isFinite(Number(n.value)) || Number(n.value) < 0 || Number(n.value) > 1))
            throw Error('layout_invalid');
        if (['loading', 'empty-state', 'error-state'].includes(str(n.type)) && (!str(n.label).trim() || (n.type !== 'loading' && (typeof n.text !== 'string' || !str(n.text).trim()))))
            throw Error('layout_invalid');
        if (n.type === 'spacer' && (!Number.isInteger(n.size) || Number(n.size) < 0 || Number(n.size) > 120))
            throw Error('layout_invalid');
        if (['number', 'slider', 'stepper'].includes(str(n.type))) {
            for (const k of ['min', 'max', 'step'])
                if (typeof n[k] !== 'number' || !Number.isFinite(n[k]) || Math.abs(Number(n[k])) > 1e9)
                    throw Error('layout_invalid');
            if (Number(n.min) >= Number(n.max) || Number(n.step) <= 0 || Number(n.step) > Number(n.max) - Number(n.min))
                throw Error('layout_invalid');
        }
        if (['checkbox', 'radio', 'stepper'].includes(str(n.type)) && (!str(n.label).trim() || (n.type === 'radio' && (!Array.isArray(n.options) || n.options.length < 1 || n.options.length > 30 || n.options.some(item => typeof item !== 'string' || !item.trim() || item.length > 120) || new Set(n.options).size !== n.options.length))))
            throw Error('layout_invalid');
        if (['checkbox', 'radio', 'stepper'].includes(str(n.type)) && typeof n.value !== 'string')
            throw Error('layout_invalid');
        if (n.type === 'data-list') {
            if (!['courses.data', 'timetable.periods', 'assignments.data', 'todos.data', 'academic.calendar', 'bus.schedule', 'cafeteria.locations', 'cafeteria.menu', 'cafeteria.cameraStatus'].includes(str(n.query)) || !m.permissions.includes(campusQueries[str(n.query)]))
                throw Error('unsupported_query');
            if (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)) || ids.has(str(n.key)))
                throw Error('field_key_invalid');
            ids.add(str(n.key));
            if (!Number.isInteger(n.limit) || Number(n.limit) < 1 || Number(n.limit) > 100)
                throw Error('layout_invalid');
            function readOnly(nodes) { for (const child of nodes) {
                if (!['text', 'label', 'markdown', 'code', 'caption', 'badge', 'icon', 'progress', 'chart', 'loading', 'empty-state', 'error-state', 'heading', 'section', 'column', 'row', 'zstack', 'scroll', 'horizontal-scroll', 'spacer', 'grid', 'disclosure', 'page', 'footer', 'link', 'browser', 'media', 'share-text', 'copy-text', 'divider', 'card', 'group', 'container'].includes(str(child.type)))
                    throw Error('component_unsupported');
                if (Array.isArray(child.children))
                    readOnly(child.children);
            } }
            if (Array.isArray(n.children))
                readOnly(n.children);
        }
        if ((n.type === 'grid' || (n.type === 'photo-grid' && n.columns !== undefined)) && (!Number.isInteger(n.columns) || Number(n.columns) < 1 || Number(n.columns) > 6))
            throw Error('layout_invalid');
        if (n.style !== undefined) {
            const style = n.style;
            if (!style || typeof style !== 'object' || Array.isArray(style) || Object.keys(style).some(k => !['tone', 'textSize', 'align', 'padding', 'spacing', 'minWidth', 'maxWidth', 'minHeight', 'maxHeight', 'aspectRatio', 'weight', 'lineLimit', 'selectable'].includes(k)))
                throw Error('layout_invalid');
            for (const [k, options] of Object.entries({ tone: ['primary', 'secondary', 'accent'], textSize: ['caption', 'body', 'title'], align: ['leading', 'center', 'trailing'] }))
                if (style[k] !== undefined && !options.includes(String(style[k])))
                    throw Error('layout_invalid');
            for (const k of ['padding', 'spacing'])
                if (style[k] !== undefined && (typeof style[k] !== 'number' || !Number.isInteger(style[k]) || Number(style[k]) < 0 || Number(style[k]) > 32))
                    throw Error('layout_invalid');
            for (const k of ['minWidth', 'maxWidth', 'minHeight', 'maxHeight'])
                if (style[k] !== undefined && (typeof style[k] !== 'number' || !Number.isFinite(style[k]) || Number(style[k]) < 0 || Number(style[k]) > 2000))
                    throw Error('layout_invalid');
            if (style.minWidth !== undefined && style.maxWidth !== undefined && Number(style.minWidth) > Number(style.maxWidth) || style.minHeight !== undefined && style.maxHeight !== undefined && Number(style.minHeight) > Number(style.maxHeight))
                throw Error('layout_invalid');
            if (style.aspectRatio !== undefined && (typeof style.aspectRatio !== 'number' || !Number.isFinite(style.aspectRatio) || Number(style.aspectRatio) < 0.1 || Number(style.aspectRatio) > 10))
                throw Error('layout_invalid');
            if (style.weight !== undefined && !['regular', 'medium', 'semibold', 'bold'].includes(String(style.weight)))
                throw Error('layout_invalid');
            if (style.lineLimit !== undefined && (!Number.isInteger(style.lineLimit) || Number(style.lineLimit) < 1 || Number(style.lineLimit) > 100))
                throw Error('layout_invalid');
            if (style.selectable !== undefined && typeof style.selectable !== 'boolean')
                throw Error('layout_invalid');
        }
        if (n.accessibility !== undefined) {
            const a = n.accessibility;
            const roles = { text: ['text', 'heading'], label: ['text'], markdown: ['text'], code: ['text'], caption: ['text'], badge: ['text'], icon: ['text'], heading: ['heading', 'text'], button: ['button'], 'icon-button': ['button'], toggle: ['switch'], field: ['textField'], 'text-area': ['textField'], 'secure-field': ['textField'], 'search-field': ['textField'], link: ['link'], 'link-button': ['link'] };
            if (!roles[str(n.type)] || !a || typeof a !== 'object' || Array.isArray(a) || Object.keys(a).some(k => !['label', 'hint', 'role'].includes(k)))
                throw Error('accessibility_invalid');
            for (const k of ['label', 'hint'])
                if (a[k] !== undefined && (typeof a[k] !== 'string' || !String(a[k]).trim() || String(a[k]).length > 1000))
                    throw Error('accessibility_invalid');
            if (a.role !== undefined && (typeof a.role !== 'string' || !roles[str(n.type)].includes(a.role)))
                throw Error('accessibility_invalid');
        }
        if (['course-picker', 'course-list'].includes(str(n.type)) && !m.permissions.includes('timetable.read'))
            throw Error('unsupported_permission');
        if (['photo-grid', 'photo-import', 'photo-capture'].includes(str(n.type))) {
            if (!m.permissions.includes('photos.user') || (n.type === 'photo-capture' && !m.permissions.includes('camera.use')))
                throw Error('unsupported_permission');
            if (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)))
                throw Error('field_key_invalid');
            if (n.arguments !== undefined) {
                const args = n.arguments;
                if (!args || Array.isArray(args) || Object.keys(args).some(k => k !== 'course') || !/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(args.course)))
                    throw Error('action_field_invalid');
            }
        }
        if (n.type === 'board-camera' && !m.permissions.includes('board.camera'))
            throw Error('unsupported_permission');
        if (n.type === 'media' && (!m.permissions.includes('media.remote') || !['image', 'video', 'audio'].includes(str(n.kind))))
            throw Error('unsupported_permission');
        if (n.type === 'browser' && !m.permissions.includes('browser.open'))
            throw Error('unsupported_permission');
        if (n.type === 'file' && !m.permissions.includes('files.user'))
            throw Error('unsupported_permission');
        if (n.type === 'campus' && (!Object.hasOwn(campusQueries, str(n.query)) || !m.permissions.includes(campusQueries[str(n.query)])))
            throw Error('unsupported_query');
        for (const key of ['text', 'label', 'key', 'action', 'equals', 'url'])
            if (n[key] !== undefined && typeof n[key] !== 'string')
                throw Error('layout_invalid');
        if (['text', 'label', 'markdown', 'code', 'caption', 'badge', 'icon', 'heading', 'share-text', 'copy-text', 'empty-state', 'error-state'].includes(str(n.type)) && typeof n.text !== 'string')
            throw Error('layout_invalid');
        if (['text', 'label', 'markdown', 'code', 'caption', 'badge', 'heading', 'share-text', 'copy-text', 'empty-state', 'error-state'].includes(str(n.type)) && (str(n.text).length > 6000))
            throw Error('layout_invalid');
        if (n.type === 'icon' && (!['book', 'calendar', 'bus', 'check', 'clock', 'info', 'map', 'person', 'photo', 'plus', 'search', 'edit', 'list', 'bell'].includes(str(n.text)) || !str(n.label).trim() || str(n.label).length > 120))
            throw Error('layout_invalid');
        if (['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'button', 'select', 'multi-select', 'checkbox', 'radio', 'stepper', 'link', 'link-button', 'date', 'file', 'browser', 'media', 'board-camera', 'share-text', 'copy-text', 'course-picker', 'photo-grid', 'photo-import', 'photo-capture', 'page', 'disclosure', 'course-list', 'number', 'slider', 'loading', 'empty-state', 'error-state'].includes(str(n.type)) && !str(n.label).trim())
            throw Error('layout_invalid');
        if (str(n.text).length > 4000 || str(n.label).length > 120)
            throw Error('text_too_long');
        if (['field', 'text-area', 'secure-field', 'search-field', 'toggle', 'select', 'multi-select', 'checkbox', 'radio', 'stepper', 'date', 'file', 'course-picker', 'course-list', 'number', 'slider'].includes(str(n.type))) {
            if (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)) || ids.has(str(n.key)))
                throw Error('field_key_invalid');
            ids.add(str(n.key));
            fields.set(str(n.key), str(n.type));
        }
        if (['select', 'multi-select'].includes(str(n.type)) && (!Array.isArray(n.options) || n.options.length < 1 || n.options.length > 30 || new Set(n.options).size !== n.options.length || n.options.some(o => typeof o !== 'string' || !o.trim() || o.length > 120)))
            throw Error('layout_invalid');
        if (n.type === 'when' && (!/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(n.key)) || typeof n.equals !== 'string' || n.equals.length > 4000))
            throw Error('layout_invalid');
        if (['link', 'link-button', 'browser', 'media'].includes(str(n.type))) {
            try {
                const u = new URL(str(n.url));
                if (u.protocol !== 'https:' || u.username || u.password || str(n.url).length > 2000)
                    throw Error();
            }
            catch {
                throw Error('action_unsupported');
            }
        }
        if (['button', 'icon-button'].includes(str(n.type)) && !['save', 'reset', 'todo.create', 'state.set', 'state.increment', 'runtime.event'].includes(str(n.action)))
            throw Error('action_unsupported');
        if (['state.set', 'state.increment'].includes(str(n.action))) {
            const args = n.arguments;
            const valueKey = n.action === 'state.set' ? 'value' : 'amount';
            if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some(k => !['field', valueKey].includes(k)) || !/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(args.field)) || typeof args[valueKey] !== 'string' || String(args[valueKey]).length > 4000)
                throw Error('action_field_invalid');
            if (n.action === 'state.increment' && (!Number.isFinite(Number(args.amount)) || Math.abs(Number(args.amount)) > 1e9))
                throw Error('action_field_invalid');
            stateActions.push({ ...args, action: n.action });
        }
        if (n.action === 'runtime.event') {
            if (!m.runtime || !['button', 'icon-button'].includes(str(n.type)) || !n.arguments || Object.keys(n.arguments).some(key => key !== 'event') || !/^\d{1,6}$/.test(str(n.arguments.event)))
                throw Error('action_unsupported');
        }
        if (n.action === 'todo.create') {
            if (!m.permissions.includes('todos.write'))
                throw Error('unsupported_permission');
            const args = n.arguments;
            if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).some(k => !['title', 'detail', 'deadline', 'notification'].includes(k)) || Object.values(args).some(v => !/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(String(v))) || !['title', 'detail'].every(k => /^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(str(args[k]))))
                throw Error('action_unsupported');
            todoActions.push(args);
        }
        if (n.type === 'button' && n.action === 'save' && !m.permissions.includes('cloud.storage'))
            throw Error('unsupported_permission');
        if (n.children !== undefined) {
            if (!Array.isArray(n.children) || !['section', 'column', 'row', 'zstack', 'scroll', 'horizontal-scroll', 'when', 'page', 'grid', 'footer', 'disclosure', 'course-list', 'data-list', 'card', 'group', 'container', 'safe-area'].includes(str(n.type)))
                throw Error('children_invalid');
            n.children.forEach(child => visit(child, depth + 1, str(n.type)));
        }
    }
    if (!Array.isArray(m.content) || !m.content.length)
        throw Error('layout_invalid');
    m.content.forEach(node => visit(node, 0));
    for (const args of stateActions) {
        const type = fields.get(str(args.field));
        if (!type || type === 'file')
            throw Error('action_field_invalid');
        if (args.action === 'state.increment' && !['number', 'slider', 'stepper'].includes(type))
            throw Error('action_field_invalid');
    }
    for (const args of todoActions) {
        for (const key of ['title', 'detail'])
            if (fields.get(str(args[key])) !== 'field')
                throw Error('action_field_invalid');
        for (const key of ['deadline', 'notification'])
            if (args[key] !== undefined && fields.get(str(args[key])) !== 'date')
                throw Error('action_field_invalid');
    }
    function checkPhotoRefs(nodes) { for (const n of nodes) {
        if (['photo-grid', 'photo-import', 'photo-capture'].includes(str(n.type)) && n.arguments) {
            if (!['course-picker', 'course-list'].includes(fields.get(str(n.arguments.course)) ?? ''))
                throw Error('action_field_invalid');
        }
        if (Array.isArray(n.children))
            checkPhotoRefs(n.children);
    } }
    checkPhotoRefs(m.content);
    if (JSON.stringify({ ...m, runtime: undefined }).length > 60000)
        throw Error('manifest_too_large');
}
