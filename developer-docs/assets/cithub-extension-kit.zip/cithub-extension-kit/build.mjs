// Run only the developer's own source. Never build an untrusted extension project.
import { execFileSync } from 'node:child_process';
import { mkdtemp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from 'typescript';
import { build } from 'esbuild';
import { readProgramMetadata } from './program-build.mjs';

const sourceDirectory = import.meta.dirname;
const packagedKit = path.basename(sourceDirectory) !== 'kit';
const root = packagedKit ? sourceDirectory : path.resolve(sourceDirectory, '..');
const { validateExtension } = await import(packagedKit
  ? new URL('./validator.mjs', import.meta.url).href
  : new URL('../runtime/validator.mjs', import.meta.url).href);
const input = process.argv[2] || 'examples/class-preparation.ts';
const entry = path.resolve(root, input);
if (!entry.startsWith(root + path.sep) || !entry.endsWith('.ts')) {
  throw Error('Choose a TypeScript file inside this project.');
}

const output = await mkdtemp(path.join(tmpdir(), 'cit-extension-build-'));
const tsc = path.join(root, 'node_modules/typescript/bin/tsc');
execFileSync(process.execPath, [
  tsc, entry, '--target', 'ES2022', '--module', 'ES2022', '--moduleResolution', 'bundler',
  '--strict', '--skipLibCheck', '--rootDir', root, '--outDir', output
], { stdio: 'inherit' });
await writeFile(path.join(output, 'package.json'), '{"type":"module"}');

async function fixImports(directory) {
  for (const item of await readdir(directory, { withFileTypes: true })) {
    const file = path.join(directory, item.name);
    if (item.isDirectory()) await fixImports(file);
    else if (file.endsWith('.js')) {
      const source = await readFile(file, 'utf8');
      const fixed = source.replace(/(from\s+['"])(\.\.?\/[^'"]+)(['"])/g,
        (_match, before, specifier, after) => before + (specifier.endsWith('.js') ? specifier : `${specifier}.js`) + after);
      await writeFile(file, fixed);
    }
  }
}
await fixImports(output);

const compiled = path.join(output, path.relative(root, entry).replace(/\.ts$/, '.js'));
const source = await readFile(entry, 'utf8');
const programMetadata = readProgramMetadata(ts, source, entry);
let manifest = programMetadata ?? (await import(pathToFileURL(compiled))).default;
if (!manifest || typeof manifest !== 'object') throw Error('The source must default-export an extension manifest.');
const needsMultilineInput = /\b(?:ui|interactive)\s*\.\s*textArea\s*\(/.test(source) || JSON.stringify(manifest.content || []).includes('"type":"text-area"');
if (needsMultilineInput) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 23);
if (manifest.permissions?.includes('location.use') || /\blocation\s*\.\s*current\s*\(/.test(source)) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 24);
if (manifest.permissions?.includes('network.status') || /\bnetwork\s*\.\s*status\s*\(/.test(source)) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 25);
if (/\b(?:network\s*\.\s*onChange|app\s*\.\s*onNetworkChange)\s*\(/.test(source) || /network\.(?:watch|unwatch)/.test(source)) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 28);
if (/\bui\s*\.\s*(?:zstack|spacer)\s*\(/.test(source) || /"type":"(?:zstack|spacer)"/.test(JSON.stringify(manifest.content || []))) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 26);
if (/\bui\s*\.\s*styled\s*\(/.test(source) && /\b(?:weight|lineLimit|selectable)\s*:/.test(source) || /"(?:weight|lineLimit|selectable)":/.test(JSON.stringify(manifest.content || []))) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 27);
const needsScrollableUI = /\bui\s*\.\s*(?:scroll|horizontalScroll)\s*\(/.test(source) || /"type":"(?:scroll|horizontal-scroll)"/.test(JSON.stringify(manifest.content || []));
if (needsScrollableUI) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 29);
const needsFileTransfer = /\bfiles\s*\.\s*(?:copy|move)\s*\(/.test(source);
if (needsFileTransfer) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 30);
const needsServicesList = /\bcit\s*\.\s*services\s*\.\s*list\s*\(/.test(source);
if (needsServicesList) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 31);
if (/\binteractive\s*\.\s*select\s*\(/.test(source)) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 32);
if (/\binteractive\s*\.\s*searchField\s*\(/.test(source) || JSON.stringify(manifest.content || []).includes('"type":"search-field"')) manifest.minimumHostAPI = Math.max(Number(manifest.minimumHostAPI) || 1, 46);

if (programMetadata || manifest.program) {
  const result = await build({
    stdin: {
      contents: `import program from ${JSON.stringify(entry)};import {mountProgram} from ${JSON.stringify(path.join(root, 'sdk/program.ts'))};mountProgram(program);`,
      resolveDir: root
    },
    bundle: true, write: false, format: 'esm', platform: 'neutral', target: 'es2022', minify: true
  });
  const { program, ...metadata } = manifest;
  const permissions = Array.isArray(metadata.permissions) ? metadata.permissions : [];
  const needsStructuredTimetable = /\bcit\s*\.\s*timetable\s*\.\s*(?:periods|freePeriods)\s*\(|\bcampus\s*\.\s*periods\s*\(|['"]timetable\.periods['"]/.test(source);
  const needsTodoCompletion = /\bcit\s*\.\s*todo\s*\.\s*(?:complete|uncomplete)\s*\(/.test(source);
  const needsCloudUser = /\bcloudUser\s*\./.test(source);
  const needsServicesList = /\bcit\s*\.\s*services\s*\.\s*list\s*\(/.test(source);
  if (needsCloudUser && !permissions.includes('cloud.storage')) throw Error('cloudUser requires the cloud.storage permission');
  const minimumHostAPI = Math.max(
    9, Number(metadata.minimumHostAPI) || 1,
    permissions.some(value => ['courseNotes.read', 'courseNotes.write', 'network.fetch'].includes(value)) ? 10 : 1,
    permissions.includes('files.storage') ? 11 : 1,
    permissions.includes('files.selection.read') ? 12 : 1,
    permissions.some(value => ['clipboard.read', 'clipboard.write'].includes(value)) ? 13 : 1,
    permissions.includes('settings.open') ? 14 : 1,
    permissions.includes('notifications.schedule') ? 15 : 1,
    permissions.includes('calendar.read') ? 18 : 1,
    permissions.includes('bus.read') ? 19 : 1,
    permissions.includes('cafeteria.read') ? 20 : 1,
    needsCloudUser ? 21 : 1,
    permissions.some(value => ['timetable.read', 'assignments.read'].includes(value)) ? 16 : 1,
    needsStructuredTimetable ? 16 : 1,
    needsTodoCompletion ? 17 : 1,
    needsMultilineInput ? 23 : 1,
    permissions.includes('location.use') ? 24 : 1,
    permissions.includes('network.status') ? 25 : 1,
    /\b(?:network\s*\.\s*onChange|app\s*\.\s*onNetworkChange)\s*\(/.test(source) || /network\.(?:watch|unwatch)/.test(source) ? 28 : 1,
    needsScrollableUI ? 29 : 1,
    needsFileTransfer ? 30 : 1,
    needsServicesList ? 31 : 1,
    /\binteractive\s*\.\s*searchField\s*\(/.test(source) ? 46 : 1
  );
  manifest = {
    ...metadata,
    minimumHostAPI,
    runtime: { engine: 'quickjs-v1', code: `;(async()=>{${result.outputFiles[0].text}})().catch(error=>{globalThis.__citFailure=String(error?.message||error)})` }
  };
}

validateExtension(manifest);
const destination = path.join(root, 'dist');
await mkdir(destination, { recursive: true });
const file = path.join(destination, path.basename(entry, '.ts') + '.json');
await writeFile(file, JSON.stringify({ manifest, source }, null, 2));
console.log(file);
