// Both the in-repository builder and the downloadable kit use these requirements.
const ui58 = /\b(?:navigation|list|field)\s*\.|\bui\s*\.\s*(?:textField|textArea|secureField|toggle|date|button|searchField|stepper|checkbox|radio|multiSelect|time|dateTime|dateRange|filePicker|photoPicker|iconButton|alert|confirm|prompt|actionSheet|toast|banner|menu|contextMenu|swipeActions|toolbar|floatingButton|lazyGrid|list|lazyList|sectionedList)\s*\(/;
const newNodes = new Set(['canvas','presentation','menu','context-menu','swipe-actions','toolbar','floating-button','lazy-list','lazy-grid']);
const rules = [
  [/\b(?:background|backgroundTasks)\s*\.\s*(?:register|unregister)\s*\(/,71,['server.functions']],
  [/\bsearch\s*\.\s*(?:registerItems|removeItems)\s*\(/,66,['extensions.read']],
  [/\bhost\s*\.\s*(?:registerShortcut|registerAction)\s*\(/,67,['host.navigate']],
  [/\bwidget\s*\.\s*(?:define|reload)\s*\(/,68],
  [/\bshortcuts\s*\.\s*register\s*\(/,69,['host.navigate']],
  [/\bpush\s*\.\s*sendToCurrentUser\s*\(/,78,['notifications.schedule']],
  [/\bauth\s*\.\s*(?:oauth2|openIDConnect)\s*\(/,73,['browser.open','network.fetch']],
  [/\bauth\s*\.\s*refresh\s*\(/,73,['network.fetch']],
  [/\bauth\s*\.\s*(?:logout|tokenStatus)\s*\(/,73],
  [/\bserver\s*\.\s*cron\s*\.\s*status\s*\(/,72,['server.functions']],
  [/\bserver\s*\.\s*cron\s*\.(?:register|unregister)\s*\(/,71,['server.functions']],
  [/\brealtime\s*\.\s*(?:publish|subscribe)\s*\(/,70,['cloud.shared']],
  [/\bbackground\s*\.\s*status\s*\(/,68],
  [/\bserver\s*\.\s*function\s*\(/,69,['server.functions']],
  [/\bcit\s*\.\s*campus\s*\.\s*(?:facilities|buildings|rooms|room|search|roomAvailability)\s*\(/,65,['timetable.read']],
  [/\bcit\s*\.\s*cafeteria\s*\.\s*hours\s*\(/,65,['cafeteria.read']],
  [/\b(?:scanner\s*\.\s*document|image\s*\.\s*scanDocument)\s*\(/,64,['camera.use','files.storage']],
  [/\bnavigation\s*\.\s*openExtension\s*\(/,62,['extensions.read','host.navigate']],
  [/\bnavigation\s*\.\s*(?:openHostPage|openExtension)\s*\(/,62,['host.navigate']],
  [/\bcit\s*\.\s*services\s*\.\s*open\s*\(/,62,['host.navigate']],
  [/\bcit\s*\.\s*cafeteria\s*\.\s*openCamera\s*\(/,62,['host.navigate','cafeteria.read']],
  [/\bcit\s*\.\s*user\s*\.\s*displayName\s*\(/,63,['profile.read']],
  [/\bextensions\s*\.\s*isInstalled\s*\(|\blink\s*\.\s*create\s*\(/,62,['extensions.read']],
  [/\bextensions\s*\.\s*(?:open|request)\s*\(|\blink\s*\.\s*open\s*\(/,62,['extensions.read','host.navigate']],
  [/\bcamera\s*\.\s*capturePhoto\s*\(/,61,['camera.use','files.selection.read']],
  [/\bcamera\s*\.\s*captureVideo\s*\(/,61,['camera.use','microphone.use','files.selection.read']],
  [/\baudio\s*\.\s*(?:record|stopRecording)\s*\(/,61,['microphone.use','files.selection.read']],
  [/\bcode\s*\.\s*generateQR\s*\(/,61,['files.storage']],
  [/\bphotos\s*\.\s*save\s*\(/,61,['photos.user','files.selection.read']],
  [/\b(?:cloud\s*\.\s*shared|groups)\s*\./,60,['cloud.shared']],
  [/\bsensors\s*\.\s*(?:accelerometer|gyroscope|magnetometer|orientation)\s*\(/,60,['sensors.motion']],
  [/\bmap\s*\.\s*openDirections\s*\(/,60,['browser.open']],
  [/\bmap\s*\.\s*(?:view|marker|polyline|circle|fitBounds)\s*\(/,67],
  [/\bcit\s*\.\s*settings\s*\.\s*language\s*\(/,60,['settings.read']],
  [/\b(?:console\s*\.\s*(?:log|warn|error)|debug\s*\.\s*inspect)\s*\(/,59],
  [/\b(?:audio\s*\.\s*(?:play|pause|stop|duration|position)|video\s*\.\s*(?:play|pause))\s*\(/,59,['files.selection.read']],
  [/\bserver\s*\.\s*(?:kv|db)\s*\./, 59, ['cloud.storage']],
  [/\bserver\s*\.\s*files\s*\./, 80, ['cloud.storage']],
  [/\bpdf\s*\.\s*(?:create|export)\s*\(/,59,['files.storage']],
  [/\b(?:pdf|video)\s*\.\s*thumbnail\s*\(/,59,['files.storage','files.selection.read']],
  [/\b(?:camera\s*\.\s*(?:scanQRCode|scanBarcode)|code\s*\.\s*(?:scanQR|scanBarcode))\s*\(/,59,['camera.use']],
  [/\binteractive\s*\.\s*select\s*\(/, 32],
  [/\binteractive\s*\.\s*multiSelect\s*\(/, 34],
  [/\binteractive\s*\.\s*dateTime\s*\(/, 35],
  [/\binteractive\s*\.\s*dateRange\s*\(/, 36],
  [/\binteractive\s*\.\s*(?:stepper|checkbox|radio)\s*\(/, 37],
  [/\bui\s*\.\s*progress\s*\(/, 38],
  [/\bui\s*\.\s*(?:loading|emptyState|errorState)\s*\(/, 39],
  [/\bui\s*\.\s*(?:card|group|container)\s*\(/, 40],
  [/\banimation\s*\.\s*(?:animate|spring|transition)\s*\(/, 41],
  [/\bui\s*\.\s*barChart\s*\(/, 42],
  [/\bui\s*\.\s*(?:safeArea|frame)\s*\(/, 43],
  [/\binteractive\s*\.\s*iconButton\s*\(/, 45],
  [/\bshare\s*\.\s*(?:text|url|items)\s*\(/, 52],
  [/\bshare\s*\.\s*file\s*\(/, 53, ['files.user','files.selection.read']],
  [/\bfiles\s*\.\s*transformImage\s*\(/, 54, ['files.storage','files.selection.read']],
  [/\bnetwork\s*\.\s*(?:uploadFile|downloadFile|upload|download)\s*\([\s\S]{0,2000}\bonProgress\b/, 55, ['network.fetch','files.storage']],
  [/\bbrowser\s*\.\s*openExternal\s*\(/, 56, ['browser.open']],
  [/\banalytics\s*\.\s*event\s*\(/, 57, ['analytics.collect']],
  [ui58, 58],
  [/\b(?:canvas|chart)\s*\./, 58],
  [/\bcamera\s*\.\s*available\s*\(/,58],
  [/\bcamera\s*\.\s*permissions\s*\(/,58,['camera.use']],
  [/\bphotos\s*\.\s*(?:pick|pickMultiple)\s*\(/,58,['files.user','files.selection.read']],
  [/\b(?:photos|video)\s*\.\s*info\s*\(|\bpdf\s*\.\s*pageCount\s*\(/,58,['files.selection.read']],
  [/\bpdf\s*\.\s*(?:open|share)\s*\(|\bshare\s*\.\s*image\s*\(/,58,['files.user','files.selection.read']],
  [/\bimage\s*\.\s*(?:resize|crop|rotate|flip|compress|convert|thumbnail|removeMetadata)\s*\(/, 58, ['files.storage']],
  [/\b(?:browser|webView)\s*\.\s*open\s*\(/, 58, ['browser.open']],
  [/\bcloud\s*\.\s*user\s*\./, 58, ['cloud.storage']],
  [/\bconnectivity\s*\./, 58, ['network.status']],
  [/\bnetwork\s*\.\s*(?:upload|download)\s*\(/, 58, ['network.fetch','files.storage']],
  [/\bui\s*\.\s*(?:filePicker|photoPicker)\s*\(/, 58, ['files.user']],
];
export function applySDKFeatures(manifest, source) {
  let minimumHostAPI = Number(manifest.minimumHostAPI) || 1;
  if (/\bdrag\s*\.\s*source\s*\(|\bdrop\s*\.\s*target\s*\(/.test(source)) minimumHostAPI = Math.max(minimumHostAPI, 66);
  for (const [pattern, version, permissions = []] of rules) {
    if (!pattern.test(source)) continue;
    if (permissions.some(permission => !manifest.permissions?.includes(permission)))
      throw Error(`API requires permissions: ${permissions.join(', ')}`);
    minimumHostAPI = Math.max(minimumHostAPI, version);
  }
  function visit(nodes) {
    for (const node of nodes || []) {
      if (node.type === 'campus' && node.query === 'cafeteria.hours') minimumHostAPI = Math.max(minimumHostAPI, 65);
      if (node.type === 'drag-source' || node.type === 'drop-target') minimumHostAPI = Math.max(minimumHostAPI, 66);
      if (['map-view','map-marker','map-polyline','map-circle','map-fit-bounds'].includes(node.type)) minimumHostAPI = Math.max(minimumHostAPI, 67);
      if (newNodes.has(node.type) || node.type === 'date' && node.arguments?.mode) minimumHostAPI = Math.max(minimumHostAPI, 58);
      if (node.children) visit(node.children);
    }
  }
  visit(manifest.content);
  // Infer the host floor from calls in the authored source, not retained
  // dispatch strings in the SDK barrel bundle (which includes unused helpers).
  if(manifest.permissions?.some(p=>['host.navigate','extensions.read'].includes(p)))minimumHostAPI=Math.max(minimumHostAPI,62);
  if (/\bon(?:LongPress|DoublePress)\b/.test(source)) minimumHostAPI = Math.max(minimumHostAPI, 79);
  const result = { ...manifest, minimumHostAPI };
  if (result.runtime && minimumHostAPI >= 58) result.runtime = { ...result.runtime, code: '/*__CIT_FEATURE_ui58__*/' + result.runtime.code };
  if (result.runtime && minimumHostAPI >= 59) result.runtime = { ...result.runtime, code: '/*__CIT_FEATURE_dataMedia59__*/' + result.runtime.code };
  if (result.runtime && minimumHostAPI >= 60) result.runtime={...result.runtime,code:'/*__CIT_FEATURE_native60__*/'+result.runtime.code};
  if (result.runtime && minimumHostAPI >= 61)result.runtime={...result.runtime,code:'/*__CIT_FEATURE_media61__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=62)result.runtime={...result.runtime,code:'/*__CIT_FEATURE_integration62__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=63)result.runtime={...result.runtime,code:'/*__CIT_FEATURE_profile63__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=66)result.runtime={...result.runtime,code:'/*__CIT_FEATURE_drag66__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=67)result.runtime={...result.runtime,code:'/*__CIT_FEATURE_map67__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=70&&/\brealtime\s*\.\s*(?:publish|subscribe)\s*\(/.test(source))result.runtime={...result.runtime,code:'/*__CIT_FEATURE_realtime70__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=71&&/\bserver\s*\.\s*cron\s*\.(?:register|unregister)\s*\(/.test(source))result.runtime={...result.runtime,code:'/*__CIT_FEATURE_serverCron71__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=71&&/\b(?:background|backgroundTasks)\s*\.\s*(?:register|unregister)\s*\(/.test(source))result.runtime={...result.runtime,code:'/*__CIT_FEATURE_serverCron71__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=72&&/\bserver\s*\.\s*cron\s*\.\s*status\s*\(/.test(source))result.runtime={...result.runtime,code:'/*__CIT_FEATURE_serverCron72__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=73&&/\bauth\s*\.\s*(?:oauth2|openIDConnect|refresh|logout|tokenStatus)\s*\(/.test(source))result.runtime={...result.runtime,code:'/*__CIT_FEATURE_auth73__*/'+result.runtime.code};
  if(result.runtime&&minimumHostAPI>=80&&/\bserver\s*\.\s*files\s*\./.test(source))result.runtime={...result.runtime,code:'/*__CIT_FEATURE_serverFiles80__*/'+result.runtime.code};
  return result;
}
