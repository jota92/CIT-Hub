import {defineProgram,keyboard,state,interactive,ui} from '../sdk/index';
const text=state.create('');const result=state.create('入力後に閉じるボタンを押してください。');
export default defineProgram({name:'キーボード検証',version:'1.0.0',description:'入力欄のキーボードを閉じます。',permissions:[],render:()=>[
 ui.text(result.value),interactive.textField('input','入力',text),interactive.button('閉じる',async()=>{
  try{await keyboard.dismiss();result.set('closed');}catch(error){result.set(error instanceof Error?error.message:String(error));}
 }),interactive.button('入力を選択',async()=>{try{await keyboard.focus('input');result.set('focused');}catch(error){result.set(error instanceof Error?error.message:String(error));}}),
 interactive.button('存在しない入力',async()=>{try{await keyboard.focus('missing');result.set('unexpected');}catch(error){result.set(error instanceof Error?error.message:String(error));}})
]});
