import {defineProgram,interactive,permissions,state,ui} from '../sdk/index';
const result=state.create('ボタンを押すとカメラ許可を確認します。');
export default defineProgram({name:'許可要求検証',version:'1.0.0',description:'ユーザー操作に応じてカメラ許可を要求します。',permissions:['camera.use'],render:()=>[ui.text(result.value),interactive.button('許可を確認',async()=>{result.set(await permissions.request('camera.use'));})]});
