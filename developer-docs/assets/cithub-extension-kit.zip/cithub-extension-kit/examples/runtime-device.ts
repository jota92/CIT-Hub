import { defineProgram, device, ui } from '../sdk/index';
const info=await device.info();
export default defineProgram({
  name:'端末情報検証',version:'1.0.0',description:'識別子を含まない端末の表示情報を確認します。',permissions:[],
  render:()=>[ui.text(JSON.stringify(info))]
});
