import { defineProgram, files, interactive, state, ui } from '../sdk';

const selectedName = state.create('');
const result = state.create('ファイルを選択してください');

export default defineProgram({
  name: '選択ファイルの確認',
  version: '1.0.0',
  description: '利用者が選んだファイルの情報と先頭チャンクを読み取る例',
  permissions: ['files.user', 'files.selection.read'],
  render: () => [ui.page('選択ファイル', [
    interactive.file('document', 'ファイルを選ぶ', selectedName),
    ui.text(result.value),
    interactive.button('先頭部分を読む', async () => {
      const info = await files.selectedInfo('document');
      if (!info) {
        result.set('ファイルが選択されていません');
        return;
      }
      const chunk = await files.readSelected('document', 0);
      const preview = chunk ? Array.from(chunk.bytes.slice(0, 16)).join(', ') : '';
      result.set(`${info.name} · ${info.mimeType} · ${info.size} bytes · ${preview}`);
    })
  ])]
});
