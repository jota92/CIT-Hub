import { defineProgram, interactive, network, state, ui } from '../sdk';

const status = state.create('ダウンロードを開始できます。');

export default defineProgram({
  name: '転送進捗の例',
  version: '1.0.0',
  description: '許可したHTTPSホストからファイルを取得し、転送状況を表示します。',
  permissions: ['network.fetch', 'files.storage'],
  network: ['downloads.example.org'],
  render: () => [
    ui.heading('資料をダウンロード'),
    ui.text(status.value),
    interactive.button('PDFを取得', async () => {
      status.set('接続しています…');
      try {
        const result = await network.downloadFile(
          'https://downloads.example.org/handout.pdf',
          'handout.pdf',
          {
            onProgress: ({ loadedBytes, totalBytes, fraction }) => {
              status.set(totalBytes === null
                ? `${loadedBytes} bytes を受信中`
                : `${Math.round((fraction ?? 0) * 100)}% (${loadedBytes}/${totalBytes} bytes)`);
            }
          }
        );
        status.set(result.ok ? `保存しました: ${result.file.name}` : `HTTP ${result.status}`);
      } catch (error) {
        status.set(error instanceof Error ? error.message : String(error));
      }
    })
  ]
});
