import { defineProgram, interactive, state, ui } from '../sdk/index';

const campus = state.create('新習志野');

export default defineProgram({
  name: 'Campus selector',
  version: '1.0.0',
  description: 'Interactive native selection example',
  permissions: [],
  render: () => [
    ui.heading('キャンパスを選択'),
    interactive.select('campus', 'キャンパス', ['新習志野', '津田沼'], campus),
    ui.text(`選択中: ${campus.value}`),
    ui.when('campus', '津田沼', [ui.text('津田沼の情報を表示しています。')]),
    ui.when('campus', '新習志野', [ui.text('新習志野の情報を表示しています。')]),
  ],
});
