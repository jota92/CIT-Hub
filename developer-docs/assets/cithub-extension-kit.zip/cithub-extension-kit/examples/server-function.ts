import { defineProgram, server, state, ui } from '../sdk/index';

const result = state.create('サーバー関数は未実行です。');

export const serverFunctions = {
  add(input: { first: number; second: number }) {
    if (!Number.isFinite(input.first) || !Number.isFinite(input.second)) throw new Error('数値を入力してください。');
    return { total: input.first + input.second };
  }
};

export default defineProgram({
  name: 'Server function example',
  version: '1.0.0',
  description: '同梱された関数を隔離サーバーで実行します。',
  permissions: ['server.functions'],
  render: () => [
    ui.button('合計を計算', async () => {
      try {
        const value = await server.function<{ total: number }>('add', { first: 3, second: 4 });
        result.set(`合計: ${value.total}`);
      } catch (error) {
        result.set(error instanceof Error ? error.message : '計算できませんでした。');
      }
    }),
    ui.text(result.value)
  ]
});
