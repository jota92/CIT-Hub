import { defineExtension, ui } from '../sdk/index';
export default defineExtension({
  name: '板書カメラ', version: '1.2.0',
  description: '授業一覧から授業別の板書写真を開き、撮影・取り込み・拡大・保存・共有・削除できます。',
  permissions: ['timetable.read', 'photos.user', 'camera.use'],
  content: [
    ui.heading('板書カメラ'),
    ui.courseList('course', '受講中の授業', [
      ui.photoGrid('notes', '保存済み写真', 'course'),
      ui.footer([
        ui.importPhotos('notes', '取り込む', 'course'),
        ui.capturePhoto('notes', '撮影', 'course'),
      ]),
    ]),
  ],
});
