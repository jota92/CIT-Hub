import { defineProgram,ui,state,camera,audio,photos,code,files,capabilities,type PickedFileInfo } from '../sdk/index';

const selected=state.create<PickedFileInfo|null>(null);
const message=state.create('操作を選んでください。データは端末内に保存します。');
async function run(operation:()=>Promise<unknown>){
  try{const result=await operation();message.set(JSON.stringify(result,null,2)??'完了しました。');}
  catch(error){message.set(error instanceof Error?error.message:'処理できませんでした。');}
}
async function select(operation:()=>Promise<PickedFileInfo|null>){
  const result=await operation();if(result)selected.set(result);return result;
}
export default defineProgram({
  name:'撮影と録音の例',version:'1.0.0',description:'ネイティブ撮影・録音画面、写真保存、QR生成を使用する例です。',
  permissions:['camera.use','microphone.use','photos.user','files.selection.read','files.storage'],
  render:()=>[
    ui.text('撮影と録音は操作中のみ。Macでは撮影ボタンを表示しません。'),
    ...(capabilities.has('camera.capturePhoto')?[ui.button('写真を撮影',()=>run(()=>select(camera.capturePhoto)))]:[]),
    ...(capabilities.has('camera.captureVideo')?[ui.button('動画を撮影（15秒まで）',()=>run(()=>select(()=>camera.captureVideo(15))))]:[]),
    ...(capabilities.has('audio.record')?[ui.button('音声を録音（60秒まで）',()=>run(()=>select(()=>audio.record(60))))]:[]),
    ...(selected.value?.mimeType.startsWith('image/')?[ui.button('写真アプリに保存',()=>run(()=>photos.save(selected.value!.key)))]:[]),
    ui.button('QRコードを生成',()=>run(()=>code.generateQR('https://cithub.app/','qr.png'))),
    ui.button('生成したQRを書き出す',()=>run(()=>files.export('qr.png'))),
    ui.code(message.value)
  ]
});
