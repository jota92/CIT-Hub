import { defineExtension, campus, ui } from '../sdk/index';

export default defineExtension({
  name: '授業準備チェック', version: '1.0.0',
  description: '次の授業と課題を確認し、準備内容に応じて入力画面を切り替えて保存します。',
  permissions: ['timetable.read', 'assignments.read', 'cloud.storage'],
  content: [
    ui.heading('次の授業に備える'),
    ui.data(campus.nextClass(), '次の授業'),
    ui.data(campus.dueSoon(), '期限が近い課題'),
    ui.divider(),
    ui.select('kind', '確認する内容', ['持ち物', '予習', '提出準備']),
    ui.when('kind', '持ち物', [ui.field('items', '持参するもの')]),
    ui.when('kind', '予習', [ui.field('study', '確認するページ・内容')]),
    ui.when('kind', '提出準備', [ui.field('submission', '提出前に確認すること')]),
    ui.toggle('done', '準備が完了した'),
    ui.button('保存する', 'save'),
    ui.link('CIT Hubの使い方', 'https://cit-hub.vercel.app/how.html'),
  ],
});
