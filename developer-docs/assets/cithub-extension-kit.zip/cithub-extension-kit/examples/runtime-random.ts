import {defineProgram, crypto, ui} from '../sdk/index';
const id=crypto.uuid();
const bytes=Array.from(crypto.randomBytes(32));
export default defineProgram({name:'乱数検証',version:'1.0.0',description:'安全な乱数とUUIDを検証します。',permissions:[],render:()=>[ui.text(id),ui.text(JSON.stringify(bytes))]});
