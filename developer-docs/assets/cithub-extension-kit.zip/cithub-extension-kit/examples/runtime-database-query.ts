import {defineProgram,database,ui} from '../sdk/index';
await database.createTable('study');
await database.transaction(tx=>{for(const row of tx.query('study'))tx.delete('study',row.id);tx.insert('study',{id:'a',minutes:30,date:'2026-10-01'});tx.insert('study',{id:'b',minutes:90,date:'2026-10-02'});tx.insert('study',{id:'c',minutes:120,date:'2026-10-03'});tx.insert('study',{id:'d',minutes:'999',date:null});});
const base=database.table('study');
const chosen=await base.where('minutes','>',60).orderBy('date','desc').limit(1).get();
const all=await base.get();
const empty=await base.limit(0).get();
export default defineProgram({name:'検索検証',version:'1.0.0',description:'データベースの条件検索を検証します。',permissions:[],render:()=>[ui.text(JSON.stringify({chosen,all,empty}))]});
