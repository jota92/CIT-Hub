import {defineProgram,cit,ui} from '../sdk/index';
const created=await cit.courseNotes.create('extension-test-course','initial');
if(!created)throw Error('Missing created note');
await cit.courseNotes.update(created.id,'updated','initial');
let conflict=false;
try{await cit.courseNotes.update(created.id,'stale','initial');}catch{conflict=true;}
const loaded=await cit.courseNotes.get(created.id);
if(!conflict||loaded?.content!=='updated')throw Error('Conflict protection failed');
await cit.courseNotes.delete(created.id,'updated');
if(await cit.courseNotes.get(created.id)!==null)throw Error('Deletion failed');
export default defineProgram({name:'授業メモ書き込み検証',version:'1.0.0',description:'テスト用メモの作成・更新・競合拒否・削除を確認します。',permissions:['courseNotes.read','courseNotes.write'],render:()=>[ui.text('PASS course note mutations')]});
