import { defineExtension, ui } from '../sdk/index';

export default defineExtension({
  name: '参考リンク',
  version: '1.0.0',
  description: '授業に関連する公式ページを安全に開くサンプルです。',
  permissions: [],
  content: [
    { type: 'heading', text: '参考リンク' },
    { type: 'text', text: '必要な情報を公式サイトで確認できます。' },
    ui.linkButton('大学公式サイトを開く', 'https://www.it-chiba.ac.jp/')
  ]
});
