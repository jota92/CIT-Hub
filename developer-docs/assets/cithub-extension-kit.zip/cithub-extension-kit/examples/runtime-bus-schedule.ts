import { defineProgram, cit, ui, state } from '../sdk/index';

const at = new Date('2026-04-13T00:00:00.000Z');
const [status, stops, departures, next, range] = await Promise.all([
  cit.bus.serviceStatus(at),
  cit.bus.stops(),
  cit.bus.timetable(at),
  cit.bus.next(undefined, undefined, at),
  cit.bus.between(at, new Date('2026-04-14T00:00:00.000Z'))
]);
const output = state.create(JSON.stringify({ status, stops, departures, next, range }, null, 2));

export default defineProgram({
  name: 'バス時刻表APIサンプル',
  version: '1.0.0',
  description: '端末内に保存されたバス時刻表から路線と次便を表示します。',
  permissions: ['bus.read'],
  render: () => [ui.heading('バス時刻表'), ui.text(output.value)]
});
