import { defineProgram, interactive, state, ui } from '../sdk/index';

const selected = state.create<string[]>(['講義資料']);
const options = ['講義資料', '実験器具', 'レポート用紙'];

export default defineProgram({
  name: '持ち物チェック',
  version: '1.0.0',
  description: '授業に持っていくものを複数選択して確認します。',
  permissions: [],
  render: () => [
    ui.heading('今日の持ち物'),
    interactive.multiSelect('items', '持っていくもの', options, selected),
    ui.text(selected.value.length ? `選択中: ${selected.value.join('、')}` : 'まだ選択されていません。'),
  ],
});
