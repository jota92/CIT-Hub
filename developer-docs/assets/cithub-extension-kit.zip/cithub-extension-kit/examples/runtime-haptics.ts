import { defineProgram, interactive, haptics, state, ui } from '../sdk/index';
const result=state.create('ボタンを押すと触覚フィードバックを実行します。');
export default defineProgram({
  name:'触覚フィードバック検証',version:'1.0.0',
  description:'端末の触覚フィードバックを検証します。',permissions:[],
  render:()=>[
    ui.text(result.value),
    ...(['light','medium','heavy','success','warning','error'] as const).map(kind=>
      interactive.button(kind,async()=>{
        try { await haptics[kind]();result.set(kind+'を実行しました。'); }
        catch(error) { result.set(error instanceof Error?error.message:String(error)); }
      }))
  ]
});
