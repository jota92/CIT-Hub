import { defineProgram, app, storage, ui } from '../sdk/index';
const environment=app.environment();
const saved=await storage.get('initializationTest');
export default defineProgram({name:'初期化テスト',version:'1.0.0',description:'実行時の初期化とトップレベルawaitを確認します。',permissions:[],render:()=>[ui.text(environment),ui.text(saved===null?'未保存':String(saved))]});
