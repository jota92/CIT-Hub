import { defineProgram, groups, realtime, shared, ui } from '../sdk/index';

const group = '0123456789abcdef0123456789abcdef';
const invitation = 'abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789';
let stopRealtime: (() => void) | undefined;

export default defineProgram({
  name: '共有グループAPIの実行例',
  version: '1.0.0',
  description: 'グループ、共有値、リアルタイムAPIを呼び出す検証用プログラムです。',
  permissions: ['cloud.shared'],
  render: () => [
    ui.button('グループ一覧', () => groups.list()),
    ui.button('グループ作成', () => groups.create('演習グループ')),
    ui.button('招待で参加', () => groups.join(invitation)),
    ui.button('グループを退出', () => groups.leave(group)),
    ui.button('メンバー一覧', () => groups.members(group)),
    ui.button('招待を作成', () => groups.invite(group, { expiresInHours: 24, maxUses: 3 })),
    ui.button('共有値を作成', () => shared.create(group, 'sharedNote', { text: 'hello' })),
    ui.button('共有値を読む', () => shared.read(group, 'sharedNote')),
    ui.button('共有値を更新', () => shared.update(group, 'sharedNote', { text: 'updated' }, 1)),
    ui.button('共有値を削除', () => shared.delete(group, 'sharedNote', 2)),
    ui.button('イベントを配信', () => realtime.publish(group, 'updates', { ready: true })),
    ui.button('イベントを購読', () => {
      stopRealtime?.();
      stopRealtime = realtime.subscribe(group, 'updates', message => console.log(message));
    }),
    ui.button('購読を停止', () => {
      stopRealtime?.();
      stopRealtime = undefined;
    })
  ]
});
