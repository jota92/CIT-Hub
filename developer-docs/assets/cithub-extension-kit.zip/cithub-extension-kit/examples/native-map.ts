import { defineProgram, map, ui } from '../sdk/index';

export default defineProgram({
  name: 'キャンパスマップ',
  version: '1.0.0',
  description: '地図に位置・範囲・経路を表示します。',
  permissions: ['browser.open'],
  render: () => [
    map.view({
      center: { latitude: 35.6812, longitude: 139.7671 },
      zoom: 14,
      height: 320
    }, [
      map.marker({ latitude: 35.6812, longitude: 139.7671 }, { title: '駅', subtitle: '出発点' }),
      map.polyline([
        { latitude: 35.6812, longitude: 139.7671 },
        { latitude: 35.6840, longitude: 139.7730 }
      ], { tone: 'accent', width: 5 }),
      map.circle({ latitude: 35.6812, longitude: 139.7671 }, 500, { tone: 'secondary' }),
      map.fitBounds([
        { latitude: 35.6790, longitude: 139.7650 },
        { latitude: 35.6860, longitude: 139.7750 }
      ], 32)
    ]),
    ui.button('駅への経路を開く', () => map.openDirections(
      { latitude: 35.6913, longitude: 140.0207 },
      { name: '津田沼駅', mode: 'walking' }
    ))
  ]
});
