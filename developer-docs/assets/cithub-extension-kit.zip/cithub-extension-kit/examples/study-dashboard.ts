import { defineExtension, ui, actions } from '../sdk/index';
export default defineExtension({
  name: '学習メモ', version: '1.0.0',
  description: '学習時間の目標と進み具合を保存し、取得済みの課題を一覧で確認します。',
  permissions: ['cloud.storage', 'assignments.read'],
  content: [
    ui.heading('学習メモ'),
    ui.number('minutes', '学習時間（分）', 0, 480, 5),
    ui.slider('progress', '進み具合（%）', 0, 100, 5),
    ui.row([actions.increment('5分追加', 'minutes', 5), actions.setField('リセット', 'minutes', '0')]),
    ui.field('memo', 'メモ'),
    ui.shareText('メモを共有', '{{memo}}・学習時間 {{minutes}}分'),
    ui.button('保存', 'save'),
    ui.page('課題一覧', [
      ui.dataList('tasks', 'assignments.data', [
        ui.heading('{{item.title}}'),
        ui.text('{{item.course}}・期限 {{item.deadline}}'),
        ui.disclosure('詳細', [ui.copyText('課題名をコピー', '{{item.title}}')]),
        ui.divider(),
      ]),
    ]),
  ],
});
