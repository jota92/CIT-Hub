import {defineProgram,permissions,ui} from '../sdk/index';
const camera=await permissions.status('camera.use');
const files=await permissions.status('files.user');
const notes=await permissions.status('courseNotes.write');
export default defineProgram({name:'権限確認検証',version:'1.0.0',description:'宣言とOSの許可状態を区別します。',permissions:['camera.use','files.user'],render:()=>[ui.text(JSON.stringify({camera,files,notes}))]});
