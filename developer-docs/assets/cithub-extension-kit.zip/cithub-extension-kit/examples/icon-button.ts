import { defineProgram, interactive, state, ui } from '../sdk/index';

const count = state.create(0);

export default defineProgram({
  name: 'アイコン操作の例',
  version: '1.0.0',
  description: 'アクセシブルなネイティブアイコンボタンを使う例です。',
  permissions: [],
  render() {
    return [
      ui.heading('カウンター'),
      ui.label(`タップ回数: ${count.value}`),
      interactive.iconButton('plus', '回数を増やす', () => count.set(count.value + 1)),
    ];
  },
});
