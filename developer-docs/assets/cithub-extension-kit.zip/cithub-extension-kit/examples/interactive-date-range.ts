import { defineProgram, interactive, state, ui } from '../sdk/index';

const range = state.create<{start:number|null;end:number|null}>({start:null,end:null});

export default defineProgram({
  name: '期間入力',
  version: '1.0.0',
  description: '開始日時と終了日時を設定します。',
  permissions: [],
  render: () => [
    ui.heading('期間'),
    interactive.dateRange('range', '対象期間', range),
    ui.text(range.value.start === null ? '開始日時は未設定です' : `開始: ${range.value.start}`),
    ui.text(range.value.end === null ? '終了日時は未設定です' : `終了: ${range.value.end}`),
  ],
});
