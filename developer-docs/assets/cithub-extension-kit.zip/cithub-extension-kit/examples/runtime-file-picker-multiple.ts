import { defineProgram, files, interactive, state, ui } from '../sdk/index';

const message = state.create('画像を複数選択できます。');

export default defineProgram({
  name: '複数ファイル選択サンプル',
  version: '1.0.0',
  description: '選択したファイルの名前、種類、サイズを表示します。',
  permissions: ['files.user', 'files.selection.read'],
  render: () => [
    ui.heading('ファイルを複数選ぶ'),
    ui.text(message.value),
    interactive.button('画像を選択', async () => {
      try {
        const selected = await files.pickMultiple('image');
        message.set(selected?.map(file => `${file.name} (${file.mimeType}, ${file.size} bytes)`).join('\n') ?? '選択をキャンセルしました。');
      } catch (error) {
        message.set(error instanceof Error ? error.message : String(error));
      }
    })
  ]
});
