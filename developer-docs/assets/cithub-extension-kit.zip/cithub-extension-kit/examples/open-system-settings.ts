import { defineProgram, interactive, permissions, state, ui } from '../sdk';

const status = state.create('アプリの通知やカメラの許可を設定から変更できます。');

export default defineProgram({
  name: 'アプリ設定を開く',
  version: '1.0.0',
  description: '利用者がボタンを押したとき、CIT HubのOS設定画面を開きます。',
  permissions: ['settings.open'],
  render: () => [
    ui.heading('アプリの設定'),
    ui.text(status.value),
    interactive.button('OS設定を開く', async () => {
      await permissions.openSettings();
      status.set('OS設定を開きました。');
    })
  ]
});
