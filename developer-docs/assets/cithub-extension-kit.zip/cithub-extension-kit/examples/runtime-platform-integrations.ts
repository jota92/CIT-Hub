import { background, backgroundTasks, defineProgram, host, push, scanner, search, server, shortcuts, ui, widget } from '../sdk/index';

export default defineProgram({
  name: 'Platform API runtime integration tests',
  version: '1.0.0',
  description: 'Exercises the host platform APIs through the TypeScript SDK and sandbox runtime.',
  permissions: ['server.functions', 'extensions.read', 'host.navigate', 'timetable.read', 'notifications.schedule', 'camera.use', 'files.storage'],
  render: () => [
    ui.button('Register background task', async () => backgroundTasks.register({ id: 'runtimeTask', intervalMinutes: 30 })),
    ui.button('Read background status', async () => background.status()),
    ui.button('Register search items', async () => search.registerItems([{ id: 'course-1', title: 'Course', keywords: ['class'], route: 'course:course-1' }])),
    ui.button('Remove search items', async () => search.removeItems(['course-1'])),
    ui.button('Register host shortcut', async () => host.registerShortcut({ id: 'runtime-shortcut', title: 'Open timetable', route: 'page:timetable' })),
    ui.button('Register host action', async () => host.registerAction({ id: 'runtime-action', title: 'Open ToDo', route: 'page:todo' })),
    ui.button('Register widget', async () => widget.define({ id: 'runtime-widget', kind: 'small', title: 'Next class', fields: [{ key: 'course', label: 'Course', source: 'courses.next' }] })),
    ui.button('Reload widget', async () => widget.reload('runtime-widget')),
    ui.button('Register shortcut', async () => shortcuts.register({ id: 'runtime-quick-action', title: 'Open services', route: 'page:services' })),
    ui.button('Send self push', async () => push.sendToCurrentUser({ title: 'Reminder', body: 'A test notification.' })),
    ui.button('Scan document', async () => scanner.document({ name: 'runtime-scan.pdf', maxPages: 3 })),
    ui.button('Register cron job', async () => server.cron.register('scheduledJob', null, 3600))
  ]
});
