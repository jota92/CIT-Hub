import { defineProgram, interactive, notification, permissions, state, ui } from '../sdk/index';

const status = state.create('未確認');

export default defineProgram({
  name: 'ローカル通知サンプル',
  version: '1.0.0',
  description: '端末内に1回限りの通知を予約し、タップ時に拡張機能へイベントを届けます。',
  permissions: ['notifications.schedule'],
  render: () => [
    ui.heading('通知API'),
    ui.text(`許可状態: ${status.value}`),
    interactive.button('許可状態を確認', async () => {
      status.set(await notification.permission());
    }),
    interactive.button('通知を許可', async () => {
      status.set(await permissions.request('notifications.schedule'));
    }),
    interactive.button('1分後にテスト通知', async () => {
      await notification.schedule({
        id: 'notification-test',
        title: 'CIT Hub 通知テスト',
        body: 'タップするとこの拡張機能へ戻ります。',
        at: new Date(Date.now() + 60_000),
        data: { source: 'extension-sample' }
      });
      status.set('予約しました');
    }),
    interactive.button('予約を表示', async () => {
      status.set(`予約 ${ (await notification.listScheduled()).length }件`);
    }),
    interactive.button('予約を取り消す', async () => {
      await notification.cancel('notification-test');
      status.set('取り消しました');
    })
  ]
});
