import { defineProgram, app, ui } from '../sdk/index';

export default defineProgram({
  name: 'ホストAPIバージョン',
  version: '1.0.0',
  description: 'アプリのリリース番号と拡張機能Host APIのバージョンを表示します。',
  permissions: [],
  render: () => [
    ui.heading('実行環境'),
    ui.text(`アプリ ${app.version()}`),
    ui.text(`Host API ${app.hostVersion()}`),
  ],
});
