import { defineProgram, groups, realtime, ui } from '../sdk/index';

export default defineProgram({
  name: 'Group realtime example',
  version: '1.0.0',
  description: 'Invitation-only group topic using HTTPS polling',
  permissions: ['cloud.shared'],
  render: () => [
    ui.text('Groups share only the latest topic event. Polling is foreground-friendly, not push.'),
    ui.button('Create group', async () => {
      await groups.create('Study group');
    }),
    ui.button('Publish status', async () => {
      const available = await groups.list();
      if (available[0]) await realtime.publish(available[0].id, 'status', { online: true });
    })
  ]
});
