import { defineProgram, files, interactive, share, state, ui } from '../sdk/index';

const status = state.create('共有する画像を選択してください。');
const selectedKey = state.create('');

export default defineProgram({
  name: '選択ファイル共有',
  version: '1.0.0',
  description: '利用者が選んだ画像をOS標準の共有画面で共有します。',
  permissions: ['files.user', 'files.selection.read'],
  render: () => [
    ui.heading('画像を共有'),
    ui.text(status.value),
    interactive.button('画像を選ぶ', async () => {
      try {
        const selected = await files.pickImage();
        if (!selected) {
          status.set('選択をキャンセルしました。');
          return;
        }
        selectedKey.set(selected.key);
        status.set(`${selected.name}を選択しました。次に共有を押してください。`);
      } catch (error) {
        status.set(error instanceof Error ? error.message : String(error));
      }
    }),
    interactive.button('選択した画像を共有', async () => {
      if (!selectedKey.value) {
        status.set('先に画像を選択してください。');
        return;
      }
      try {
        await share.file(selectedKey.value);
        status.set('共有先を選択してください。');
      } catch (error) {
        status.set(error instanceof Error ? error.message : String(error));
      }
    })
  ]
});
