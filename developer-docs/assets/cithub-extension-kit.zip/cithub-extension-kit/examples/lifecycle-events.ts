import { app, defineProgram, state, ui } from '../sdk';

const events = state.create('イベント待機中');
const record = (message: string) => events.set(`${events.value} → ${message}`);

app.onLaunch(() => record('起動'));
app.onAppear(() => record('表示'));
app.onDisappear(() => record('非表示'));
app.onResume(() => record('再開'));
app.onSuspend(() => record('中断'));
app.onOpenURL(({ url }) => record(`URL: ${url}`));
app.onNotification(({ identifier, action }) => {
  record(`通知: ${identifier ?? '通知'} (${action ?? 'open'})`);
});
app.onMemoryWarning(() => record('メモリ警告'));

export default defineProgram({
  name: 'ライフサイクル確認',
  version: '1.0.0',
  description: '起動・表示状態・URL・通知・メモリ警告イベントの受信確認',
  permissions: [],
  render: () => [ui.page('イベント', [ui.text(events.value)])]
});
