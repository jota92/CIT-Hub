import {defineProgram,cit,ui,interactive,state} from '../sdk/index';
const expected=await cit.todo.get('todo-a');
if(!expected)throw Error('todo_missing');
const result=state.create('ready');
export default defineProgram({name:'添付競合検証',version:'1.0.0',description:'読み取り後の添付変更を検出します。',permissions:['todos.read','todos.write'],render:()=>[
 ui.text(result.value),interactive.button('削除',async()=>{
   try{await cit.todo.delete(expected);result.set('deleted');}
   catch(error){result.set(error instanceof Error?error.message:String(error));}
 })
]});
