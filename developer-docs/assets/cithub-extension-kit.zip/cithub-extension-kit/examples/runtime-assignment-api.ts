import { defineProgram, cit, ui } from '../sdk/index';

const assignments = await cit.assignments.list();
const upcoming = await cit.assignments.pending();
const late = await cit.assignments.overdue();
const dueSoon = await cit.assignments.dueSoon(14);
const searched = await cit.assignments.search('レポート');
const courseWork = await cit.assignments.byCourse('情報');
const dated = await cit.assignments.between(new Date('2026-04-01T00:00:00+09:00'), new Date('2027-03-31T23:59:59+09:00'));
const first = assignments[0] ? await cit.assignments.get(assignments[0].id) : null;

export default defineProgram({
  name: '構造化課題API検証',
  version: '1.0.0',
  description: '取得済み課題を条件検索し、詳細情報を参照します。',
  permissions: ['assignments.read'],
  render: () => [ui.text(JSON.stringify({ assignments, upcoming, late, dueSoon, searched, courseWork, dated, first }))]
});
