import {defineProgram,cit,ui} from '../sdk/index';
const notes=await cit.courseNotes.list();
const first=notes.length?await cit.courseNotes.get(notes[0].id):null;
export default defineProgram({name:'授業メモ検証',version:'1.0.0',description:'本人の保存済み授業メモを読み取ります。',permissions:['courseNotes.read'],render:()=>[ui.text(JSON.stringify({notes,first}))]});
