import { defineExtension, ui, campus } from '../sdk/index';

export default defineExtension({
  name: '資料と授業情報', version: '1.0.0',
  description: '自分の時間割・課題・ToDo・表示設定を確認し、選んだ資料を表示・再生できます。',
  permissions: ['timetable.read', 'assignments.read', 'todos.read', 'settings.read', 'files.user', 'browser.open'],
  content: [
    ui.heading('資料を開く'), ui.file('material', '画像・動画・音声・PDFなど'),
    ui.browser('大学のサイトをアプリ内で開く', 'https://www.it-chiba.ac.jp/'),
    ui.link('大学のサイトを外部ブラウザで開く', 'https://www.it-chiba.ac.jp/'),
    ui.divider(), ui.data(campus.courseData(), '時間割データ'),
    ui.data(campus.assignmentData(), '取得済み課題データ'),
    ui.data(campus.todoData(), '自分のToDoデータ'),
    ui.data(campus.displaySettings(), '表示・学内サービス設定'),
  ],
});
