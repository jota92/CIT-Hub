import { defineProgram,ui,state,sensors,map,cit } from '../sdk/index';

const output=state.create('ボタンを押して取得してください。');
async function read(kind:'accelerometer'|'gyroscope'|'magnetometer'|'orientation') {
  try { output.set(JSON.stringify(await sensors[kind](),null,2)); }
  catch(error) { output.set(error instanceof Error?error.message:'取得できません。'); }
}
export default defineProgram({
  name:'端末と経路の例',version:'1.0.0',description:'端末センサーの実測値と地図アプリへの経路表示を確認します。',
  permissions:['sensors.motion','browser.open','settings.read'],
  render:()=>[
    ui.text('センサーがない端末では非対応と表示されます。計測は画面を閉じると終了します。'),
    ui.button('加速度を取得',()=>read('accelerometer')),
    ui.button('回転速度を取得',()=>read('gyroscope')),
    ui.button('磁場を取得',()=>read('magnetometer')),
    ui.button('姿勢を取得',()=>read('orientation')),
    ui.button('表示言語を取得',async()=>{output.set(await cit.settings.language());}),
    ui.button('津田沼駅への徒歩経路',()=>map.openDirections({latitude:35.6913,longitude:140.0207},{name:'津田沼駅',mode:'walking'})),
    ui.code(output.value)
  ]
});
