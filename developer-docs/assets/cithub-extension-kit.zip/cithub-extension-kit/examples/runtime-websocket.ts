import { defineProgram, interactive, network, state, ui } from '../sdk/index';

const status = state.create('未接続');
const messages = state.create<string[]>([]);
let socket: Awaited<ReturnType<typeof network.websocket.connect>> | null = null;

async function connect() {
  if (socket) return;
  status.set('接続中');
  try {
    const connection = await network.websocket.connect('wss://stream.example.net/events');
    socket = connection;
    connection.onMessage(text => messages.set([...messages.value, text].slice(-20)));
    connection.onClose(event => { socket = null; status.set(`切断 (${event.code})`); });
    connection.onError(code => { socket = null; status.set(`通信エラー: ${code}`); });
    await connection.ready;
    status.set('接続済み');
  } catch (error) {
    socket = null;
    status.set(error instanceof Error ? error.message : String(error));
  }
}

async function disconnect() {
  const current = socket;
  socket = null;
  await current?.close();
  status.set('未接続');
}

export default defineProgram({
  name: 'WebSocket接続サンプル',
  version: '1.0.0',
  description: '宣言したWSSホストからイベントを受信します。',
  permissions: ['network.fetch'],
  network: ['stream.example.net'],
  render: () => [
    ui.heading('ライブ更新'),
    ui.text(status.value),
    interactive.button('接続', connect),
    interactive.button('切断', disconnect),
    ...messages.value.map(message => ui.text(message))
  ]
});
