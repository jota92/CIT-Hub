import { defineProgram, interactive, NetworkError, ui } from '../sdk';

export default defineProgram({
  name: 'エラー表示の確認',
  version: '1.0.0',
  description: '未処理の通信エラーを、拡張機能を停止せず利用者に通知するテスト用サンプルです。',
  permissions: [],
  render: () => [
    ui.heading('エラー処理'),
    ui.text('ボタンを押すと、型付きエラーが画面上に表示されます。'),
    interactive.button('通信エラーを発生させる', () => {
      throw new NetworkError('network_timeout');
    }),
  ],
});
