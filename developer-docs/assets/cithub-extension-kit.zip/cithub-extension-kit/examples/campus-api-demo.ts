import { defineExtension, campus, ui } from '../sdk/index';

export default defineExtension({
  name: '授業と課題メモ',
  version: '1.0.0',
  description: '現在・次の授業、今日の時間割、履修状況、課題とToDoの件数を確認できます。準備メモと確認状態を保存するサンプルです。',
  permissions: ['timetable.read', 'assignments.read', 'todos.read', 'cloud.storage'],
  content: [
    ui.text('アプリが取得済みの情報を表示します。未取得の情報や提出状況は判定できません。'),
    ui.section('授業', [
      ui.data(campus.currentClass(), '現在の授業'),
      ui.data(campus.nextClass(), '次の授業'),
      ui.data(campus.today(), '今日の時間割'),
      ui.data(campus.enrollment(), '履修状況'),
    ]),
    ui.section('課題とToDo', [
      ui.data(campus.workload(), '課題の状況'),
      ui.data(campus.dueSoon(), '7日以内の期限'),
      ui.data(campus.overdue(), '期限超過'),
      ui.data(campus.todos(), '自分のToDo'),
    ]),
    ui.section('準備メモ', [
      ui.text('ここに入力したメモと確認状態だけを、拡張機能専用のサーバー領域に保存します。'),
      ui.field('preparation', '持ち物・次にすること'),
      ui.toggle('prepared', '授業の準備を確認した'),
      ui.button('保存する', 'save'),
      ui.button('入力をクリア', 'reset'),
    ]),
  ],
});
