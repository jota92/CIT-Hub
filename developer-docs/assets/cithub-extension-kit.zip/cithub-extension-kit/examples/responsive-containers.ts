import { defineProgram, ui } from '../sdk/index';

export default defineProgram({
  name: '授業カード',
  version: '1.0.0',
  description: 'レスポンシブなカードとグループで授業情報をまとめます。',
  permissions: ['timetable.read'],
  render: () => [
    ui.container([
      ui.card([
        ui.heading('次の授業'),
        ui.data('courses.next', '次の授業')
      ], '時間割'),
      ui.group([
        ui.caption('授業の準備'),
        ui.text('ノートと教材を確認します。')
      ])
    ])
  ]
});
