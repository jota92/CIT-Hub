import { defineProgram, server, state, ui } from '../sdk/index';
import type { ServerRecord } from '../sdk/index';

const title=state.create('');
const rows=state.create<ServerRecord[]>([]);
const feedback=state.create('');
async function reload(){rows.set((await server.db.query('notes',{limit:20})).rows);}
async function perform(task:()=>Promise<void>){
  try{await task();await reload();feedback.set('保存内容を取得しました。');}
  catch(error){feedback.set(error instanceof Error?error.message:'処理に失敗しました。');}
}
export default defineProgram({
  name:'サーバー保存の例',version:'1.0.0',description:'本人専用の保存領域と競合を検出する更新操作の例です。',
  permissions:['cloud.storage'],
  render:()=>[
    ui.textField('title','内容',title),
    ui.button('追加',()=>perform(async()=>{
      if(!title.value.trim())throw Error('内容を入力してください。');
      await server.db.insert('notes',`note-${Date.now()}`,{title:title.value});title.set('');
    })),
    ui.button('最新の内容を取得',()=>perform(async()=>{})),
    ...rows.value.flatMap(row=>[
      ui.text(String(row.value.title??'')),
      ui.button('入力した内容に変更',()=>perform(async()=>{
        if(!title.value.trim())throw Error('内容を入力してください。');
        await server.db.update('notes',row.id,{title:title.value},row.revision);
      })),
      ui.button('削除',()=>perform(async()=>{await server.db.delete('notes',row.id,row.revision);})),
      ui.divider()
    ]),
    ui.text(feedback.value)
  ]
});
