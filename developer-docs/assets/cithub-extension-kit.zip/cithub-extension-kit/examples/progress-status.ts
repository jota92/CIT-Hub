import { defineProgram, ui } from '../sdk/index';

export default defineProgram({
  name: 'Progress status',
  version: '1.0.0',
  description: 'Shows task progress using the host-native progress indicator.',
  permissions: [],
  render: () => [
    ui.heading('Import status'),
    ui.progress('Files processed', 0.62),
    ui.caption('62% complete'),
  ],
});
