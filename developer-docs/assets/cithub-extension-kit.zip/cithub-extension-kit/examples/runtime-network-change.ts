import { defineProgram, interactive, network, state, ui } from '../sdk/index';

const label = state.create('接続状態の変化を待っています。');
let unsubscribe: (() => void) | null = null;

export default defineProgram({
  name: '接続状態の変化',
  version: '1.0.0',
  description: 'ネットワーク接続・通信方式の変化を表示します。',
  permissions: ['network.status'],
  render: () => [
    ui.text(label.value),
    interactive.button('監視を開始', async () => {
      if (unsubscribe) return;
      unsubscribe = await network.onChange(status => {
        label.set(`${status.connected ? '接続中' : '未接続'}・${status.transport}`);
      });
      label.set('接続状態の監視中です。');
    }),
    interactive.button('監視を停止', () => {
      unsubscribe?.();
      unsubscribe = null;
      label.set('監視を停止しました。');
    })
  ]
});
