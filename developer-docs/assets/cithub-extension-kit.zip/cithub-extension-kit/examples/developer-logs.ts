import { console, debug, defineProgram, ui } from '../sdk/index';
export default defineProgram({
  name:'開発ログの例',version:'1.0.0',description:'本人用プレビューの開発ログを確認します。',permissions:[],
  render:()=>[
    ui.text('開発プレビューの「開発ログ」から確認できます。送信後はDeveloper Consoleにも表示されます。'),
    ui.button('ログを記録',()=>{
      console.log('画面操作が完了しました。',{step:1});
      console.warn('状態の確認',{available:false});
      console.error('エラー処理の例',{code:'example_error'});
    }),
    ui.code(debug.inspect({screen:'example',state:{count:1}}))
  ]
});
