import { defineProgram, ui } from '../sdk';

export default defineProgram({
  name: 'スクロール表示',
  version: '1.0.0',
  description: '縦方向と横方向の独立したスクロール領域',
  permissions: [],
  render: () => [
    ui.heading('横にスクロール'),
    ui.horizontalScroll([
      ui.badge('月曜日'), ui.badge('火曜日'), ui.badge('水曜日'),
      ui.badge('木曜日'), ui.badge('金曜日'), ui.badge('土曜日')
    ]),
    ui.scroll([
      ui.text('この領域は縦方向にスクロールします。'),
      ...Array.from({ length: 12 }, (_, index) => ui.text(`項目 ${index + 1}`))
    ])
  ]
});
