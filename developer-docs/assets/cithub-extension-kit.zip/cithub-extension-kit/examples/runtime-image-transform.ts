import { defineProgram, files, interactive, state, ui } from '../sdk/index';

const status = state.create('画像を選択してください。');
const selectedKey = state.create('');

export default defineProgram({
  name: '画像を軽量化',
  version: '1.0.0',
  description: '選択した画像を端末内で縮小し、JPEGで保存します。',
  permissions: ['files.user', 'files.selection.read', 'files.storage'],
  render: () => [
    ui.text(status.value),
    interactive.button('画像を選ぶ', async () => {
      try {
        const image = await files.pickImage();
        if (!image) return;
        selectedKey.set(image.key);
        status.set(`${image.name}を選択しました。`);
      } catch (error) {
        status.set(error instanceof Error ? error.message : String(error));
      }
    }),
    interactive.button('縮小して保存', async () => {
      if (!selectedKey.value) {
        status.set('先に画像を選択してください。');
        return;
      }
      try {
        const result = await files.transformImage(selectedKey.value, 'optimized.jpg', {
          maxDimension: 1600,
          quality: 0.82
        });
        status.set(`${result.width} x ${result.height} px / ${result.size} bytes`);
      } catch (error) {
        status.set(error instanceof Error ? error.message : String(error));
      }
    }),
    interactive.button('JPEGを書き出す', async () => {
      try {
        await files.export('optimized.jpg', 'optimized.jpg');
      } catch (error) {
        status.set(error instanceof Error ? error.message : String(error));
      }
    })
  ]
});
