import { defineProgram, interactive, state, ui } from '../sdk/index';

const reminderAt = state.create<number | null>(null);

export default defineProgram({
  name: '日時入力',
  version: '1.0.0',
  description: '日時を選択して予定を確認します。',
  permissions: [],
  render: () => [
    ui.heading('予定日時'),
    interactive.dateTime('reminderAt', '通知する日時', reminderAt),
    ui.text(reminderAt.value === null ? '日時は未設定です' : `選択した時刻（Unix ms）: ${reminderAt.value}`),
  ],
});
