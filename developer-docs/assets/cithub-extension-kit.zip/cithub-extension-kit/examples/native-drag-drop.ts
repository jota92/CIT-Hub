import { defineProgram, drag, drop, ui } from '../sdk/index';

export default defineProgram({
  name: 'テキストのドラッグ＆ドロップ',
  version: '1.0.0',
  description: '拡張機能画面内で文字列をドラッグし、ドロップ先へ受け渡します。',
  permissions: [],
  render: () => [
    ui.text('OS標準のドラッグ操作でテキストを移動できます。受け渡しはこの画面内で完結します。'),
    drag.source('ドラッグする文字', 'CIT Hub extension'),
    drop.target('receivedText', 'ここにドロップ')
  ]
});
