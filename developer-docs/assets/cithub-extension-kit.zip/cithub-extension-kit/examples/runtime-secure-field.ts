import { defineProgram, interactive, state, ui } from '../sdk/index';

const credential = state.create('');
export default defineProgram({
  name: 'セキュア入力例', version: '1.0.0',
  description: '画面上の文字を伏せる入力欄の例です。', permissions: [],
  render: () => [ui.heading('確認コード'), interactive.secureField('code', 'コード', credential), ui.text(`入力文字数: ${credential.value.length}`)]
});
