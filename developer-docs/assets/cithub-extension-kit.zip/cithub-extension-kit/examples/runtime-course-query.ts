import { defineProgram, cit, ui } from '../sdk/index';
const at = new Date('2026-10-07T01:00:00Z');
const current = await cit.courses.current(at);
const next = await cit.courses.next(at);
const today = await cit.courses.today(at);
const found = await cit.courses.search('数学');
const overdue = await cit.assignments.overdue(at);
const dueSoon = await cit.assignments.dueSoon(7, at);
export default defineProgram({name:'授業データ検証',version:'1.0.0',description:'授業と課題の検索を確認します。',permissions:['timetable.read','assignments.read'],render:()=>[ui.text(JSON.stringify({current,next,today,found,overdue,dueSoon}))]});
