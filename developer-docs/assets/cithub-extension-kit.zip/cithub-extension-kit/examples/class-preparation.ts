import { defineExtension, ui } from '../sdk/index';
export default defineExtension({
 name: '授業の準備', version: '1.0.0', description: '次回授業の持ち物と準備を記録します。',
 permissions: ['cloud.storage'],
 content: [
  ui.text('持ち物や準備を書いて保存してください。'),
  ui.section('次回の授業', [ui.field('course','授業名'), ui.field('memo','持ち物・準備'), ui.toggle('ready','準備できた')]),
  ui.row([ui.button('保存する','save'), ui.button('入力をクリア','reset')]),
 ],
});
