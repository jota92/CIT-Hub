import { defineProgram, app, state, date, utils, interactive, ui } from '../sdk/index';
const status=state.create('待機中');
app.onLaunch(async()=>{await utils.sleep(20);status.set('起動しました。');});
app.onResume(()=>{status.set('再開しました。');});
app.onSuspend(()=>{status.set('中断しました。');});
export default defineProgram({name:'実行環境テスト',version:'1.0.0',description:'日時・タイマー・ライフサイクルの動作テストです。',permissions:[],render:()=>[
 ui.text(status.value),ui.text(date.format('2026-10-07T00:00:00Z',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'})),
 interactive.button('少し待って更新',async()=>{await utils.sleep(20);status.set('更新しました。');})
]});
