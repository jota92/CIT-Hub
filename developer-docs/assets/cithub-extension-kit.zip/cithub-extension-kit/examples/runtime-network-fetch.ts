import { defineProgram, interactive, network, state, ui } from '../sdk/index';

const result = state.create('まだ取得していません');

async function loadStatus() {
  result.set('通信中…');
  try {
    const response = await network.get('https://api.example.net/v1/status', {
      Accept: 'application/json'
    });
    result.set(response.ok ? response.body.slice(0, 1200) : `HTTP ${response.status}`);
  } catch (error) {
    result.set(error instanceof Error ? error.message : String(error));
  }
}

export default defineProgram({
  name: 'HTTPS通信サンプル',
  version: '1.0.0',
  description: '許可先として宣言したHTTPS APIから状態を取得します。',
  permissions: ['network.fetch'],
  network: ['api.example.net'],
  render: () => [
    ui.heading('API状態'),
    ui.text(result.value),
    interactive.button('取得', loadStatus)
  ]
});
