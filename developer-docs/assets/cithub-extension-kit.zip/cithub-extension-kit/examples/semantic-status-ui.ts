import { defineExtension, ui } from '../sdk/index';

export default defineExtension({
  name: '状態表示サンプル',
  version: '1.0.0',
  description: '読み込み中、空状態、エラー状態をOS標準UIで表示します。',
  permissions: [],
  content: [
    ui.loading('データを読み込み中'),
    ui.emptyState('予定はありません', '新しい予定が登録されると、ここに表示されます。'),
    ui.errorState('読み込めませんでした', '通信状態を確認して、もう一度お試しください。')
  ]
});
