import { accessibility, defineProgram, interactive, state, ui } from '../sdk/index';

const enabled = state.create(false);
const memo = state.create('');
const status = state.create('まだ実行していません');

export default defineProgram({
  name: '読み上げ操作の例', version: '1.0.0',
  description: '読み上げラベル・ヒントと操作部品を組み合わせる例です。', permissions: [],
  render: () => [
    accessibility.role(ui.heading('アクセシビリティ確認'), 'heading'),
    accessibility.label(ui.text(status.value), '実行結果'),
    accessibility.hint(interactive.textField('memo', '授業メモ', memo), '授業で確認する内容を入力します。'),
    accessibility.role(interactive.toggle('enabled', '通知を有効にする', enabled), 'switch'),
    accessibility.hint(interactive.button('確認', () => status.set('ボタン操作を受け取りました')), 'タップすると操作結果を更新します。')
  ]
});
