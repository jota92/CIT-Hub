import { defineExtension, ui, campus, actions } from '../sdk/index';

export default defineExtension({
  name: '授業の準備メモ', version: '1.0.0',
  description: '次の授業を確認して、準備をToDoに追加します。必要な資料は端末内に保存できます。',
  permissions: ['timetable.read', 'todos.write', 'files.user'],
  content: [
    ui.styled(ui.heading('授業の準備'), { tone: 'accent', textSize: 'title' }),
    ui.data(campus.nextClass(), '次の授業'),
    ui.divider(),
    ui.field('title', 'やること'),
    ui.field('detail', '詳細'),
    ui.date('deadline', '期限'),
    ui.date('notification', '通知する日時'),
    actions.createTodo('内容を確認して追加', 'title', 'detail', 'deadline', 'notification'),
    ui.divider(),
    ui.file('material', '準備に使う資料'),
  ],
});
