import { defineProgram, ui, state, navigation, cit, extensions, link } from '../sdk/index';

const id=state.create('');
const feedback=state.create('移動先はボタンを押したときに開きます。');
async function run(action:()=>Promise<unknown>) {
  try { const result=await action();if(result!==undefined)feedback.set(String(result)); }
  catch(error) { feedback.set(error instanceof Error?error.message:String(error)); }
}
export default defineProgram({
  name:'画面連携の例',version:'1.0.0',description:'ホスト画面、食堂カメラ、追加済み拡張機能への移動と共有リンクを確認します。',
  permissions:['host.navigate','extensions.read','cafeteria.read'],
  render:()=>[
    ui.button('時間割を開く',()=>run(()=>navigation.openHostPage('timetable'))),
    ui.button('ToDoを開く',()=>run(()=>navigation.openHostPage('todo'))),
    ui.button('ポータルを開く',()=>run(()=>cit.services.open('portal'))),
    ui.button('食堂ライブカメラ',()=>run(()=>cit.cafeteria.openCamera())),
    ui.textField('extensionId','拡張機能ID',id),
    ui.button('追加済みか確認',()=>run(()=>extensions.isInstalled(id.value))),
    ui.button('追加済みの版を開く',()=>run(()=>extensions.open(id.value))),
    ui.button('追加内容を確認',()=>run(()=>extensions.request(id.value))),
    ui.button('共有リンクを取得',()=>run(()=>link.create(id.value))),
    ui.text(feedback.value)
  ]
});
