import { defineProgram, interactive, state, text, ui } from '../sdk/index';

const input = state.create('CIT Hub 2.0.2');
const status = state.create('');
const versionPattern = text.regex('^(CIT Hub)\\s+(\\d+\\.\\d+\\.\\d+)$', 'i');

export default defineProgram({
  name: '正規表現ヘルパー',
  version: '1.0.0',
  description: '入力文字列からCIT Hubのバージョン表記を検出します。',
  permissions: [],
  render: () => [
    ui.heading('バージョン表記を確認'),
    interactive.textField('version', 'アプリ名とバージョン', input),
    ui.text(status.value),
    interactive.button('確認', () => {
      const match = versionPattern.exec(input.value);
      status.set(match ? `アプリ: ${match[1]} / バージョン: ${match[2]}` : '形式が一致しません。');
    })
  ]
});
