import { auth, browser, defineProgram, state, ui } from '../sdk';

const status = state.create('未接続');

const provider = {
  authorizationEndpoint: 'https://accounts.example.edu/oauth2/authorize',
  tokenEndpoint: 'https://accounts.example.edu/oauth2/token',
  clientId: 'public-cithub-extension-client',
  scopes: ['calendar.read']
};

export async function connectProvider() {
  // Call only from a visible button so opening the system browser is user initiated.
  const session = await auth.oauth2(provider);
  status.set(`接続済み・有効期限: ${session.expiresAt ? new Date(session.expiresAt).toLocaleString() : 'プロバイダー指定なし'}`);
  return session;
}

export async function providerStatus() {
  const status = await auth.tokenStatus();
  return status.connected ? `接続済み (${status.scopes.join(', ')})` : '未接続';
}

export async function openProviderDocs() {
  await browser.openExternal('https://accounts.example.edu/developer/oauth');
}

export default defineProgram({
  name: 'OAuth 2.0接続',
  version: '1.0.0',
  description: 'PKCEを使った外部サービス接続の基本例です。',
  permissions: ['browser.open', 'network.fetch'],
  network: ['accounts.example.edu'],
  render: () => [
    ui.heading('外部サービスに接続'),
    ui.text(status.value),
    ui.button('接続する', async () => {
      try { await connectProvider(); }
      catch (error) { status.set(error instanceof Error ? error.message : '接続できませんでした。'); }
    }),
    ui.button('接続状態を確認', async () => { status.set(await providerStatus()); }),
    ui.button('接続を解除', async () => { await auth.logout(); status.set('未接続'); }),
    ui.button('プロバイダーの説明を開く', openProviderDocs)
  ]
});
