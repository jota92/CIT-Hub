import { audio, defineProgram, files, state, ui, video } from '../sdk/index';
const audioKey=state.create(''),videoKey=state.create(''),feedback=state.create('');
async function attempt(task:()=>Promise<void>){try{await task();}catch(error){feedback.set(error instanceof Error?error.message:'再生できませんでした。');}}
export default defineProgram({
  name:'メディア再生の例',version:'1.0.0',description:'選択した音声と動画を端末のプレイヤーで再生します。',
  permissions:['files.user','files.selection.read'],
  render:()=>[
    ui.button('音声を選ぶ',()=>attempt(async()=>{const file=await files.pickAudio();if(file)audioKey.set(file.key);})),
    ...(audioKey.value?[
      ui.button('音声を再生',()=>attempt(()=>audio.play(audioKey.value))),
      ui.button('音声を再開',()=>attempt(()=>audio.play())),
      ui.button('一時停止',()=>attempt(()=>audio.pause())),
      ui.button('停止',()=>attempt(()=>audio.stop())),
      ui.button('再生位置と長さを確認',()=>attempt(async()=>{feedback.set(`${await audio.position()??0} / ${await audio.duration()??0} 秒`);}))
    ]:[]),
    ui.button('動画を選ぶ',()=>attempt(async()=>{const file=await files.pickVideo();if(file)videoKey.set(file.key);})),
    ...(videoKey.value?[
      ui.button('動画を再生',()=>attempt(()=>video.play(videoKey.value))),
      ui.button('動画を一時停止',()=>attempt(()=>video.pause()))
    ]:[]),
    ui.text(feedback.value)
  ]
});
