import { defineProgram,ui,state,groups,cloud,type ExtensionGroup,type SharedValue } from '../sdk/index';

const name=state.create('共同メモ'),invitation=state.create(''),text=state.create('');
const selected=state.create<ExtensionGroup|null>(null),record=state.create<SharedValue<{text:string}>|null>(null);
const feedback=state.create('参加済みグループの取得、または作成・招待で始めます。');
async function run(action:()=>Promise<void>) {
  try { await action(); } catch(error) { feedback.set(error instanceof Error?error.message:'操作できません。'); }
}
export default defineProgram({
  name:'グループメモの例',version:'1.0.0',description:'招待で参加したグループのメモを共有します。実名や学番は表示しません。',
  permissions:['cloud.shared'],
  render:()=>[
    ui.textField('groupName','グループ名',name),
    ui.button('グループを作成',()=>run(async()=>{selected.set(await groups.create(name.value));record.set(null);feedback.set('作成しました。');})),
    ui.button('参加済みの最初のグループを開く',()=>run(async()=>{selected.set((await groups.list())[0]??null);record.set(null);feedback.set(selected.value?'取得しました。':'参加済みグループはありません。');})),
    ui.textField('invitation','招待コード',invitation),
    ui.button('招待で参加',()=>run(async()=>{const group=await groups.join(invitation.value);if(group){selected.set(group);record.set(null);feedback.set('参加しました。');}})),
    ...(selected.value?[
      ui.heading(selected.value.name),
      ui.button('招待を発行',()=>run(async()=>{const issued=await groups.invite(selected.value!.id);invitation.set(issued.invitation);feedback.set('招待コードは24時間、1人のみ有効です。');})),
      ui.button('メンバーを確認',()=>run(async()=>{feedback.set(JSON.stringify(await groups.members(selected.value!.id),null,2));})),
      ui.textArea('note','共有する内容',text),
      ui.button('メモを取得',()=>run(async()=>{const value=await cloud.shared.read<{text:string}>(selected.value!.id,'note');record.set(value);text.set(value?.value.text??'');feedback.set(value?'取得しました。':'メモはありません。');})),
      ui.button('メモを保存',()=>run(async()=>{const group=selected.value!.id,old=record.value;record.set(old?await cloud.shared.update(group,'note',{text:text.value},old.revision):await cloud.shared.create(group,'note',{text:text.value}));feedback.set('保存しました。競合した場合は取得してから確認してください。');})),
      ui.button('メモを削除',()=>run(async()=>{if(record.value){await cloud.shared.delete(selected.value!.id,'note',record.value.revision);record.set(null);text.set('');feedback.set('削除しました。');}})),
      ui.button('グループから退出',()=>run(async()=>{if(await groups.leave(selected.value!.id)){selected.set(null);record.set(null);feedback.set('退出しました。');}}))
    ]:[]),
    ui.text(feedback.value)
  ]
});
