import {defineProgram,cit,ui} from '../sdk/index';
for(const fields of [
 {title:'invalid',url:'javascript:alert(1)'},
 {title:'invalid',deadline:'2000-01-01T00:00:00Z'},
 {title:'invalid',deadline:'2050-01-01T00:00:00Z',notificationMode:'weekly' as const,notificationDate:'2050-01-01T00:00:00Z'},
 {title:'invalid',deadline:'2050-01-01T00:00:00Z',notificationMode:'once' as const,notificationDate:'2050-01-02T00:00:00Z'}
]) {
 let rejected=false;
 try { await cit.todo.create(fields); } catch(error) { rejected=error instanceof Error&&['todo_invalid_url','todo_invalid_schedule'].includes(error.message); }
 if(!rejected)throw Error('invalid_todo_was_not_rejected');
}
const created=await cit.todo.create({title:'検証用ToDo',detail:'作成'});
const updated=await cit.todo.update(created,{title:'検証用ToDo',detail:'更新'});
let conflict=false;
try { await cit.todo.delete(created); } catch(error) { conflict=error instanceof Error&&error.message==='todo_conflict'; }
if(!conflict)throw Error('stale_delete_was_not_rejected');
await cit.todo.delete(updated);
export default defineProgram({
 name:'ToDo書き込み検証',version:'1.0.0',description:'追加・編集・競合拒否・削除を検証します。',
 permissions:['todos.read','todos.write'],render:()=>[ui.text('PASS ToDo mutations')]
});
