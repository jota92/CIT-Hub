import { defineProgram, cit, ui, state } from '../sdk/index';

const [events, today, period] = await Promise.all([
  cit.academicCalendar.list(),
  cit.academicCalendar.on(new Date()),
  cit.academicCalendar.between(new Date(), new Date(Date.now() + 7 * 24 * 60 * 60 * 1000))
]);
const rendered = state.create(JSON.stringify({ events, today, period }));

export default defineProgram({
  name: '学年暦の確認',
  version: '1.0.0',
  description: 'キャッシュ済み学年暦から今日と今後7日間の予定を確認します。',
  permissions: ['calendar.read'],
  render: () => [ui.heading('学年暦'), ui.text(rendered.value)]
});
