import { defineProgram, cit, ui, state } from '../sdk/index';

const start = new Date();
const end = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
const [events, holidays, classDays, weekNumber] = await Promise.all([
  cit.calendar.events(),
  cit.calendar.holidays(start, end),
  cit.calendar.classDays(start, end),
  Promise.resolve(cit.calendar.weekNumber(start))
]);
const rendered = state.create(JSON.stringify({ events, holidays, classDays, weekNumber }));

export default defineProgram({
  name: '学年暦の確認',
  version: '1.0.0',
  description: 'キャッシュ済み学年暦から今日と今後7日間の予定を確認します。',
  permissions: ['calendar.read', 'timetable.read'],
  render: () => [ui.heading('学年暦'), ui.text(rendered.value)]
});
