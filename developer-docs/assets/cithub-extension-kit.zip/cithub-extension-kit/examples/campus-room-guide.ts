import { app, cit, defineProgram, state, ui } from '../sdk/index';

const results = state.create('教室情報を読み込んでいます。');
const roomStatus = state.create('教室を選択して状況を確認できます。');
const searchText = state.create('');

async function refreshRooms() {
  try {
    const rooms = await cit.campus.rooms();
    const matches = searchText.value ? await cit.campus.search(searchText.value) : rooms;
    const buildings = await cit.campus.buildings();
    results.set(JSON.stringify({ rooms: matches, buildings }, null, 2));
  } catch {
    results.set('時間割を取得できないため、教室情報を表示できません。');
  }
}

async function checkFirstRoom() {
  try {
    const rooms = await cit.campus.rooms();
    if (!rooms.length) {
      roomStatus.set('時間割に教室情報がありません。');
      return;
    }
    const room = await cit.campus.room(rooms[0].classroom);
    if (!room) {
      roomStatus.set('教室情報が見つかりません。');
      return;
    }
    const status = await cit.campus.roomAvailability(room.id, new Date());
    roomStatus.set(JSON.stringify(status, null, 2));
  } catch {
    roomStatus.set('この教室の授業状況を確認できませんでした。');
  }
}

app.onLaunch(refreshRooms);
app.onAppear(refreshRooms);

export default defineProgram({
  name: '時間割の教室一覧',
  version: '1.0.0',
  description: '取得済みの自分の時間割から教室を一覧・検索します。空室情報は表示しません。',
  permissions: ['timetable.read'],
  render: () => [
    ui.heading('時間割の教室'),
    ui.text('教室一覧は本人の取得済み時間割から作成します。大学全体の空室状況ではありません。'),
    ui.searchField('roomQuery', '教室を検索', searchText, { onSubmit: refreshRooms }),
    ui.button('一覧を更新', refreshRooms),
    ui.text(results.value),
    ui.button('先頭の教室の授業状況', checkFirstRoom),
    ui.text(roomStatus.value)
  ]
});
