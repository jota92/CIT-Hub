import { defineProgram, intent, ui } from '../sdk/index';

let value = '未実行';
intent.register<{ message: string }, string>('example.greeting', input => {
  value = input.message;
  return `受信: ${input.message}`;
});

export default defineProgram({
  name: 'Intent dispatch example',
  version: '1.0.0',
  description: '同じ拡張機能内で名前付き処理を登録して呼び出す例',
  permissions: [],
  render: () => [
    ui.text(`結果: ${value}`),
    ui.button('Intentを実行', async () => {
      const results = await intent.perform<{ message: string }, string>('example.greeting', { message: 'こんにちは' });
      value = results.join(', ');
    })
  ]
});
