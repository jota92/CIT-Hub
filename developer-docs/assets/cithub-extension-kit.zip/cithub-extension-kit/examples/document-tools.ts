import { camera, defineProgram, files, pdf, state, ui, video } from '../sdk/index';

const feedback=state.create('');
const selectedPDF=state.create('');
const selectedVideo=state.create('');
async function attempt(task:()=>Promise<void>){try{await task();}catch(error){feedback.set(error instanceof Error?error.message:'処理に失敗しました。');}}
export default defineProgram({
  name:'文書とコード読み取りの例',version:'1.0.0',description:'PDFの生成・書き出し、サムネイル生成、カメラでのコード読み取りを行います。',
  permissions:['files.storage','files.user','files.selection.read','camera.use'],
  render:()=>[
    ui.button('PDFを作成',()=>attempt(async()=>{
      const result=await pdf.create('notes.pdf',[{title:'授業メモ',text:'次回までに資料を確認する。'}]);feedback.set(`${result.pageCount}ページのPDFを作成しました。`);
    })),
    ui.button('作成したPDFを書き出す',()=>attempt(async()=>{feedback.set(await pdf.export('notes.pdf','授業メモ.pdf')?'書き出しました。':'キャンセルしました。');})),
    ui.button('PDFを選択',()=>attempt(async()=>{const file=await files.pickDocument();if(file)selectedPDF.set(file.key);})),
    ...(selectedPDF.value?[ui.button('先頭ページのサムネイルを保存',()=>attempt(async()=>{const result=await pdf.thumbnail(selectedPDF.value,'pdf-preview.jpg');feedback.set(`${result.width} × ${result.height}`);} ))]:[]),
    ui.button('動画を選択',()=>attempt(async()=>{const file=await files.pickVideo();if(file)selectedVideo.set(file.key);})),
    ...(selectedVideo.value?[ui.button('動画のサムネイルを保存',()=>attempt(async()=>{const result=await video.thumbnail(selectedVideo.value,'video-preview.jpg');feedback.set(`${result.width} × ${result.height}`);} ))]:[]),
    ui.button('QRコードを読み取る',()=>attempt(async()=>{const result=await camera.scanQRCode();feedback.set(result?result.value:'キャンセルしました。');})),
    ui.button('バーコードを読み取る',()=>attempt(async()=>{const result=await camera.scanBarcode();feedback.set(result?`${result.format}: ${result.value}`:'キャンセルしました。');})),
    ui.text(feedback.value)
  ]
});
