import { defineProgram, cit, ui, interactive, state } from '../sdk/index';

const status = state.create('未完了');
const todo = await cit.todo.get('todo-a');

export default defineProgram({
  name: 'ToDo完了操作の検証',
  version: '1.0.0',
  description: 'ToDoの完了と未完了への変更を確認します。',
  permissions: ['todos.read', 'todos.write'],
  render: () => [
    ui.text(status.value),
    interactive.button('完了にする', async () => {
      if (!todo) return;
      const updated = await cit.todo.complete(todo.id);
      status.set(updated?.completed ? '完了' : '対象なし');
    }),
    interactive.button('未完了に戻す', async () => {
      if (!todo) return;
      const updated = await cit.todo.uncomplete(todo.id);
      status.set(updated?.completed === false ? '未完了' : '対象なし');
    })
  ]
});
