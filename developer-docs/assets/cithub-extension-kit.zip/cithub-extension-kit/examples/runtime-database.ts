import {defineProgram,database,ui} from '../sdk/index';
await database.createTable('study');
await database.transaction(tx=>{if(!tx.get('study','one'))tx.insert('study',{id:'one',minutes:30});tx.update('study','one',{minutes:90});});
try{await database.transaction(tx=>{tx.delete('study','one');throw Error('rollback');});}catch{}
const record=await database.get('study','one');
export default defineProgram({name:'データベース検証',version:'1.0.0',description:'保存とトランザクションを検証します。',permissions:[],render:()=>[ui.text(JSON.stringify(record))]});
