import {defineProgram,crypto,ui} from '../sdk/index';
const key=crypto.generateKey();
const first=await crypto.encrypt('日本語のメモ',key,'test');
const second=await crypto.encrypt('日本語のメモ',key,'test');
const decoded=await crypto.decrypt(first,key,'test');
let rejected=false;
try{await crypto.decrypt({...first,ciphertext:(first.ciphertext.startsWith('00')?'01':'00')+first.ciphertext.slice(2)},key,'test');}catch{rejected=true;}
if(decoded!=='日本語のメモ'||first.iv===second.iv||!rejected)throw Error('Encryption test failed');
export default defineProgram({name:'暗号化検証',version:'1.0.0',description:'暗号化の復元と改ざん検知を確認します。',permissions:[],render:()=>[ui.text('PASS authenticated encryption')]});
