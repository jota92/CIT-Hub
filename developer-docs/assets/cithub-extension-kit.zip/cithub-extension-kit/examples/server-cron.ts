import { defineProgram, server, ui } from '../sdk/index';

export const serverFunctions = {
  dailySummary: async (input: { label: string }) => ({
    ranAt: new Date().toISOString(),
    label: input.label
  })
};

export default defineProgram({
  name: 'Scheduled function example',
  version: '1.0.0',
  description: 'Server-side scheduled execution through the isolated function runtime',
  permissions: ['server.functions'],
  render: () => [
    ui.button('Register daily job', async () => {
      await server.cron.register('dailySummary', { label: 'daily' }, 86_400);
    }),
    ui.button('Remove job', async () => {
      await server.cron.unregister('dailySummary');
    })
  ]
});
