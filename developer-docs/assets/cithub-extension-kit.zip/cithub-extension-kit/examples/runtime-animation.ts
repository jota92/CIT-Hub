import { animation, defineProgram, interactive, state, ui } from '../sdk/index';

const expanded = state.create(false);

export default defineProgram({
  name: 'ネイティブアニメーション',
  version: '1.0.0',
  description: '状態変化をOS標準のアニメーションで表示する例です。',
  permissions: [],
  render: () => [
    ui.heading(expanded.value ? '詳細を表示中' : '詳細を閉じています'),
    interactive.button('切り替える', () => animation.spring(() => expanded.set(!expanded.value), { duration: 0.3, damping: 0.78 })),
    ...(expanded.value ? [ui.text('アニメーションは状態変更をネイティブUIへ伝えます。')] : [])
  ]
});
