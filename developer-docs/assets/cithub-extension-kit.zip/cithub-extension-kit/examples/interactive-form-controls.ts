import { defineProgram, interactive, state, ui } from '../sdk/index';

const quantity = state.create(2);
const accepted = state.create(false);
const campus = state.create('新習志野');

export default defineProgram({
  name: '入力コントロール',
  version: '1.0.0',
  description: '数量、確認、単一選択をOS標準UIで操作する例',
  permissions: [],
  render() {
    return [
      ui.heading('入力例'),
      interactive.stepper('quantity', '数量', quantity, 0, 10, 1),
      interactive.checkbox('accepted', '内容を確認しました', accepted),
      interactive.radio('campus', 'キャンパス', ['新習志野', '津田沼'], campus),
      ui.label(`数量: ${quantity.value}`),
      ui.label(`確認: ${accepted.value ? '済み' : '未確認'}`),
      ui.label(`選択: ${campus.value}`),
    ];
  },
});
