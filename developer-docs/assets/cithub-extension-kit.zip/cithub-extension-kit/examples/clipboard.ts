import { clipboard, defineProgram, interactive, state, ui } from '../sdk';

const message = state.create('CIT Hubからコピーする文字');
const result = state.create('ボタンを押してクリップボードを操作します');

export default defineProgram({
  name: 'クリップボード例',
  version: '1.0.0',
  description: '利用者の操作で文字をコピーまたは読み取る例',
  permissions: ['clipboard.read', 'clipboard.write'],
  render: () => [ui.page('クリップボード', [
    interactive.textField('message', 'コピーする文字', message),
    ui.text(result.value),
    interactive.button('コピー', async () => {
      await clipboard.writeText(message.value);
      result.set('クリップボードへコピーしました');
    }),
    interactive.button('読み取る', async () => {
      const text = await clipboard.readText();
      result.set(text ?? 'クリップボードに文字がありません');
    })
  ])]
});
