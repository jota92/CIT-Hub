import { defineProgram, interactive, state, ui } from '../sdk/index';

const query = state.create('');
const status = state.create('入力欄を選択してください。');

export default defineProgram({
  name: '入力イベント',
  version: '1.0.0',
  description: '入力フォーカスと送信イベントの確認用サンプルです。',
  permissions: [],
  render: () => [
    ui.heading('検索'),
    interactive.textField('query', 'キーワード', query, {
      onFocus: () => status.set('入力中です。'),
      onBlur: () => status.set('入力を終了しました。'),
      onSubmit: () => status.set(`送信: ${query.value}`)
    }),
    ui.text(status.value)
  ]
});
