import { defineProgram, files, interactive, state, ui } from '../sdk';

const result = state.create('保存領域のファイルを選んでください');

export default defineProgram({
  name: 'ファイルの整理',
  version: '1.0.0',
  description: '拡張機能専用の保存領域でファイルを複製・移動します。',
  permissions: ['files.storage'],
  render: () => [ui.page('ファイル操作', [
    ui.text(result.value),
    interactive.button('複製して移動', async () => {
      try {
        const copied = await files.copy('notes.bin', 'notes-copy.bin');
        if (!copied) {
          result.set('複製元が見つかりません');
          return;
        }
        const moved = await files.move('notes-copy.bin', 'notes-archive.bin');
        result.set(moved ? '複製して保管しました' : '移動元が見つかりません');
      } catch (error) {
        result.set(`失敗: ${String(error)}`);
      }
    })
  ])]
});
