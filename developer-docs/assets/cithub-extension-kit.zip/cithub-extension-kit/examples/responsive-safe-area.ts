import { defineExtension, ui } from '../sdk/index';

export default defineExtension({
  name: 'Responsive course overview',
  version: '1.0.0',
  description: 'A safe-area-aware page that adapts to phone, tablet and desktop widths.',
  permissions: ['timetable.read'],
  content: [
    ui.safeArea([
      ui.frame(ui.column([
        ui.heading('今週の授業'),
        ui.data('timetable.periods'),
        ui.caption('画面幅に合わせて配置し、ノッチやシステム領域と重ならないようにします。'),
      ]), { minWidth: 240, maxWidth: 860 }),
    ]),
  ],
});
