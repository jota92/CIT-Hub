import { browser, defineProgram, interactive, ui } from '../sdk';

export default defineProgram({
  name: '外部ブラウザを開く例',
  version: '1.0.0',
  description: '利用者がボタンを押したときに、HTTPSページを既定のブラウザで開きます。',
  permissions: ['browser.open'],
  render: () => [
    ui.heading('関連ページ'),
    ui.text('リンク先はCIT HubのログインCookieとは共有されません。'),
    interactive.button('大学の公式サイトを開く', async () => {
      await browser.openExternal('https://www.it-chiba.ac.jp/');
    })
  ]
});
