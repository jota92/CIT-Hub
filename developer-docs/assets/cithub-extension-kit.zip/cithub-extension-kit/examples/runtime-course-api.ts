import { defineProgram, cit, ui } from '../sdk/index';

const courses = await cit.courses.list();
const monday = await cit.courses.byWeekday(1);
const mondayFirstPeriod = monday[0] ? await cit.courses.forPeriod(1, monday[0].period) : [];
const firstCourse = courses[0] ? await cit.courses.get(courses[0].id) : null;
const periods = await cit.timetable.periods();
const freeMonday = await cit.timetable.freePeriods(1);
const mondaySchedule = await cit.timetable.at(new Date('2026-10-12T08:00:00+09:00'));
const tuesdaySchedule = await cit.timetable.tomorrow(new Date('2026-10-12T08:00:00+09:00'));
const weeklySchedule = await cit.timetable.week(new Date('2026-10-12T08:00:00+09:00'));
const currentOccurrence = await cit.timetable.current(new Date('2026-10-12T09:15:00+09:00'));
const nextOccurrence = await cit.timetable.next(new Date('2026-10-12T08:00:00+09:00'));

export default defineProgram({
  name: '構造化時間割API検証',
  version: '1.0.0',
  description: '授業ID、学期、担当情報、時限一覧と空き時限を取得します。',
  permissions: ['timetable.read'],
  render: () => [ui.text(JSON.stringify({ courses, monday, mondayFirstPeriod, firstCourse, periods, freeMonday, mondaySchedule, tuesdaySchedule, weeklySchedule, currentOccurrence, nextOccurrence }))]
});
