import {defineProgram,crypto,ui} from '../sdk/index';
const hash=await crypto.hash('abc');
const hmac=await crypto.hmac('The quick brown fox jumps over the lazy dog','key');
export default defineProgram({name:'ハッシュ検証',version:'1.0.0',description:'端末内のSHAとHMACを検証します。',permissions:[],render:()=>[ui.text(hash),ui.text(hmac)]});
