import { defineProgram, interactive, location, permissions, state, ui } from '../sdk/index';

const status = state.create('現在地は取得していません。');

export default defineProgram({
  name: '現在地の確認',
  version: '1.0.0',
  description: 'ボタンを押した時だけ、端末の現在地を確認します。',
  permissions: ['location.use'],
  render: () => [
    ui.text(status.value),
    interactive.button('現在地を取得', async () => {
      const permission = await permissions.request('location.use');
      if (permission !== 'granted') {
        status.set(permission === 'denied' ? '位置情報が許可されていません。端末の設定を確認してください。' : `位置情報の状態: ${permission}`);
        return;
      }
      const fix = await location.current();
      status.set(`緯度 ${fix.latitude.toFixed(5)} / 経度 ${fix.longitude.toFixed(5)} (精度 約${Math.round(fix.accuracyMeters)}m)`);
    })
  ]
});
