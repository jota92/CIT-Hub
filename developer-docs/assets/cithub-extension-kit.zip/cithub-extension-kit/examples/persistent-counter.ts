import { defineProgram, interactive, state, storage, app, capabilities, ui } from '../sdk/index';
const count = state.create(0);
const status = state.create('保存済みの値を読み込めます。');
export default defineProgram({
 name: '端末内保存テスト', version: '1.0.0', description: '本人・拡張機能ごとの端末内保存と非同期APIを確認します。', permissions: [],
 render: () => [ui.heading(`現在 ${count.value}`), ui.text(status.value), ui.text(`実行環境: ${app.environment()}`),
 interactive.button('読み込む', async () => { count.set(await storage.get<number>('count') ?? 0); status.set('読み込みました。'); }),
 interactive.button('増やして保存', async () => { const next = count.value + 1; await storage.set('count', next); count.set(next); status.set('保存しました。'); }),
 interactive.button('リセット', async () => { await storage.remove('count'); count.reset(); status.set('削除しました。'); }),
 ui.text(capabilities.has('storage.set') ? '端末内保存に対応' : '端末内保存に未対応')]
});
