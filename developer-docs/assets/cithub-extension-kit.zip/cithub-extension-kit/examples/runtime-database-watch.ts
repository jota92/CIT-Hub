import {defineProgram,database,state,ui} from '../sdk/index';
const observed=state.create('waiting');
database.watch('study',rows=>observed.set(JSON.stringify(rows)),error=>observed.set(String(error)));
export default defineProgram({name:'更新監視検証',version:'1.0.0',description:'別画面からの更新と再開時の監視を確認します。',permissions:[],render:()=>[ui.text(observed.value)]});
