import { analytics, defineProgram, interactive, ui } from '../sdk/index';

export default defineProgram({
  name: '匿名イベントの例',
  version: '1.0.0',
  description: '個人を識別しないイベント集計を試します。',
  permissions: ['analytics.collect'],
  render: () => [
    ui.text('ボタン操作の合計件数だけを計測します。'),
    interactive.button('詳細を開く', async () => {
      await analytics.event('detail.open');
    })
  ]
});
