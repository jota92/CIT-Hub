import { defineProgram, files, interactive, state, ui } from '../sdk/index';

const status = state.create('まずファイルを作成し、次に書き出してください。');

export default defineProgram({
  name: 'ファイル書き出しサンプル',
  version: '1.0.0',
    description: '拡張機能専用領域のファイルをOS標準の保存画面から書き出します。',
  permissions: ['files.storage'],
    render: () => [
      ui.heading('ファイルを書き出す'),
      ui.text(status.value),
      interactive.button('サンプルファイルを作成', async () => {
        try {
          await files.write('cithub-export.txt', new Uint8Array([67, 73, 84, 32, 72, 117, 98, 32, 101, 120, 116, 101, 110, 115, 105, 111, 110, 32, 101, 120, 112, 111, 114, 116]));
          status.set('作成しました。書き出しボタンを押してください。');
        } catch (error) {
          status.set(error instanceof Error ? error.message : String(error));
        }
      }),
      interactive.button('ファイルを書き出す', async () => {
        try {
          const saved = await files.saveAs('cithub-export.txt', 'CIT Hub export.txt');
          status.set(saved ? '保存しました。' : '保存をキャンセルしました。');
        } catch (error) {
          status.set(error instanceof Error ? error.message : String(error));
        }
      })
    ]
});
