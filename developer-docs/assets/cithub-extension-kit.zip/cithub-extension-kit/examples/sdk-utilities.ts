import { defineProgram, date, json, math, text, ui, utils } from '../sdk/index';

const identifier = utils.uuid();

export default defineProgram({
  name: 'SDKユーティリティ確認',
  version: '1.0.0',
  description: '日時・文字列・JSON・数学・UUIDのSDK APIを確認します。',
  permissions: [],
  render: () => [
    ui.heading('SDKユーティリティ'),
    ui.text(`UUID: ${identifier}`),
    ui.text(`中央値: ${math.median([8, 2, 4, 6])}`),
    ui.text(text.format('{name} / {day}', { name: 'CIT Hub', day: date.format(date.now(), { weekday: 'long' }) })),
    ui.text(json.stringify({ ready: true }))
  ]
});
