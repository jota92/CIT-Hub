import { defineProgram, interactive, state, ui } from '../sdk/index';
const count = state.create(0);
export default defineProgram({
 name: '操作テスト', version: '1.0.0', description: 'TypeScriptの状態変更、計算、非同期処理を確認します。', permissions: [],
 render: () => [ui.heading(`現在 ${count.value}`), interactive.button('増やす', async () => { await Promise.resolve(); count.update(value => value + 1); }), interactive.button('リセット', () => count.reset())]
});
