import {defineProgram,accessibility,ui} from '../sdk/index';
const status=await accessibility.status();
const reduceMotion=await accessibility.isReduceMotionEnabled();
let highContrast:boolean|string;
try{highContrast=await accessibility.isHighContrastEnabled();}catch(error){highContrast=error instanceof Error?error.message:String(error);}
export default defineProgram({name:'表示支援設定検証',version:'1.0.0',description:'OSの動作・コントラスト設定を確認します。',permissions:[],render:()=>[ui.text(JSON.stringify({status,reduceMotion,highContrast}))]});
