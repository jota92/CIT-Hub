import { defineProgram, interactive, network, state, ui } from '../sdk/index';

const message = state.create('接続状態はまだ確認していません。');

export default defineProgram({
  name: '接続状態の確認',
  version: '1.0.0',
  description: 'ボタンを押した時に通信方式と接続状態を確認します。',
  permissions: ['network.status'],
  render: () => [
    ui.text(message.value),
    interactive.button('接続状態を確認', async () => {
      const status = await network.status();
      message.set(`${status.connected ? '接続中' : '未接続'}・${status.transport}・従量制限: ${status.metered === null ? '不明' : status.metered ? 'あり' : 'なし'}`);
    })
  ]
});
