import { cloudUser, defineProgram, interactive, state, ui } from '../sdk/index';

const note = state.create('');
const status = state.create('');

export default defineProgram({
  name: 'クラウド設定サンプル',
  version: '1.0.0',
  description: '自分のアカウント間で同期する拡張機能設定の例です。',
  permissions: ['cloud.storage'],
  render() {
    return [
      ui.heading('アカウント間で同期するメモ'),
      interactive.textField('note', 'メモ', note),
      ui.text(status.value),
      interactive.button('読み込み', async () => {
        const result = await cloudUser.get<{ text: string }>('sample');
        note.set(result.value?.text ?? '');
        status.set(`revision ${result.revision}`);
      }),
      interactive.button('保存', async () => {
        const current = await cloudUser.get('sample');
        const revision = await cloudUser.set('sample', current.revision, { text: note.value });
        status.set(`保存しました。revision ${revision}`);
      }),
      interactive.button('削除', async () => {
        const current = await cloudUser.get('sample');
        const deleted = await cloudUser.delete('sample', current.revision);
        note.set('');
        status.set(deleted ? '削除しました。' : '保存データはありません。');
      })
    ];
  }
});
