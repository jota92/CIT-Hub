import { canvas, chart, defineProgram, files, pdf, photos, share, state, ui } from '../sdk/index';

const selectedPhoto=state.create('');
const selectedPDF=state.create('');
const feedback=state.create('');
const drawing=canvas.create(320,100,'学習時間の推移')
  .line(16,80,304,80,{stroke:'secondary'})
  .path([{op:'move',x:24,y:72},{op:'cubic',cx:80,cy:12,cx2:200,cy2:90,x:296,y:24}],{stroke:'accent',lineWidth:2})
  .circle(296,24,4)
  .text('今週',16,16,{size:12});

export default defineProgram({
  name:'描画とメディアの例',version:'1.0.0',description:'ネイティブ描画、グラフ、写真選択とPDF表示の使用例です。',
  permissions:['files.user','files.selection.read'],
  render:()=>[
      drawing.node(),
      chart.line('学習時間',['月','火','水','木','金'],[{label:'分',values:[30,60,45,90,80]}]),
      chart.donut('課題の状況',['未完了','完了'],[3,7]),
      ui.button('写真を選ぶ',async()=>{
        const chosen=await photos.pick();if(!chosen)return;
        selectedPhoto.set(chosen.key);
        const info=await photos.info(chosen.key);feedback.set(`${info.width} × ${info.height}`);
      }),
      ...(selectedPhoto.value?[ui.button('選んだ写真を共有',()=>share.image(selectedPhoto.value))]:[]),
      ui.button('PDFを選ぶ',async()=>{
        const chosen=await files.pickDocument();if(!chosen)return;
        const count=await pdf.pageCount(chosen.key);selectedPDF.set(chosen.key);feedback.set(`${count}ページ`);
      }),
      ...(selectedPDF.value?[ui.button('PDFを開く',()=>pdf.open(selectedPDF.value))]:[]),
      ui.text(feedback.value)
    ]
});
