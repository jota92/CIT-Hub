import { defineProgram, cit, ui, state } from '../sdk/index';

const [locations, menus, cameras] = await Promise.all([
  cit.cafeteria.locations(),
  cit.cafeteria.menu(),
  cit.cafeteria.cameraStatus()
]);
const content = state.create(JSON.stringify({ locations, menus, cameras }, null, 2));

export default defineProgram({
  name: '食堂情報APIサンプル',
  version: '1.0.0',
  description: '食堂の場所、公式メニューPDF、カメラの稼働時間を表示します。',
  permissions: ['cafeteria.read'],
  render: () => [ui.heading('食堂情報'), ui.text(content.value)]
});
