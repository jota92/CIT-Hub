import { defineProgram, interactive, share, state, ui } from '../sdk/index';

const status=state.create('共有する内容を選んでください。');

export default defineProgram({
  name:'共有シートAPIサンプル',
  version:'1.0.0',
  description:'利用者が押したときにOS標準の共有シートを開きます。',
  permissions:[],
  render:()=>[
    ui.heading('共有'),
    ui.text(status.value),
    interactive.button('案内文を共有',async()=>{
      try{await share.text('CIT Hubの共有APIから送信しました。');status.set('共有シートを開きました。');}
      catch(error){status.set(error instanceof Error?error.message:String(error));}
    }),
    interactive.button('公式サイトを共有',async()=>{
      try{await share.items([{text:'CIT Hub公式サイト'},{url:'https://cit-hub.vercel.app/'}]);status.set('共有シートを開きました。');}
      catch(error){status.set(error instanceof Error?error.message:String(error));}
    })
  ]
});
