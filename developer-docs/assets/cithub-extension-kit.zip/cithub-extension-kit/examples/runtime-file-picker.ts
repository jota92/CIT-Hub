import { defineProgram, files, interactive, state, ui } from '../sdk/index';

const status = state.create('画像を選択してください。');

export default defineProgram({
  name: 'ファイル選択サンプル',
  version: '1.0.0',
  description: '選択した画像の名前・サイズを表示し、必要なら内容を範囲読み込みします。',
  permissions: ['files.user', 'files.selection.read'],
  render: () => [
    ui.heading('ファイルを選ぶ'),
    ui.text(status.value),
    interactive.button('画像を選択', async () => {
      try {
        const file = await files.pickImage();
        if (!file) {
          status.set('選択をキャンセルしました。');
          return;
        }
        const firstChunk = await files.readSelected(file.key, 0, 32 * 1024);
        status.set(`${file.name}・${file.size} bytes・${file.mimeType}・読み込み ${firstChunk?.bytes.length ?? 0} bytes`);
      } catch (error) {
        status.set(error instanceof Error ? error.message : String(error));
      }
    })
  ]
});
