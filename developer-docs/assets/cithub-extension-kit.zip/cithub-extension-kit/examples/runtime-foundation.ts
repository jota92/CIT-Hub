import { defineProgram, field, list, navigation, state, ui } from '../sdk/index';

const title = field.create('title', '持ち物を確認');
const selectedTab = state.create('notes');
const time = state.create<number|null>(null);
const items = list.create([
  { id: 'notebook', title: 'ノート' },
  { id: 'calculator', title: '電卓' },
  { id: 'textbook', title: '教科書' }
], {
  key: item => item.id,
  render: item => [ui.text(item.title)],
  onSelect: item => ui.toast(`${item.title}を選択しました`)
}).contextMenu([{ title: '内容を確認', perform: item => ui.alert(item.title, '授業に必要な持ち物です。') }]);

navigation.register({ name: 'detail', title: 'メモ', render: () => [
  ui.textField(title.key, 'メモのタイトル', title),
  ui.time('noticeTime', '確認する時刻', time),
  ui.button('入力を元に戻す', () => title.reset()),
  ui.button('確認', async () => { if (await ui.confirm('保存しますか？', title.value)) ui.toast('確認しました'); })
] });
navigation.register({ name: 'help', title: '操作の説明', render: () => [ui.text('項目を長押しするとメニューを表示します。')] });

export default defineProgram({
  name: '操作と一覧のサンプル', version: '1.0.0', description: '入力・一覧・画面遷移・シート・確認ダイアログを使うサンプルです。', permissions: [],
  render: () => [
    ui.toolbar([ui.button('説明', () => navigation.sheet('help'))]),
    navigation.tabs([
      { id: 'notes', title: 'メモ', render: () => [ui.text(title.value), ui.button('メモを開く', () => navigation.push('detail'))] },
      { id: 'items', title: '持ち物', render: () => [ui.lazyList(items)] }
    ], selectedTab),
    ui.menu('その他', [
      ui.button('全画面で説明', () => navigation.fullScreen('help')),
      ui.button('名前を入力', async () => { const value = await ui.prompt('メモのタイトル', '', title.value); if (value !== null) title.set(value); })
    ])
  ]
});
