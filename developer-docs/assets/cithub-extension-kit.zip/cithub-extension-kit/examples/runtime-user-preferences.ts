import { defineProgram, cit, ui } from '../sdk/index';

const preferences = await cit.user.preferences();
const reminders = await cit.settings.notifications();
const services = await cit.services.list();

export default defineProgram({
  name: '自分のアプリ設定',
  version: '1.0.0',
  description: '自分の表示・通知・学内サービス設定を確認します。',
  permissions: ['settings.read'],
  render: () => [
    ui.heading('自分の設定'),
    ui.text(`有効な学内サービス: ${services.map(service => service.title).join('、') || 'なし'}`),
    ui.text(`授業開始通知: ${reminders.classStart ? 'オン' : 'オフ'}`),
    ui.text(`課題通知: ${reminders.assignments ? 'オン' : 'オフ'}`),
    ui.text(`テーマカラー: ${preferences.accentColor ?? '標準'}`),
    ui.text(`ポータル自動ログイン: ${preferences.portal.portalAutoLogin ? 'オン' : 'オフ'}`)
  ]
});
