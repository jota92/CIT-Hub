import { defineProgram, cit, ui } from '../sdk/index';

const [selectedSemester, visibleSemesters, todayIsClassDay] = await Promise.all([
  cit.semester.current(),
  cit.semester.list(),
  cit.academicCalendar.isClassDay(new Date())
]);

export default defineProgram({
  name: '学期と授業日の確認',
  version: '1.0.0',
  description: '取得済み時間割と学年暦から学期・授業日の情報を確認します。',
  permissions: ['timetable.read', 'calendar.read'],
  render: () => [
    ui.heading('学期と授業日'),
    ui.text(`選択中の学期: ${selectedSemester ?? '時間割未取得'}`),
    ui.text(`時間割に含まれる学期: ${visibleSemesters.join('、') || 'なし'}`),
    ui.text(`今日の授業日判定: ${todayIsClassDay === null ? '判定できません' : todayIsClassDay ? '授業日' : '休業日'}`)
  ]
});
