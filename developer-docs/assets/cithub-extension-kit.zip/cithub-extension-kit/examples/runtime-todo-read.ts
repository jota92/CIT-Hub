import { defineProgram, cit, ui, state } from '../sdk/index';
const first=await cit.todo.get('todo-a');
const matching=await cit.todo.search('数学');
const result=state.create(JSON.stringify({first,matching}));
cit.todo.watch(rows=>result.set(JSON.stringify({rows})),error=>result.set(String(error)));
export default defineProgram({
 name:'ToDo取得検証',version:'1.0.0',description:'本人のToDoの取得、検索、更新監視を検証します。',
 permissions:['todos.read'],render:()=>[ui.text(result.value)]
});
