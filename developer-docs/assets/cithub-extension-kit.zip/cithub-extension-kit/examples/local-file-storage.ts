import { app, defineProgram, files, interactive, state, ui } from '../sdk';

const status = state.create('保存ファイルを確認中');
app.onLaunch(async () => {
  const info = await files.info('study-note.txt');
  status.set(info ? `${info.name} · ${info.size} bytes` : '保存ファイルはありません');
});

export default defineProgram({
  name: '端末内ファイル',
  version: '1.0.0',
  description: '利用者ごとの拡張機能専用領域へ小さなファイルを保存',
  permissions: ['files.storage'],
  render: () => [ui.page('ファイル', [
      ui.text(status.value),
      interactive.button('サンプルを保存', async () => {
        await files.write('study-note.txt', Uint8Array.from([67, 73, 84, 32, 72, 117, 98]));
        const saved = await files.read('study-note.txt');
        status.set(saved ? `保存完了 · ${saved.byteLength} bytes` : '読み込みに失敗しました');
      })
    ])]
});
