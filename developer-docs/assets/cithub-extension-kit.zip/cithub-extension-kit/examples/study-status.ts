import { defineExtension, campus, ui } from '../sdk/index';
export default defineExtension({
 name: '授業と課題の確認', version: '1.0.0', description: '現在と次の授業、履修数、残っている課題を確認します。データは端末内だけで利用します。',
 permissions: ['timetable.read', 'assignments.read', 'todos.read'],
 content: [ui.section('授業', [ui.data(campus.currentClass(), '現在の授業'), ui.data(campus.nextClass(), '次の授業'), ui.data(campus.enrollment(), '履修状況')]),
 ui.section('課題', [ui.data(campus.workload(), '残っている課題'), ui.data(campus.dueSoon(), '7日以内の期限'), ui.data(campus.overdue(), '期限超過'), ui.data(campus.todos(), '自分のToDo')])]
});
