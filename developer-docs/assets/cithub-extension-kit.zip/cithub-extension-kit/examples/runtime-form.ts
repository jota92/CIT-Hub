import { defineProgram, interactive, state, ui } from '../sdk/index';
const name=state.create('');
const enabled=state.create(false);
export default defineProgram({name:'入力連携テスト',version:'1.0.0',description:'入力とTypeScriptの状態管理を接続するサンプルです。',permissions:[],render:()=>[
 interactive.textArea('name','名前',name),interactive.toggle('enabled','表示する',enabled),
 ui.text(enabled.value?`入力内容: ${name.value}`:'表示はオフです。')
]});
