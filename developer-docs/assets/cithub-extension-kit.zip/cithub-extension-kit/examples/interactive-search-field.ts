import { defineProgram, interactive } from '../sdk/program';
import { state } from '../sdk/core';
import { ui } from '../sdk';

const query = state.create('');
const matches = state.create('検索語を入力してください。');

export default defineProgram({
  name: '課題検索',
  version: '1.0.0',
  description: '検索欄のネイティブ操作と状態同期の例です。',
  permissions: [],
  render: () => [
    ui.heading('課題を検索'),
    interactive.searchField('query', '課題名を入力', query, {
      onSubmit: () => matches.set(query.value ? `「${query.value}」を検索します。` : '検索語を入力してください。')
    }),
    ui.text(matches.value)
  ]
});
