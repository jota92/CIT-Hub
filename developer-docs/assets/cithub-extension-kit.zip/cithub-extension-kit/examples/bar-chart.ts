import { defineProgram, ui } from '../sdk/index';

export default defineProgram({
  name: '学習時間',
  version: '1.0.0',
  description: '曜日ごとの学習時間を比較します。',
  permissions: [],
  render: () => [
      ui.page('学習時間', [
        ui.barChart('今週の学習時間', ['月', '火', '水', '木', '金'], [
        { label: '時間', values: [1.5, 2, 0.75, 1.25, 2.5] },
        ]),
      ]),
  ],
});
